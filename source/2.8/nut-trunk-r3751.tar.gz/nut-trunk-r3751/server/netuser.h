void net_login(nut_ctype_t *client, int numarg, const char **arg);
void net_logout(nut_ctype_t *client, int numarg, const char **arg);
void net_master(nut_ctype_t *client, int numarg, const char **arg);
void net_username(nut_ctype_t *client, int numarg, const char **arg);
void net_password(nut_ctype_t *client, int numarg, const char **arg);
