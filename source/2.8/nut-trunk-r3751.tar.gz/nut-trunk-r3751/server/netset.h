void net_set(nut_ctype_t *client, int numarg, const char **arg);
