void net_list(nut_ctype_t *client, int numarg, const char **arg);
