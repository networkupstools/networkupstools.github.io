void net_ver(nut_ctype_t *client, int numarg, const char **arg);
void net_netver(nut_ctype_t *client, int numarg, const char **arg);
void net_help(nut_ctype_t *client, int numarg, const char **arg);
void net_fsd(nut_ctype_t *client, int numarg, const char **arg);
