#ifndef NETVISION_MIB_H
#define NETVISION_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	netvision;

#endif /* NETVISION_MIB_H */
