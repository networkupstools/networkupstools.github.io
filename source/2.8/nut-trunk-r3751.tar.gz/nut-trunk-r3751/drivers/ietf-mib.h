#ifndef IETF_MIB_H
#define IETF_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	ietf;

#endif /* IETF_MIB_H */
