#ifndef RARITAN_PDU_MIB_H
#define RARITAN_PDU_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	raritan;

#endif /* RARITAN_PDU_MIB_H */
