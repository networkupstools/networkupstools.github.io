#ifndef COMPAQ_MIB_H
#define COMPAQ_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	compaq;

#endif /* COMPAQ_MIB_H */
