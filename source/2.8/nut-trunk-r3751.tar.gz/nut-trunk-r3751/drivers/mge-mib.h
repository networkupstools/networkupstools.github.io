#ifndef MGE_MIB_H
#define MGE_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	mge;

#endif /* MGE_MIB_H */
