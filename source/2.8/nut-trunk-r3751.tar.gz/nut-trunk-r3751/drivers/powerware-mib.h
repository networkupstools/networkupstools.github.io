#ifndef POWERWARE_MIB_H
#define POWERWARE_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	powerware;

#endif /* POWERWARE_MIB_H */
