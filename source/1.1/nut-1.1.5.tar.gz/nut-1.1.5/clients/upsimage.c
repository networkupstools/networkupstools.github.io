/* upsimage - cgi program to create graphical ups information reports

   Status:
     20020814 - Simon Rozman
       - redesigned the meters
     20020823 - Simon Rozman
       - added support for width, height and scale_height parameters
       - added support for outvolt
       - noimage now writes out a clue, why upsimage failed
     20020902 - Simon Rozman
       - background now transparent by default
       - added support for colorization parameters
       - removed linear antialiasing of the scale, until I come up with a better algorithm
	       
   Copyrights:
     (C) 1998  Russell Kroll <rkroll@exploits.org>
     (C) 2002  Simon Rozman <simon@rozman.net>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include "common.h"
#include "upsclient.h"
#include "cgilib.h"
#include <stdlib.h>

#ifdef HAVE_GD_GD_H
#include <gd/gd.h>
#include <gd/gdfontmb.h>
#elif HAVE_GD_H
#include <gd.h>
#include <gdfontmb.h>
#else
#error "You need gd to build this!  http://www.boutell.com/gd/"
#endif

#define MAX_CGI_STRLEN 64
#define MIN_WIDTH      50
int
	back_col		= 0x000000,
	scale_num_col		= 0xffff00,
	summary_col		= 0xffff00,
	ok_zone_maj_col 	= 0x00ff00,
	ok_zone_min_col		= 0x007800,
	neutral_zone_maj_col	= 0xffffff,
	neutral_zone_min_col	= 0x646464,
	warn_zone_maj_col	= 0xff0000,
	warn_zone_min_col	= 0x960000,
	bar_col                 = 0x00ff00;

#define MAX_WIDTH      200
#define MIN_HEIGHT     100
#define MAX_HEIGHT     500

static	char	*monhost = NULL, *cmd = NULL;
static	int	width = 100, height = 350, scale_height = 300;

static	int	port;
static	char	*upsname, *hostname;
static	UPSCONN	ups;

#define RED(x)         ((x >> 16) & 0xff)
#define GREEN(x)       ((x >> 8)  & 0xff)
#define BLUE(x)        (x & 0xff)

void parsearg(char *var, char *value) 
{
	int v;
	
	/* avoid bogus junk from evil people */
	if ((strlen(var) > MAX_CGI_STRLEN) || (strlen(value) > MAX_CGI_STRLEN))
		return;

	if (!strcmp(var, "host")) {
		if (monhost)
			free(monhost);

		monhost = xstrdup(value);
		return;
	}

	if (!strcmp(var, "display")) {
		if (cmd)
			free(cmd);

		cmd = xstrdup(value);
		return;
	}

	if (!strcmp(var, "width")) {
		v = atoi(value);

		/* avoid false width from bad people */
		if (v < MIN_WIDTH)
			width = MIN_WIDTH;
		else if (v > MAX_WIDTH)
			width = MAX_WIDTH;
		else
			width = v;

		return;
	}

	if (!strcmp(var, "height")) {
		v = atoi(value);

		/* avoid false height from bad people */
		if (v < MIN_HEIGHT)
			height = MIN_HEIGHT;
		else if (v > MAX_HEIGHT)
			height = MAX_HEIGHT;
		else
			height = v;
		
		scale_height = height - 50;
	} else if (!strcmp(var, "back_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		back_col = v;
	} else if (!strcmp(var, "scale_num_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		scale_num_col = v;
	} else if (!strcmp(var, "summary_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		summary_col = v;
	} else if (!strcmp(var, "ok_zone_maj_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		ok_zone_maj_col = v;
	} else if (!strcmp(var, "ok_zone_min_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		ok_zone_min_col = v;
	} else if (!strcmp(var, "neutral_zone_maj_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		neutral_zone_maj_col = v;
	} else if (!strcmp(var, "neutral_zone_min_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		neutral_zone_min_col = v;
	} else if (!strcmp(var, "warn_zone_maj_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		warn_zone_maj_col = v;
	} else if (!strcmp(var, "warn_zone_min_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		warn_zone_min_col = v;
	} else if (!strcmp(var, "bar_col")) {
		v = strtoul(value, (char **)NULL, 16);
		
		bar_col = v;
	}
}

/* write the HTML header then have gd dump the image */
static void drawimage(gdImagePtr im)
{
	printf("Pragma: no-cache\n");
	printf("Content-type: image/png\n\n");

	gdImagePng(im, stdout);
	gdImageDestroy(im);
	exit(0);
}

int gdImageColorAllocate2(gdImagePtr im, int rgb)
{
	return gdImageColorAllocate(im, RED(rgb), GREEN(rgb), BLUE(rgb));
}

static void drawscale(
	gdImagePtr im,				/* image where we would like to draw scale */
	int lvllo, int lvlhi,			/* min and max numbers on the scale */
	int step, int step5, int step10,	/* steps for minor, submajor and major dashes */
	int redlo1, int redhi1,			/* first red zone start and end */
	int redlo2, int redhi2,			/* second red zone start and end */
	int grnlo, int grnhi)			/* green zone start and end */
{
	int	col1, col2, back_color, scale_num_color, ok_zone_maj_color, ok_zone_min_color,
		neutral_zone_maj_color, neutral_zone_min_color, warn_zone_maj_color, warn_zone_min_color;
	char		lbltxt[16];
	int		y, level, range;
	
	back_color		= gdImageColorAllocate2(im, back_col);
	scale_num_color		= gdImageColorAllocate2(im, scale_num_col);
	ok_zone_maj_color	= gdImageColorAllocate2(im, ok_zone_maj_col);
	ok_zone_min_color	= gdImageColorAllocate2(im, ok_zone_min_col);
	neutral_zone_maj_color	= gdImageColorAllocate2(im, neutral_zone_maj_col);
	neutral_zone_min_color	= gdImageColorAllocate2(im, neutral_zone_min_col);
	warn_zone_maj_color	= gdImageColorAllocate2(im, warn_zone_maj_col);
	warn_zone_min_color	= gdImageColorAllocate2(im, warn_zone_min_col);

	/* start out with a background color and make it transparent */
	gdImageFilledRectangle(im, 0, 0, width, height, back_color);
	gdImageColorTransparent(im, back_color);
	
	range = lvlhi - lvllo;

	/* draw scale to correspond with the values */
	for (level = lvlhi; level >= lvllo; level -= step) {
		/* select dash RGB color according to the level */
		if (((redlo1 <= level) && (level <=redhi1)) || ((redlo2 <= level) && (level <=redhi2))) {
			col1 = warn_zone_maj_color;
			col2 = warn_zone_min_color;
		} else if ((grnlo <= level) && (level <= grnhi)) {
			col1 = ok_zone_maj_color;
			col2 = ok_zone_min_color;
		} else {
			col1 = neutral_zone_maj_color;
			col2 = neutral_zone_min_color;
		}

		/* calculate integer value for y */
		y = scale_height * (lvlhi - level) / range;
		
		/* draw major, semimajor or minor dash accordingly */		
		if (level % step10 == 0) {
			gdImageLine(im, 0, y, width, y, col1);
		} else {
		        if (level % step5 == 0)
				gdImageLine(im, 5, y, width - 5, y, col2);
			else
		    		gdImageLine(im, 10, y, width - 10, y, col2);
		}
	}

	/* put the values on the scale */	
	for (level = lvlhi; level >= lvllo; level -= step) {
		if (level % step10 == 0) {
			y = scale_height * (lvlhi - level) / range;
		        snprintf(lbltxt, sizeof(lbltxt), "%u", level);
			gdImageString(im, gdFontMediumBold, width - 20, y, lbltxt, scale_num_color);
		}
	}
}

static void noimage(const char *msg)
{
	gdImagePtr	im;
	int		back_color, summary_color;

	im = gdImageCreate(width, height);
	back_color = gdImageColorAllocate2(im, back_col);
	summary_color = gdImageColorAllocate2(im, summary_col);
	
	gdImageFilledRectangle(im, 0, 0, width, height, back_color);
	gdImageColorTransparent(im, back_color);
	
	if (width > height)
		gdImageString(im, gdFontMediumBold, (width - strlen(msg)*gdFontMediumBold->w)/2, (height - gdFontMediumBold->h)/2, (char*)msg, summary_color);
	else
		gdImageStringUp(im, gdFontMediumBold, (width - gdFontMediumBold->h)/2, (height + strlen(msg)*gdFontMediumBold->w)/2, (char*)msg, summary_color);

	drawimage(im);

	/* NOTREACHED */
}

static void drawbattcap(char *battcaps) 
{
	gdImagePtr	im;
	int		bar, summary_color;
	char		batttxt[16];
	int		battpos;
	double		battcap;
	
	battcap = strtod(battcaps, NULL);

	im = gdImageCreate(width, height);		/* X=width, Y=height */

        bar	= gdImageColorAllocate2(im, bar_col);
	summary_color	= gdImageColorAllocate2(im, summary_col);
	
	/* draw scale in the background */
	drawscale(im, 0, 100, 2, 10, 20, 0, 20, -1, -1, 80, 100);
	
	/* rescale battcap to get a Y coordinate for the top of the bar */
	battpos = (1 - battcap / 100) * scale_height;

	/* sanity checks: */

	/* 1: if battcap is above 100%, then battpos goes negative */
	if (battpos < 0)
		battpos = 0;

	/* 2: if battcap is somehow below 0%, battpos goes off the scale */
	if (battpos > scale_height)
		battpos = scale_height;

	/* draw it */
	gdImageFilledRectangle(im, 25, battpos, width - 25, scale_height, bar);

	/* stick the text version of the value at the bottom center */
	snprintf(batttxt, sizeof(batttxt), "%.1f %%", battcap);
	gdImageString(im, gdFontMediumBold, (width - strlen(batttxt)*gdFontMediumBold->w)/2, height - gdFontMediumBold->h, batttxt, summary_color);

	drawimage(im);

	/* NOTREACHED */
}

static void drawupsload(char *upsloads) 
{
	gdImagePtr	im;
	int		bar, summary_color;
	char		loadtxt[16];
	int		loadpos;
	double		upsload;

	upsload = strtod(upsloads, NULL);

	im = gdImageCreate(width, height);

        bar	= gdImageColorAllocate2(im, bar_col);
	summary_color	= gdImageColorAllocate2(im, summary_col);
	
	/* draw scale in the background */
	drawscale(im, 0, 125, 5, 25, 25, 100, 125, -1, -1, 0, 50);

	/* rescale upsload to get a Y coordinate */
	loadpos = (1 - upsload / 120) * scale_height;

	/* sanity tests */

	/* 1: upsload above 125 == negative loadpos */
	if (loadpos < 0)
		loadpos = 0;

	/* 2: upsload below 0 == loadpos off the scale */
	if (loadpos > scale_height)
		loadpos = scale_height;

	/* draw it */
	gdImageFilledRectangle(im, 25, loadpos, width - 25, scale_height, bar);

	/* label it */
	snprintf(loadtxt, sizeof(loadtxt), "%.1f %%", upsload);
	gdImageString(im, gdFontMediumBold, (width - strlen(loadtxt)*gdFontMediumBold->w)/2, height - gdFontMediumBold->h, loadtxt, summary_color);

	drawimage(im);

	/* NOTREACHED */
}

static void drawutility(char *utilstr, int ht, int lt) 
{
	gdImagePtr	im;
	int	bar, summary_color;
	char	utiltxt[16];
	int	lv, hv, vr, utp;
	double	ut;

	ut = strtod(utilstr, NULL);

	/* hack: deal with hardware that doesn't have known transfer points */
	if ((lt == 0) || (ht == 0)) {
		if (ut < 200.0) {
			lt = 90;
			ht = 140;
		}
		else {
			lt = 200;
			ht = 250;
		}
	}

	/* round transfer points to get high and low numbers for graph */
	lv = ((lt - 10 + 5) / 10) * 10;
	hv = ((ht + 10 + 5) / 10) * 10;
	
	/* voltage range */
	vr = hv - lv;

	im = gdImageCreate(width, height);

        bar	= gdImageColorAllocate2(im, bar_col);
	summary_color	= gdImageColorAllocate2(im, summary_col);
	
	/* draw scale in the background */
	if (vr <= 50)
		/* the scale is sparse enough to draw finer scale */
		drawscale(im, lv, hv, 1, 5, 10, ht, hv, lv, lt, lt + 10, ht - 10);
	else
		/* the scale is too dense to draw finer scale */
		drawscale(im, lv, hv, 2, 2, 10, ht, hv, lv, lt, lt + 10, ht - 10);

	/* draw the utility box */
	utp = ((double)(hv - ut) / vr) * scale_height;

	/* deal with insanity from very large voltage values */
	if (utp < 0)
		utp = 0;

	/* and handle insanity from very low values as well */
	if (utp > scale_height)
		utp = scale_height;

	gdImageFilledRectangle(im, 25, utp, width - 25, scale_height, bar);

	/* label it */
	snprintf(utiltxt, sizeof(utiltxt), "%.1f VAC", ut);
	gdImageString(im, gdFontMediumBold, (width - strlen(utiltxt)*gdFontMediumBold->w)/2, height - gdFontMediumBold->h, utiltxt, summary_color); 

	drawimage(im);

	/* NOTREACHED */
}

int main(int argc, char **argv)
{
	char	val[256], highxfer[256], lowxfer[256];

	extractcgiargs();

	/* no 'host=' or 'display=' given */
	if ((!monhost) || (!cmd))
		noimage("No host or display");

	if (!checkhost(monhost, NULL))
		noimage("Access denied");

	upscli_splitname(monhost, &upsname, &hostname, &port);

	if (upscli_connect(&ups, hostname, port, 0) < 0) {
		printf("Can't connect to server: %s\n", 
			upscli_strerror(&ups));
		exit(0);
	}

	if (!strcmp(cmd, "loadpct")) {
		if (upscli_getvar(&ups, upsname, "loadpct", val, sizeof(val)) < 0)
			noimage("loadpct N/A");

		drawupsload(val);
		exit(0);
	} 

	if (!strcmp(cmd, "battpct")) {
		if (upscli_getvar(&ups, upsname, "battpct", val, sizeof(val)) < 0)
			noimage("loadpct N/A");

		drawbattcap(val);
		exit(0);
	}

	if (!strcmp(cmd, "utility")) {
		if (upscli_getvar(&ups, upsname, "utility", val, sizeof(val)) < 0)
			noimage("utility N/A");

		/* these are not showstoppers */
		if (upscli_getvar(&ups, upsname, "highxfer", highxfer, sizeof(highxfer)) < 0)
			strncpy(highxfer, "0", 1);

		if (upscli_getvar(&ups, upsname, "lowxfer", lowxfer, sizeof(lowxfer)) < 0)
			strncpy(lowxfer, "0", 1);

		drawutility(val, atoi(highxfer), atoi(lowxfer));
		exit(0);
	}

	if (!strcmp(cmd, "outvolt")) {
		if (upscli_getvar(&ups, upsname, "outvolt", val, sizeof(val)) < 0)
			noimage("outvolt N/A");

		/* these are not showstoppers */
		if (upscli_getvar(&ups, upsname, "highxfer", highxfer, sizeof(highxfer)) < 0)
			strncpy(highxfer, "0", 1);

		if (upscli_getvar(&ups, upsname, "lowxfer", lowxfer, sizeof(lowxfer)) < 0)
			strncpy(lowxfer, "0", 1);

		drawutility(val, atoi(highxfer), atoi(lowxfer));
		exit(0);
	}

	noimage("Unknown display");

	return 0;
}
