/* upsclient - network communications functions for UPS clients

   Copyright (C) 2002  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include "common.h"

#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "upsclient.h"

#define UPSCLIENT_MAGIC 0x19980308

struct {
	int	flags;
	char	*str;
} upscli_errlist[] =
{
	{ 0, "Unknown error"			},	/*  0: UPSCLI_ERR_UNKNOWN */
	{ 0, "Variable not supported by UPS"	},	/*  1: UPSCLI_ERR_VARNOTSUPP */
	{ 0, "No such host"			},	/*  2: UPSCLI_ERR_NOSUCHHOST */
	{ 0, "Invalid response from server"	},	/*  3: UPSCLI_ERR_INVRESP */
	{ 0, "Unknown UPS"			},	/*  4: UPSCLI_ERR_UNKNOWNUPS */
	{ 0, "Invalid list type"		},	/*  5: UPSCLI_ERR_INVLISTTYPE */
	{ 0, "Access denied"			},	/*  6: UPSCLI_ERR_ACCESSDENIED */
	{ 0, "Password required"		},	/*  7: UPSCLI_ERR_PWDREQUIRED */
	{ 0, "Password incorrect"		},	/*  8: UPSCLI_ERR_PWDINCORRECT */
	{ 0, "Missing argument"			},	/*  9: UPSCLI_ERR_MISSINGARG */
	{ 0, "Data stale"			},	/* 10: UPSCLI_ERR_DATASTALE */
	{ 0, "Variable unknown"			},	/* 11: UPSCLI_ERR_VARUNKNOWN */
	{ 0, "Already logged in"		},	/* 12: UPSCLI_ERR_LOGINTWICE */
	{ 0, "Already set password"		},	/* 13: UPSCLI_ERR_PWDSETTWICE */
	{ 0, "Unknown variable type"		},	/* 14: UPSCLI_ERR_UNKNOWNTYPE */
	{ 0, "Unknown variable"			},	/* 15: U1PSCLI_ERR_UNKNOWNVAR */
	{ 0, "Read-only variable"		},	/* 16: UPSCLI_ERR_VARREADONLY */
	{ 0, "New value is too long"		},	/* 17: UPSCLI_ERR_TOOLONG */
	{ 0, "Invalid value for variable"	},	/* 18: UPSCLI_ERR_INVALIDVALUE */
	{ 0, "Set command failed"		},	/* 19: UPSCLI_ERR_SETFAILED */
	{ 0, "Unknown instant command"		},	/* 20: UPSCLI_ERR_UNKINSTCMD */
	{ 0, "Instant command failed"		},	/* 21: UPSCLI_ERR_CMDFAILED */
	{ 0, "Instant command not supported"	},	/* 22: UPSCLI_ERR_CMDNOTSUPP */
	{ 0, "Invalid username"			},	/* 23: UPSCLI_ERR_INVUSERNAME */
	{ 0, "Already set username"		},	/* 24: UPSCLI_ERR_USERSETTWICE */
	{ 0, "Unknown command"			},	/* 25: UPSCLI_ERR_UNKCOMMAND */
	{ 0, "Invalid argument"			},	/* 26: UPSCLI_ERR_INVALIDARG */
	{ 1, "Send failure: %s"			},	/* 27: UPSCLI_ERR_SENDFAILURE */
	{ 1, "Receive failure: %s"		},	/* 28: UPSCLI_ERR_RECVFAILURE */
	{ 1, "socket failure: %s"		},	/* 29: UPSCLI_ERR_SOCKFAILURE */
	{ 1, "bind failure: %s"			},	/* 30: UPSCLI_ERR_BINDFAILURE */
	{ 1, "Connection failure: %s"		},	/* 31: UPSCLI_ERR_CONNFAILURE */
	{ 1, "Write error: %s"			},	/* 32: UPSCLI_ ERR_WRITE */
	{ 1, "Read error: %s"			},	/* 33: UPSCLI_ERR_READ */
	{ 0, "Invalid password"			},	/* 34: UPSCLI_ERR_INVPASSWORD */
	{ 0, "Username required"		},	/* 35: UPSCLI_ERR_USERREQUIRED */
	{ 0, "SSL is not available",		},	/* 36: UPSCLI_ERR_SSLFAIL */

};

/* make sure we're using a struct that's been through upscli_connect */
const int upscli_checkmagic(UPSCONN *ups)
{
	if (!ups)
		return 0;

	if (ups->upsclient_magic != UPSCLIENT_MAGIC)
		return 0;

	return 1;
}

const char *upscli_strerror(UPSCONN *ups)
{
	static	char	buf[SMALLBUF];

	if (!ups)
		return upscli_errlist[UPSCLI_ERR_INVALIDARG].str;

	if (!upscli_checkmagic(ups))
		return upscli_errlist[UPSCLI_ERR_INVALIDARG].str;

	if (ups->upserror > UPSCLI_ERR_MAX)
		return "Invalid error number";

	switch (upscli_errlist[ups->upserror].flags) {

		case 0:
			return upscli_errlist[ups->upserror].str;

		case 1:
			snprintf(buf, sizeof(buf), upscli_errlist[ups->upserror].str,
				strerror(ups->syserrno));
			return buf;
	}

	/* fallthrough */

	snprintf(buf, sizeof(buf), "Unknown error flag %d",
		upscli_errlist[ups->upserror].flags);

	return buf;
}

static void upscli_wrerror(UPSCONN *ups)
{
	ups->upserror = UPSCLI_ERR_WRITE;
	ups->syserrno = errno;

	shutdown(ups->fd, 2);
	close(ups->fd);
	ups->fd = -1;
}

/* internal: abstract the SSL calls for the other functions */
static int net_read(UPSCONN *ups, char *buf, size_t buflen)
{
#ifdef HAVE_SSL
	if (ups->ssl)
		return SSL_read(ups->ssl, buf, buflen);
#endif

	return read(ups->fd, buf, buflen);
}

static int net_write(UPSCONN *ups, const char *buf, size_t count)
{
#ifdef HAVE_SSL
	if (ups->ssl)
		return SSL_write(ups->ssl, buf, count);
#endif

	return write(ups->fd, buf, count);
}

/* internal: bring back a line (up to LF or buflen bytes) */
static int upscli_read(UPSCONN *ups, char *buf, size_t buflen)
{
	int	ret, numrec = 0;
	char	ch;

	if (!ups)
		return -1;

	if ((!buf) || (buflen < 1) || (ups->fd == -1)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (!upscli_checkmagic(ups)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	for (;;) {
		ret = net_read(ups, &ch, 1);

		if (ret < 1) {
			ups->upserror = UPSCLI_ERR_READ;
			ups->syserrno = errno;

			shutdown(ups->fd, 2);
			close(ups->fd);
			ups->fd = -1;

			return -1;	
		}

		if ((ch == 10) || (numrec == (buflen - 1))) {

			/* tie off the end */
			buf[numrec] = '\0';
			return 0;
		}

		buf[numrec++] = ch;
	}

	/* NOTREACHED */
}
	
/* stub first */
#ifndef HAVE_SSL
int upscli_sslinit(UPSCONN *ups)
{
	return 0;		/* not supported */
}

#else

int upscli_sslinit(UPSCONN *ups)
{
	int	ret;
	char	buf[SMALLBUF];

	if (!ups)
		return -1;

	if (!upscli_checkmagic(ups)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	/* see if upsd even talks SSL/TLS */
	snprintf(buf, sizeof(buf), "STARTTLS\n");

	ret = write(ups->fd, buf, strlen(buf));

	if (ret < 0) {
		upscli_wrerror(ups);
		return -1;
	}

	ret = upscli_read(ups, buf, sizeof(buf));

	if (ret < 0)
		return -1;

	if (strcmp(buf, "OK STARTTLS") != 0)
		return 0;		/* not supported */

	/* upsd is happy, so let's crank up the client */

	SSL_library_init();

	ups->ctx = SSL_CTX_new(TLSv1_client_method());

	if (!ups->ctx)
		return 0;
	
	ups->ssl = SSL_new(ups->ctx);

	if (!ups->ssl)
		return 0;

	ret = SSL_set_fd(ups->ssl, ups->fd);

	if (ret != 1)
		return -1;

	SSL_set_connect_state(ups->ssl);

	return 1;	/* OK */
}
	
#endif	/* HAVE_SSL */
	
int upscli_connect(UPSCONN *ups, const char *host, int port, int flags)
{
	struct	sockaddr_in	local, server;
	struct	hostent	*serv;

	/* clear out any lingering junk */
	ups->fd = -1;
	ups->host = NULL;
	ups->flags = 0;
	ups->upserror = 0;
	ups->syserrno = 0;
	ups->upsclient_magic = UPSCLIENT_MAGIC;
	ups->ctx = NULL;
	ups->ssl = NULL;

	if (!host) {
		ups->upserror = UPSCLI_ERR_NOSUCHHOST;
		return -1;
	}

	if ((serv = gethostbyname(host)) == (struct hostent *) NULL) {

		ups->upserror = UPSCLI_ERR_NOSUCHHOST;
		return -1;
	}

	if ((ups->fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		ups->upserror = UPSCLI_ERR_SOCKFAILURE;
		ups->syserrno = errno;
		return -1;
	}

	memset(&local, '\0', sizeof(struct sockaddr_in));
	local.sin_family = AF_INET;
	local.sin_port = htons(INADDR_ANY);

	memset(&server, '\0', sizeof(struct sockaddr_in));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);

	memcpy(&server.sin_addr, serv->h_addr, serv->h_length);

	if (bind(ups->fd, (struct sockaddr *) &local, 
		sizeof(struct sockaddr_in)) == -1) {
		ups->upserror = UPSCLI_ERR_BINDFAILURE;
		ups->syserrno = errno;
		close(ups->fd);
		ups->fd = -1;

		return -1;
	}

	if (connect(ups->fd, (struct sockaddr *) &server, 
		sizeof(struct sockaddr_in)) == -1) {
		ups->upserror = UPSCLI_ERR_CONNFAILURE;
		ups->syserrno = errno;
		close(ups->fd);
		ups->fd = -1;

		return -1;
	}

	ups->host = xstrdup(host);
	ups->port = port;

	if (flags & UPSCLI_CONN_TRYSSL)
		upscli_sslinit(ups);

	if (flags & UPSCLI_CONN_REQSSL) {
		if (upscli_sslinit(ups) != 1) {
			ups->upserror = UPSCLI_ERR_SSLFAIL;
			return -1;
		}
	}

	return 0;
}

/* map upsd error strings back to upsclient internal numbers */
static struct {
	int	errnum;
	char	*text;
}	upsd_errlist[] =
{
	{ UPSCLI_ERR_VARNOTSUPP,	"VAR-NOT-SUPPORTED"	},	
	{ UPSCLI_ERR_UNKNOWNUPS,	"UNKNOWN-UPS"		},
	{ UPSCLI_ERR_ACCESSDENIED, 	"ACCESS-DENIED"		},
	{ UPSCLI_ERR_PWDREQUIRED,	"PASSWORD-REQUIRED"	},
	{ UPSCLI_ERR_PWDINCORRECT,	"PASSWORD-INCORRECT"	},
	{ UPSCLI_ERR_MISSINGARG,	"MISSING-ARGUMENT"	},
	{ UPSCLI_ERR_DATASTALE,		"DATA-STALE"		},
	{ UPSCLI_ERR_VARUNKNOWN,	"VAR-UNKNOWN"		},
	{ UPSCLI_ERR_LOGINTWICE,	"ALREADY-LOGGED-IN"	},
	{ UPSCLI_ERR_PWDSETTWICE,	"ALREADY-SET-PASSWORD"	},
	{ UPSCLI_ERR_UNKNOWNTYPE,	"UNKNOWN-TYPE"		},
	{ UPSCLI_ERR_UNKNOWNVAR,	"UNKNOWN-VAR"		},
	{ UPSCLI_ERR_VARREADONLY,	"READONLY"		},
	{ UPSCLI_ERR_TOOLONG,		"TOO-LONG"		},
	{ UPSCLI_ERR_INVALIDVALUE,	"INVALID-VALUE"		},
	{ UPSCLI_ERR_SETFAILED,		"SET-FAILED"		},
	{ UPSCLI_ERR_UNKINSTCMD,	"UNKNOWN-INSTCMD"	},
	{ UPSCLI_ERR_CMDFAILED,		"INSTCMD-FAILED"	},
	{ UPSCLI_ERR_CMDNOTSUPP,	"CMD-NOT-SUPPORTED"	},
	{ UPSCLI_ERR_INVUSERNAME,	"INVALID-USERNAME"	},
	{ UPSCLI_ERR_USERSETTWICE,	"ALREADY-SET-USERNAME"	},
	{ UPSCLI_ERR_UNKCOMMAND,	"UNKNOWN-COMMAND"	},
	{ UPSCLI_ERR_INVPASSWORD,	"INVALID-PASSWORD"	},
	{ UPSCLI_ERR_USERREQUIRED,	"USERNAME-REQUIRED"	},
	
	{ 0,			NULL,		}
};

static int upscli_errcheck(UPSCONN *ups, char *buf)
{
	int	i;

	if (!ups)
		return -1;

	if (!buf) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	/* see if it's even an error now */
	if (strncmp(buf, "ERR", 3) != 0)
		return 0;

	/* look it up in the table */
	for (i = 0; upsd_errlist[i].text != NULL; i++) {
		if (!strcmp(&buf[4], upsd_errlist[i].text)) {
			ups->upserror = upsd_errlist[i].errnum;
			return -1;
		}
	}

	/* hmm - don't know what upsd is telling us */
	ups->upserror = UPSCLI_ERR_UNKNOWN;
	return -1;
}

int upscli_getvar(UPSCONN *ups, const char *upsname, const char *var, 
			char *buf, size_t buflen)
{
	int	ret;
	char	cmd[SMALLBUF], tmp[LARGEBUF], *ptr;

	if (!ups)
		return -1;

	if ((!buf) || (!var) || (buflen < 1) || (ups->fd == -1)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (!upscli_checkmagic(ups)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (upsname)
		snprintf(cmd, sizeof(cmd), "REQ %s@%s\n", var, upsname);
	else
		snprintf(cmd, sizeof(cmd), "REQ %s\n", var);

	ret = net_write(ups, cmd, strlen(cmd));

	if (ret < 0) {
		upscli_wrerror(ups);
		return -1;
	}

	if (upscli_read(ups, tmp, sizeof(tmp)) != 0)
		return -1;

	if (upscli_errcheck(ups, tmp) != 0)
		return -1;

	if (strncmp(tmp, "ANS", 3) != 0) {
		ups->upserror = UPSCLI_ERR_INVRESP;

		/* try to copy some of it for later inspection */
		snprintf(buf, buflen, "%s", tmp);

		return -1;
	}

	if (!upsname)		/* skip "ANS <var> " */
		ptr = tmp + strlen(var) + 5;
	else			/* skip "ANS <var>@<upsname> " */
		ptr = tmp + strlen(var) + 5 + strlen(upsname) + 1;

	snprintf(buf, buflen, "%s", ptr);

	return 0;
}

static struct {
	int	type;
	char	*cmd;
	char	*resp;
}	upscli_cmdlist[] =
{
	{ UPSCLI_LIST_VARS, 	"LISTVARS",	"VARS",		},
	{ UPSCLI_LIST_RW,	"LISTRW",	"RW",		},
	{ UPSCLI_LIST_CMDS,	"LISTINSTCMD",	"INSTCMDS",	},
	{ 0,			NULL,		NULL		}
};

int upscli_getlist(UPSCONN *ups, const char *upsname, int listtype, 
			char *buf, size_t buflen)
{
	int	ret, i, cmdpos;
	char	cmd[SMALLBUF], tmp[LARGEBUF], *ptr;

	if (!ups)
		return -1;

	if ((!buf) || (buflen < 1) || (ups->fd == -1)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (!upscli_checkmagic(ups)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	cmdpos = -1;

	for (i = 0; upscli_cmdlist[i].cmd != NULL; i++) {
		if (upscli_cmdlist[i].type == listtype) {
			cmdpos = i;
			break;
		}
	}

	if (cmdpos == -1) {
		ups->upserror = UPSCLI_ERR_INVLISTTYPE;
		return -1;
	}

	if (upsname)
		snprintf(cmd, sizeof(cmd), "%s %s\n", 
			upscli_cmdlist[cmdpos].cmd, upsname);
	else
		snprintf(cmd, sizeof(cmd), "%s\n",
			upscli_cmdlist[cmdpos].cmd);

	ret = net_write(ups, cmd, strlen(cmd));

	if (ret < 0) {
		upscli_wrerror(ups);
		return -1;
	}

	if (upscli_read(ups, tmp, sizeof(tmp)) != 0)
		return -1;

	if (upscli_errcheck(ups, tmp) != 0)
		return -1;

	if (strncmp(tmp, upscli_cmdlist[cmdpos].resp,
		strlen(upscli_cmdlist[cmdpos].resp)) != 0) {
		ups->upserror = UPSCLI_ERR_INVRESP;

		/* try to copy some of it for later inspection */
		snprintf(buf, buflen, "%s", tmp);

		return -1;
	}

	if (!upsname) {

		/* skip "<resp> " */
		ptr = tmp + strlen(upscli_cmdlist[cmdpos].resp) + 1;

	} else {

		/* skip "<resp> @<name> " */
		ptr = tmp + strlen(upscli_cmdlist[cmdpos].resp) +
			strlen(upsname) + 3;	
	}

	snprintf(buf, buflen, "%s", ptr);

	return 0;
}

int upscli_sendline(UPSCONN *ups, const char *buf, size_t buflen)
{
	int	ret;

	if (!ups)
		return -1;

	if ((!buf) || (buflen < 1) || (ups->fd == -1)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (!upscli_checkmagic(ups)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	ret = net_write(ups, buf, buflen);

	if (ret < 0) {
		upscli_wrerror(ups);
		return -1;
	}

	return 0;
}

int upscli_readline(UPSCONN *ups, char *buf, size_t buflen)
{
	char	tmp[LARGEBUF];

	if (!ups)
		return -1;

	if ((!buf) || (buflen < 1) || (ups->fd == -1)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (!upscli_checkmagic(ups)) {
		ups->upserror = UPSCLI_ERR_INVALIDARG;
		return -1;
	}

	if (upscli_read(ups, tmp, sizeof(tmp)) != 0)
		return -1;

	if (upscli_errcheck(ups, tmp) != 0)
		return -1;

	snprintf(buf, buflen, "%s", tmp);

	return 0;
}

/* split [upsname@]hostname[:port] into separate components */
int upscli_splitname(const char *buf, char **upsname, char **hostname,
			int *port)
{
	char	tmp[SMALLBUF], *ptr, *ap, *cp;

	if ((!buf) || (!upsname) || (!hostname) || (!port))
		return -1;

	snprintf(tmp, sizeof(tmp), "%s", buf);

	ap = strchr(tmp, '@');

	if (ap) {
		*ap++ = '\0';
		*upsname = strdup(tmp);
		ptr = ap;

	} else {

		*upsname = NULL;
		ptr = tmp;
	}

	cp = strchr(ptr, ':');

	if (cp) {
		*cp++ = '\0';
		*hostname = strdup(ptr);
		ptr = cp;

		*port = strtol(ptr, (char **) NULL, 10);

	} else {

		*hostname = strdup(ptr);
		*port = PORT;
	}

	return 0;
}

int upscli_disconnect(UPSCONN *ups)
{
	if (!ups)
		return -1;

	if (!upscli_checkmagic(ups))
		return -1;

	if (ups->fd != -1) {

		/* try to disconnect gracefully */
		net_write(ups, "LOGOUT\n", 7);

		shutdown(ups->fd, 2);
		close(ups->fd);
		ups->fd = -1;
	}

	if (ups->host)
		free(ups->host);

	ups->host = NULL;
	ups->upsclient_magic = 0;

	return 0;
}

