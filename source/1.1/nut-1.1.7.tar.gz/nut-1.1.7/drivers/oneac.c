/*
 * NUT Oneac EG and ON model specific drivers for UPS units using
 * the Oneac Advanced Interface.  If your UPS is equipped with the
 * Oneac Basic Interface, use the genericups driver
*/

/*
   Copyright (C) 2002  by Eric Lawson <elawson@inficad.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


#include "main.h"
#include "oneac.h"


void instcmd (int auxcmd, int dlen, char *data)
{
	upslogx(LOG_INFO, "instcmd: unknown type 0x%04x", auxcmd);
}


void upsdrv_initinfo(void)
{
	char buffer[256];

	addinfo(INFO_MFR, "ONEAC", 0, 0);
	addinfo(INFO_MODEL, "", 0, 0);
	addinfo(INFO_FIRMREV, "", 0, 0);
	addinfo(INFO_STATUS, "", 0, 0);
	addinfo(INFO_XFERWHY, "", 0,0);
/*	addinfo(INFO_PDNGRACE, "", 0, 0); */
	addinfo(INFO_ACFREQ, "", 0, 0);
	addinfo(INFO_ALRM_GENERAL, "", 0, 0);

	/*set some stuff that shouldn't change after initialization*/
	/*firmware revision*/
	upssendchar (GET_VERSION);
	upssend (COMMAND_END);
	upsrecv (buffer, sizeof(buffer),ENDCHAR,IGNCHARS);
	setinfo (INFO_FIRMREV, "%3s",buffer);

	/*nominal AC frequency setting --either 50 or 60*/
	upssendchar (GET_NOM_FREQ);
	upssend (COMMAND_END);
	upsrecv (buffer, sizeof(buffer), ENDCHAR,IGNCHARS);
	setinfo (INFO_ACFREQ,"%2s", buffer);

	/*UPS type -- ON or EG */
	upssendchar (GET_FAMILY);
	upssend (COMMAND_END);
	upsrecv (buffer, sizeof(buffer), ENDCHAR, IGNCHARS);
	setinfo (INFO_MODEL, "%2s",buffer);

	upsh.instcmd = instcmd;

	writeinfo();
}

void upsdrv_updateinfo(void)
{
	 char buffer[256];

	upssendchar (GET_ALL);
	upssend (COMMAND_END);
	upsrecv (buffer, sizeof(buffer), ENDCHAR, IGNCHARS);

	upsdebugx (1,"upsrecv_updateinfo: upsrecv returned: %s\n",buffer);

	/*take care of the UPS status information*/
	switch (buffer[12]) {
		case NORMAL :
			setinfo (INFO_STATUS, "OL ");
			break;
		case ON_BAT_LOW_LINE :
		case ON_BAT_HI_LINE  :
			setinfo (INFO_STATUS, "OB ");
			break;
		case LO_BAT_LOW_LINE :
		case LO_BAT_HI_LINE  :
			setinfo (INFO_STATUS, "OB LB ");
			break;
		case TOO_HOT :
			setinfo (INFO_STATUS, "OVER FSD ");
			break;
		case FIX_ME :
			setinfo (INFO_ALRM_GENERAL, "ALARM ");
			break;
		case BAD_BAT :
			setinfo (INFO_STATUS, "RB ");
			break;
		default :
			upslogx (LOG_ERR, "Unknown UPS status");
	}

	/*take care of the reason why the UPS last transfered to battery*/
	switch (buffer[13]) {
		case XFER_BLACKOUT :
			setinfo (INFO_XFERWHY, "Blackout");
			break;
		case XFER_LOW_VOLT :
			setinfo (INFO_XFERWHY, "Low Utility Voltage");
			break;
		case XFER_HI_VOLT :
			setinfo (INFO_XFERWHY, "High Utility Voltage");
			break;
		case NO_VALUE_YET :
			setinfo (INFO_XFERWHY, "No transfer to battery has occured.");
			break;
		default :
			upslogx (LOG_ERR, "Unknown reason for UPS transfer to battery");
	}

	writeinfo();
}

void upsdrv_shutdown(void)
{
	upssend (SHUTDOWN);
}


void upsdrv_help(void)
{
	printf("You must set the DIP switch on the interface card to the\n");
	printf("9600 BPS position.");
}

void upsdrv_makevartable(void)
{
}

void upsdrv_banner(void)
{
printf("Network UPS Tools - Oneac EG/ON UPS driver 0.01 (%s)\n\n", UPS_VERSION);experimental_driver = 1;
}

void upsdrv_initups(void)
{
	char buffer[256];
	
	upsdebugx(1,"Trying to open serial port %s",device_path);
	open_serial(device_path, B9600);

	/*Is there anybody out there?*/

	upssend (COMMAND_END);
	sleep(1);
	upssend (COMMAND_END);
	sleep(1);
	upssendchar(GET_MFR);
	upssend(COMMAND_END);
	upsrecv (buffer, sizeof(buffer), ENDCHAR, IGNCHARS);
	if (strncmp(buffer, MFGR, sizeof(MFGR)))
		fatalx("Unable to contace ONEAC UPS on %s\n",device_path);
}

/* tell main how many items you need */
int upsdrv_infomax(void)
{
	return 64;
}
