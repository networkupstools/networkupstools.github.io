/* upsct - simple "client" to test communications (TCP mode)

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include "common.h"

#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "upsfetch.h"

	int	fd;
	char	*upsname;

void printvar(char *var)
{
	char	value[SMALLBUF];

	if (getupsvarfd(fd, upsname, var, value, sizeof(value)) < 0)
		printf("Error: %s\n", upsstrerror(upserror));
	else
		printf("%s\n", value);
}

void help(char *prog)
{
	printf("Network UPS Tools upsct %s\n\n", UPS_VERSION);

	printf("usage: %s <host> [<variable>]\n", prog);

	printf("\nDemo program to display UPS variables over a TCP socket.\n\n");

	printf("  <host>     - UPS server, [<upsname>@]host[:port] form\n");
	printf("  <variable> - optional, display this variable only.\n");
	printf("               Default: list all variables for <host>\n");

	exit(1);
}

int main(int argc, char **argv)
{
	char	vars[LARGEBUF], *v, *ptr, *host;

	if (argc < 2)
		help(argv[0]);

	/* handle upsname@hostname syntax and split up parts */
	ptr = strstr(argv[1], "@");
	if (ptr != NULL) {
		ptr[0] = 0;
		upsname = argv[1];
		host = ptr + 1;
	}
	else {
		upsname = NULL;
		host = argv[1];
	}

	fd = upsconnect(host);
	if (fd < 0) {
		printf("Unable to connect to %s - %s\n", host,
		        upsstrerror(upserror));
		exit(1);
	}

	if (argc >= 3) {
		printvar(argv[2]);
		exit(0);
	}

	if (getupsvarlistfd(fd, upsname, vars, sizeof(vars)) < 0) {
		printf("Unable to get variable list - %s\n", 
		        upsstrerror(upserror));
		exit(1);
	}

	printf("host: %s\n", host);

	if (strlen(vars) == 0) {
		printf("No variables available!  Check your configuration (ups.conf and upsd.conf)\n");
		exit(1);
	}

	v = vars;
	while (v != NULL) {
		ptr = strchr (v, ' ');
		if (ptr)
			*ptr++ = '\0';

		printf("%s: ", v);
		printvar(v);

		v = ptr;
	}		

	return 0;
}
