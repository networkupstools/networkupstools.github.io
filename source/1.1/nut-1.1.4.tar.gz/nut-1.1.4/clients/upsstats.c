/* upsstats - cgi program to generate the main ups info page

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include "common.h"
#include "upsclient.h"
#include "status.h"
#include "cgilib.h"
#include "timehead.h"

#include <sys/time.h>

static	char	*monhost = NULL;
static	int	use_celsius = 1, refreshdelay = -1;

	/* from cgilib's checkhost() */
static	char	*monhostdesc = NULL;

static	int	port;
static	char	*upsname, *hostname;
static	UPSCONN	ups;

#define MAX_CGI_STRLEN 64

void parsearg(char *var, char *value)
{
	/* avoid bogus junk from evil people */
	if ((strlen(var) > MAX_CGI_STRLEN) || (strlen(value) > MAX_CGI_STRLEN))
		return;

	if (!strcmp(var, "host")) {
		if (monhost)
			free(monhost);

		monhost = xstrdup(value);
		return;
	}

	if (!strcmp(var, "use_celsius"))
		use_celsius = (int) strtol(value, (char **) NULL, 10);
	
	if (!strcmp(var, "refresh"))
		refreshdelay = (int) strtol(value, (char **) NULL, 10);
}

static void report_error(void)
{
	if (ups.upserror == UPSCLI_ERR_VARNOTSUPP)
		printf("Not supported\n");
	else
		printf("[error: %s]\n", upscli_strerror(&ups));
}

static int parse_var(const char *buf)
{
	char	ans[SMALLBUF];

	if (upscli_getvar(&ups, upsname, buf, ans, sizeof(ans)) < 0) {
		report_error();
		return 1;	/* handled */
	}

	printf("%s\n", ans);

	return 1;	/* handled */
}

static void do_status(void)
{
	int	i;
	char	stat[SMALLBUF], *sp, *ptr;

	if (upscli_getvar(&ups, upsname, "status", stat, sizeof(stat)) < 0) {
		report_error();
		return;
	}

	sp = stat;

	while (sp) {
		ptr = strchr(sp, ' ');
		if (ptr)
			*ptr++ = '\0';

		/* expand from table in status.h */
		for (i = 0; stattab[i].name != NULL; i++)
			if (!strcmp(stattab[i].name, sp))
				printf("%s ", stattab[i].desc);

		sp = ptr;
	}
}

static int do_date(const char *buf)
{
	char	datebuf[SMALLBUF];
	time_t	tod;

	time(&tod);
	if (strftime(datebuf, sizeof(datebuf), buf, localtime(&tod))) {
		printf("%s\n", datebuf);
		return 1;
	}

	return 0;
}

static int get_img_val(const char *var, const char *desc)
{
	char	temp[SMALLBUF];

	if (upscli_getvar(&ups, upsname, var, temp, sizeof(temp)) < 0) {
		report_error();
		return 1;
	}

	printf("<IMG SRC=\"upsimage.cgi?host=%s&amp;display=%s&amp;\""
		" WIDTH=\"100\" HEIGHT=\"350\""
		" ALT=\"%s: %s\">\n",
			monhost, var, desc, temp);

	return 1;
}

static int do_img(const char *buf)
{
	if (!strcmp(buf, "BATTPCT"))
		return get_img_val("battpct", "Battery Charge");

	if (!strcmp(buf, "UTILITY"))
		return get_img_val("utility", "Utility");

	if (!strcmp(buf, "OUTVOLT"))
		return get_img_val("outvolt", "Output Voltage");

	if (!strcmp(buf, "LOADPCT"))
		return get_img_val("loadpct", "UPS Load");

	return 0;
}

/* look for lines starting and ending with @ containing valid commands */
static int parse_line(char *buf)
{
	char	*cmd;

	if (buf[0] != '@')
		return 0;	/* not handled */

	if (buf[strlen(buf) - 1] != '@')
		return 0;

	/* avoid the outer @s */
	buf[strlen(buf) - 1] = '\0';
	cmd = &buf[1];

	if (!strncmp(cmd, "VAR ", 4))
		return parse_var(&cmd[4]);

	if (!strcmp(cmd, "HOST")) {
		printf("%s\n", monhost);
		return 1;
	}

	if (!strcmp(cmd, "HOSTDESC")) {
		printf("%s\n", monhostdesc);
		return 1;
	}

	if (!strcmp(cmd, "STATUS")) {
		do_status();
		return 1;
	}	

	if (!strncmp(cmd, "DATE ", 5))
		return do_date(&cmd[5]);

	if (!strncmp(cmd, "IMG ", 4))
		return do_img(&cmd[4]);

	if (!strcmp(cmd, "VERSION")) {
		printf("%s\n", UPS_VERSION);
		return 1;
	}

	if (!strcmp(cmd, "REFRESH")) {
		if (refreshdelay > 0)
			printf("<META HTTP-EQUIV=\"Refresh\" CONTENT=\"%d\">\n", 
				refreshdelay);

		return 1;
	}
		
	return 0;
}

static void display_template(const char *tfn)
{
	char	fn[SMALLBUF], buf[LARGEBUF];	
	FILE	*tf;

	snprintf(fn, sizeof(fn), "%s/%s", CONFPATH, tfn);

	tf = fopen(fn, "r");

	if (!tf) {
		fprintf(stderr, "upsstats: Can't open %s: %s\n", 
			fn, strerror(errno));

		printf("Error: can't open template file\n");

		exit(1);
	}

	while (fgets(buf, sizeof(buf), tf)) {
		buf[strlen(buf) - 1] = '\0';

		if (!parse_line(buf))
			printf("%s\n", buf);
	}

	fclose(tf);
}

int main(int argc, char **argv)
{
	extractcgiargs();

	printf("Content-type: text/html\n"); 
	printf("Pragma: no-cache\n");
	printf("\n");

	if (!monhost) {
		printf("No host defined.  Set 'host' variable in the URL first.\n");
		exit(0);
	}

	if (!checkhost(monhost, &monhostdesc)) {
		printf("Access to that host [%s] is not authorized.\n",
			monhost);
		exit(0);
	}

	upscli_splitname(monhost, &upsname, &hostname, &port);

	if (upscli_connect(&ups, hostname, port, 0) < 0) {
		printf("Can't connect to server: %s\n",
			upscli_strerror(&ups));

		exit(1);
        }


	display_template("upsstats.html");

	return 0;
}
