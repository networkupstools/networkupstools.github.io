/* upsimage - cgi program to create graphical ups information reports

   Status:
     20020814 - Simon Rozman <simon@rozman.net>
       - redesigned the meters
     20020823 - Simon Rozman <simon@rozman.net>
       - added support for width, height and scale_height parameters
       - added support for outvolt
       - noimage now writes out a clue, why upsimage failed
	       
   Copyrights:
     (C) 1998  Russell Kroll <rkroll@exploits.org>
     (C) 2002  Simon Rozman <simon@rozman.net>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include "common.h"
#include "upsclient.h"
#include "cgilib.h"
#include <stdlib.h>

#ifdef HAVE_GD_GD_H
#include <gd/gd.h>
#include <gd/gdfontmb.h>
#elif HAVE_GD_H
#include <gd.h>
#include <gdfontmb.h>
#else
#error "You need gd to build this!  http://www.boutell.com/gd/"
#endif

#define MAX_CGI_STRLEN 64
#define MIN_WIDTH      50
#define MAX_WIDTH      200
#define MIN_HEIGHT     100
#define MAX_HEIGHT     500

static	char	*monhost = NULL, *cmd = NULL;
static	int	width = 100, height = 350, scale_height = 300;

static	int	port;
static	char	*upsname, *hostname;
static	UPSCONN	ups;

void parsearg(char *var, char *value) 
{
	int v;
	
	/* avoid bogus junk from evil people */
	if ((strlen(var) > MAX_CGI_STRLEN) || (strlen(value) > MAX_CGI_STRLEN))
		return;

	if (!strcmp(var, "host")) {
		if (monhost)
			free(monhost);

		monhost = xstrdup(value);
		return;
	}

	if (!strcmp(var, "display")) {
		if (cmd)
			free(cmd);

		cmd = xstrdup(value);
		return;
	}

	if (!strcmp(var, "width")) {
		v = atoi(value);

		/* avoid false width from bad people */
		if (v < MIN_WIDTH)
			width = MIN_WIDTH;
		else if (v > MAX_WIDTH)
			width = MAX_WIDTH;
		else
			width = v;

		return;
	}

	if (!strcmp(var, "height")) {
		v = atoi(value);

		/* avoid false height from bad people */
		if (v < MIN_HEIGHT)
			height = MIN_HEIGHT;
		else if (v > MAX_HEIGHT)
			height = MAX_HEIGHT;
		else
			height = v;
		
		scale_height = height - 50;
	}	
}

/* write the HTML header then have gd dump the image */
static void drawimage(gdImagePtr im)
{
	printf("Pragma: no-cache\n");
	printf("Content-type: image/png\n\n");

	gdImagePng(im, stdout);
	gdImageDestroy(im);
	exit(0);
}

static void blend(gdImagePtr im, float amount, int fr, int fg, int fb, 
		int br, int bg, int bb, int *col1, int *col2)
{
	float anti_amount;
	int r, g, b;
    
	anti_amount = 1 - amount;
    
	r = anti_amount * fr + amount * br;
	g = anti_amount * fg + amount * bg;
	b = anti_amount * fb + amount * bb;

	/* for paletted PNG prefill image palette with many colors and
		use gdImageColorClosest instead */

	*col1 = gdImageColorAllocate(im, r, g, b);

	r = amount * fr + anti_amount * br;
	g = amount * fg + anti_amount * bg;
	b = amount * fb + anti_amount * bb;
  
	*col2 = gdImageColorAllocate(im, r, g, b);
}

static void drawscale(
	gdImagePtr im,				/* image where we would like to draw scale */
	int lvllo, int lvlhi,			/* min and max numbers on the scale */
	int step, int step5, int step10,	/* steps for minor, submajor and major dashes */
	int redlo1, int redhi1,			/* first red zone start and end */
	int redlo2, int redhi2,			/* second red zone start and end */
	int grnlo, int grnhi)			/* green zone start and end */
{
	int		green, black, yellow, darkgrey;
	char		lbltxt[16];
	int		y, level, range;
	float           yf;
	int		r1, g1, b1, r2, g2, b2, col1, col2;
	
	black     = gdImageColorAllocate(im, 0, 0, 0);
	darkgrey  = gdImageColorAllocate(im, 50, 50, 50);
        green     = gdImageColorAllocate(im, 0, 255, 0);
	yellow    = gdImageColorAllocate(im, 255, 255, 0);

	/* start out with a black background color */
	gdImageFilledRectangle(im, 0, 0, width, height, black);

	/* the actual bar is backed with dark grey */
	gdImageFilledRectangle(im, 0, 0, width, height - 50, darkgrey);
	
	range        = lvlhi - lvllo;

	/* draw scale to correspond with the values */
	for (level = lvlhi; level >= lvllo; level -= step) {

		/* select dash RGB color according to the level */
		if (((redlo1 <= level) && (level <=redhi1)) || ((redlo2 <= level) && (level <=redhi2))) {
			r1 = 255; g1 = 0;   b1 = 0;
			r2 = 150; g2 = 0;   b2 = 0;
		} else if ((grnlo <= level) && (level <= grnhi)) {
			r1 = 0;   g1 = 255; b1 = 0;
			r2 = 0;   g2 = 120; b2 = 0;
		} else {
			r1 = 255; g1 = 255; b1 = 255;
			r2 = 100; g2 = 100; b2 = 100;
		}
		
		/* calculate float value for y, to perform antialiasing */
		yf = (float)scale_height * (lvlhi - level) / range;
		y = (int)yf;
		
		/* draw major, semimajor or minor dash accordingly */		
		if (level % step10 == 0) {
			blend(im, yf - y, r1, g1, b1, 50, 50, 50, &col1, &col2);
			gdImageLine(im, 0, y, width, y, col1); y++;
			gdImageLine(im, 0, y, width, y, col2);
		} else {
			blend(im, yf - y, r2, g2, b2, 50, 50, 50, &col1, &col2);
		        if (level % step5 == 0) {
				gdImageLine(im, 5, y, width - 5, y, col1); y++;
				gdImageLine(im, 5, y, width - 5, y, col2);
			} else {
		    		gdImageLine(im, 10, y, width - 10, y, col1); y++;
		    		gdImageLine(im, 10, y, width - 10, y, col2);
			}
		}
	}

	/* put the values on the scale */	
	for (level = lvlhi; level >= lvllo; level -= step) {
		if (level % step10 == 0) {
			y = scale_height * (lvlhi - level) / range;
		        snprintf(lbltxt, sizeof(lbltxt), "%u", level);
			gdImageString(im, gdFontMediumBold, width - 20, y, lbltxt, yellow);
		}
	}
}

static void noimage(const char *msg)
{
	gdImagePtr	im;
	int		black, white;

	im = gdImageCreate(width, height);
	white = gdImageColorAllocate(im, 255, 255, 255);
	black = gdImageColorAllocate(im, 0, 0, 0);
	
	gdImageFilledRectangle(im, 0, 0, width, height, black);
	if (width > height)
		gdImageString(im, gdFontMediumBold, (width - strlen(msg)*gdFontMediumBold->w)/2, (height - gdFontMediumBold->h)/2, (char*)msg, white);
	else
		gdImageStringUp(im, gdFontMediumBold, (width - gdFontMediumBold->h)/2, (height + strlen(msg)*gdFontMediumBold->w)/2, (char*)msg, white);

	drawimage(im);

	/* NOTREACHED */
}

static void drawbattcap(char *battcaps) 
{
	gdImagePtr	im;
	int		green, yellow;
	char		batttxt[16];
	int		battpos;
	double		battcap;
	
	battcap = strtod(battcaps, NULL);

	im = gdImageCreate(width, height);		/* X=width, Y=height */

        green  = gdImageColorAllocate(im, 0, 255, 0);
	yellow = gdImageColorAllocate(im, 255, 255, 0);
	
	/* draw scale in the background */
	drawscale(im, 0, 100, 2, 10, 20, 0, 20, -1, -1, 80, 100);
	
	/* rescale battcap to get a Y coordinate for the top of the bar */
	battpos = (1 - battcap / 100) * scale_height;

	/* sanity checks: */

	/* 1: if battcap is above 100%, then battpos goes negative */
	if (battpos < 0)
		battpos = 0;

	/* 2: if battcap is somehow below 0%, battpos goes off the scale */
	if (battpos > scale_height)
		battpos = scale_height;

	/* draw it */
	gdImageFilledRectangle(im, 25, battpos, width - 25, scale_height, green);

	/* stick the text version of the value at the bottom center */
	snprintf(batttxt, sizeof(batttxt), "%.1f %%", battcap);
	gdImageString(im, gdFontMediumBold, (width - strlen(batttxt)*gdFontMediumBold->w)/2, (scale_height + height - gdFontMediumBold->h)/2, batttxt, yellow);

	drawimage(im);

	/* NOTREACHED */
}

static void drawupsload(char *upsloads) 
{
	gdImagePtr	im;
	int		green, yellow;
	char		loadtxt[16];
	int		loadpos;
	double		upsload;

	upsload = strtod(upsloads, NULL);

	im = gdImageCreate(width, height);

        green  = gdImageColorAllocate(im, 0, 255, 0);
	yellow = gdImageColorAllocate(im, 255, 255, 0);
	
	/* draw scale in the background */
	drawscale(im, 0, 125, 5, 25, 25, 100, 120, -1, -1, 0, 50);

	/* rescale upsload to get a Y coordinate */
	loadpos = (1 - upsload / 120) * scale_height;

	/* sanity tests */

	/* 1: upsload above 125 == negative loadpos */
	if (loadpos < 0)
		loadpos = 0;

	/* 2: upsload below 0 == loadpos off the scale */
	if (loadpos > scale_height)
		loadpos = scale_height;

	/* draw it */
	gdImageFilledRectangle(im, 25, loadpos, width - 25, scale_height, green);

	/* label it */
	snprintf(loadtxt, sizeof(loadtxt), "%.1f %%", upsload);
	gdImageString(im, gdFontMediumBold, (width - strlen(loadtxt)*gdFontMediumBold->w)/2, (scale_height + height - gdFontMediumBold->h)/2, loadtxt, yellow);

	drawimage(im);

	/* NOTREACHED */
}

static void drawutility(char *utilstr, int ht, int lt) 
{
	gdImagePtr	im;
	int	green, yellow;
	char	utiltxt[16];
	int	lv, hv, vr, utp;
	double	ut;

	ut = strtod(utilstr, NULL);

	/* hack: deal with hardware that doesn't have known transfer points */
	if ((lt == 0) || (ht == 0)) {
		if (ut < 200.0) {
			lt = 90;
			ht = 140;
		}
		else {
			lt = 200;
			ht = 250;
		}
	}

	/* round transfer points to get high and low numbers for graph */
	lv = ((lt - 10 + 5) / 10) * 10;
	hv = ((ht + 10 + 5) / 10) * 10;
	
	/* voltage range */
	vr = hv - lv;

	im = gdImageCreate(width, height);

	green = gdImageColorAllocate(im, 0, 255, 0);
	yellow = gdImageColorAllocate(im, 255, 255, 0);
	
	/* draw scale in the background */
	drawscale(im, lv, hv, 1, 5, 10, ht, hv, lv, lt, lt + 10, ht - 10);

	/* draw the utility box */
	utp = ((double)(hv - ut) / vr) * scale_height;

	/* deal with insanity from very large voltage values */
	if (utp < 0)
		utp = 0;

	/* and handle insanity from very low values as well */
	if (utp > scale_height)
		utp = scale_height;

	gdImageFilledRectangle(im, 25, utp, width - 25, scale_height, green);

	/* label it */
	snprintf(utiltxt, sizeof(utiltxt), "%.1f VAC", ut);
	gdImageString(im, gdFontMediumBold, (width - strlen(utiltxt)*gdFontMediumBold->w)/2, (scale_height + height - gdFontMediumBold->h)/2, utiltxt, yellow); 

	drawimage(im);

	/* NOTREACHED */
}

int main(int argc, char **argv)
{
	char	val[256], highxfer[256], lowxfer[256];

	extractcgiargs();

	/* no 'host=' or 'display=' given */
	if ((!monhost) || (!cmd))
		noimage("No host or display");

	if (!checkhost(monhost, NULL))
		noimage("Access denied");

	upscli_splitname(monhost, &upsname, &hostname, &port);

	if (upscli_connect(&ups, hostname, port, 0) < 0) {
		printf("Can't connect to server: %s\n", 
			upscli_strerror(&ups));
		exit(0);
	}

	if (!strcmp(cmd, "loadpct")) {
		if (upscli_getvar(&ups, upsname, "loadpct", val, sizeof(val)) < 0)
			noimage("loadpct N/A");

		drawupsload(val);
		exit(0);
	} 

	if (!strcmp(cmd, "battpct")) {
		if (upscli_getvar(&ups, upsname, "battpct", val, sizeof(val)) < 0)
			noimage("loadpct N/A");

		drawbattcap(val);
		exit(0);
	}

	if (!strcmp(cmd, "utility")) {
		if (upscli_getvar(&ups, upsname, "utility", val, sizeof(val)) < 0)
			noimage("utility N/A");

		/* these are not showstoppers */
		if (upscli_getvar(&ups, upsname, "highxfer", highxfer, sizeof(highxfer)) < 0)
			strncpy(highxfer, "0", 1);

		if (upscli_getvar(&ups, upsname, "lowxfer", lowxfer, sizeof(lowxfer)) < 0)
			strncpy(lowxfer, "0", 1);

		drawutility(val, atoi(highxfer), atoi(lowxfer));
		exit(0);
	}

	if (!strcmp(cmd, "outvolt")) {
		if (upscli_getvar(&ups, upsname, "outvolt", val, sizeof(val)) < 0)
			noimage("outvolt N/A");

		/* these are not showstoppers */
		if (upscli_getvar(&ups, upsname, "highxfer", highxfer, sizeof(highxfer)) < 0)
			strncpy(highxfer, "0", 1);

		if (upscli_getvar(&ups, upsname, "lowxfer", lowxfer, sizeof(lowxfer)) < 0)
			strncpy(lowxfer, "0", 1);

		drawutility(val, atoi(highxfer), atoi(lowxfer));
		exit(0);
	}

	noimage("Unknown display");

	return 0;
}
