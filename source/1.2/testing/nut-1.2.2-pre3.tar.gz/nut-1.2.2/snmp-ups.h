/*  snmp-ups.h - NUT Meta SNMP driver (support different MIBS)
 *
 *  Based on UCD/NetSNMP API (Simple Network Management Protocol V1-2)
 *
 *  Copyright (C) 2002-2003 
 *  			Dmitry Frolov <frolov@riss-telecom.ru>
 *  			Arnaud Quette <arnaud.quette@free.fr>
 *
 *  data structure and processing principles are inspired by:
 *            Hans Ekkehard Plesser <hans.plesser@itf.nlh.no>
 *
 *  Sponsored by MGE UPS SYSTEMS <http://www.mgeups.com/opensource/>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/* TODO list:
- complete shutdown
- add enum values to OIDs.
- optimize network flow by constructing one big packet (calling snmp_add_null_var
for each OID request we made), instead of sending many small packets
- complete mib2nut data (add all OID translation to NUT)
- externalize mib2nut data in .m2n files and load at driver startup using parseconf()...
- ... and use Net-SNMP lookup mecanism for OIDs (use string path, not numeric)
- add support for registration and traps (needed ?),
- add mib autodetection support (needed ?),
- adjust information logging.
*/

#define SNMP_UPS_VERSION "0.2"

#include <unistd.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include "common.h"
#include <shared.h>
#include <shared-tables.h> 

/* use explicit booleans */
#ifndef FALSE
typedef enum ebool { FALSE, TRUE } bool;
#else
typedef int bool;
#endif

/* Common SNMP data and lookup definitions */
/* special functions to interpret items: 
   take UPS answer, return string to set in INFO, max len  
   
   NOTE: FFE means For Future Extensions
   
   */
   
/* typedef void (*interpreter)(char *, char *, int); */

/* for lookup between OID values and INFO_ value */
typedef struct {
	int oid_value;		/* OID value */
	char *info_value;	/* INFO_* value */
} info_lkp_t;

/* Structure containing info about one item that can be requested
   from UPS and set in INFO.  If no interpreter functions is defined,
   use sprintf with given format string.  If unit is not NONE, values
   are converted according to the multiplier table  
*/
typedef struct {
	int info_type;				/* INFO_ or CMD_ element */
	int info_flags;				/* flags to set in addinfo */
	int info_len;				/* length of strings if STR, */
								/* cmd value if CMD, multiplier otherwise. */
	char *OID;					/* SNMP OID or NULL */
	char *dfl;					/* default value */
	unsigned long flags;		/* my flags */
	info_lkp_t *oid2info;		/* lookup table between OID and NUT values */
/*	char *info_OID_format;		*//* FFE: OID format for complex values */
/*	interpreter interpret;		*//* FFE: interpreter fct, NULL if not needed  */
} snmp_info_t;

#define SU_FLAG_OK			(1 << 0)		/* show element to upsd. */
#define SU_FLAG_STATIC		(1 << 1)		/* retrieve info only once. */
#define SU_FLAG_ABSENT		(1 << 2)		/* data is absent in the device, */
										/* use default value. */
#define SU_FLAG_STALE		(1 << 3)		/* data stale, don't try too often. */

/* status string components */
#define SU_STATUS_PWR		(0 << 8)		/* indicates power status element */
#define SU_STATUS_BATT		(1 << 8)		/* indicates battery status element */
#define SU_STATUS_CAL		(2 << 8)		/* indicates calibration status element */
#define SU_STATUS_RB		(3 << 8)		/* indicates replace battery status element */
#define SU_STATUS_NUM_ELEM	4
#define SU_STATUS_INDEX(t)	(((t) >> 8) & 7)

/* hints for su_ups_set, applicable only to rw vars */
#define SU_TYPE_INT			(0 << 16)	/* cast to int when setting value */
#define SU_TYPE_STRING		(1 << 16)	/* cast to string */
#define SU_TYPE_TIME		(2 << 16)	/* cast to int */
#define SU_TYPE(t)			((t)->flags & 7 << 16)

#define SU_CMD_MASK			0x2000

#define SU_VAR_COMMUNITY	"community"
#define SU_VAR_VERSION		"snmp_version"
#define SU_VAR_MIBS			"mibs"
#define SU_VAR_SDTYPE		"sdtype"

#ifdef VALSIZE
#define SU_INFOSIZE		VALSIZE
#else
#define SU_INFOSIZE		128
#endif
#define SU_BUFSIZE		32
#define SU_LARGEBUF		256

#define SU_STALE_RETRY	10		/* retry to retrieve stale element */
								/* after this number of iterations. */
/* modes to snmp_ups_walk. */
#define SU_WALKMODE_INIT	0
#define SU_WALKMODE_UPDATE	1


typedef struct {
	snmp_info_t *snmp_info; /* pointer to the good Snmp2Nut lookup data */
	
} mib2nut_info;

/* Common SNMP functions */
void nut_snmp_init(const char *type, const char *host, const char *community);
void nut_snmp_cleanup(void);
struct snmp_pdu *nut_snmp_get(const char *OID);
bool nut_snmp_get_str(const char *OID, char *buf, size_t buf_len);
bool nut_snmp_get_int(const char *OID, long *pval);
bool nut_snmp_set(const char *OID, char type, const char *value);
bool nut_snmp_set_str(const char *OID, const char *value);
bool nut_snmp_set_int(const char *OID, long value);
void nut_snmp_perror(struct snmp_session *sess,  int status,
	struct snmp_pdu *response, const char *fmt, ...);
		
void su_startup(void);
void su_cleanup(void);
void su_init_instcmds(void);
void su_setuphandlers(void); /* need to deal with external function ptr */
void su_setinfo(int type, const char *value, int flags, int auxdata);
void su_status_set(snmp_info_t *, long value);
snmp_info_t *su_find_info(int type);
struct netvars_t *su_find_netvar(int type);
struct instcmds_t *su_find_instcmd(int cmd);
bool snmp_ups_walk(int mode);
bool su_ups_get(snmp_info_t *su_info_p);

void load_mib2nut(char *mib);
char *su_find_infoval(info_lkp_t *oid2info, long value);
long su_find_valinfo(info_lkp_t *oid2info, char* value);

extern char *upsname;
struct snmp_session g_snmp_sess, *g_snmp_sess_p;
char *OID_pwr_status;
int g_pwr_battery;

void su_ups_set(int type, int data_len, char *data);
void su_ups_instcmd(int auxcmd, int data_len, char *data);
void su_shutdown_ups(void);

