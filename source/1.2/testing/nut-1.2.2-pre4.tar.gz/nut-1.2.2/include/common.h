#ifndef NUT_COMMON_H
#define NUT_COMMON_H

/* common.h - prototypes for the common useful functions

   Copyright (C) 2000  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <math.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <assert.h>

#ifndef HAVE_CFMAKERAW
#include <termios.h>
#endif

#include "config.h"
#include "proto.h"
#include "version.h"

/* close ttys and become a daemon */
void background(void);

void switch_to_user(const char *user, const char *group);

/* change uid/gid if running as root */
void droproot(void);

/* write a pid file - <name> is a full pathname *or* just the program name */
void writepid(const char *name);

/* send a signal to another running process */
void sendsignal(const char *progname, int sig);

int snprintfcat(char *dst, size_t size, const char *fmt, ...);

/* open <pidfn>, get the pid, then send it <sig> */
void sendsignalfn(const char *pidfn, int sig);

const char *xbasename(const char *file);

void xbit_set(int *val, int flag);
void xbit_clear(int *val, int flag);

/* enable writing upslog() type messages to the syslog */
void syslogbit_set(void);

void upslog(int priority, const char *fmt, ...);
void upslogx(int priority, const char *fmt, ...);
void upsdebug(int level, const char *fmt, ...);
void upsdebugx(int level, const char *fmt, ...);

void fatal(const char *fmt, ...);
void fatalx(const char *fmt, ...);

extern int nut_debug_level;

void *xmalloc(size_t size);
void *xcalloc(size_t number, size_t size);
void *xrealloc(void *ptr, size_t size);
char *xstrdup(const char *string);


/* Buffer sizes used for various functions */
#define SMALLBUF	512
#define LARGEBUF	1024

/* 
 * Provide declarations for getopt() global variables, used in the model
 * drivers for parsing command line options.
 */
#ifdef NEED_GETOPT_H
#include <getopt.h>
#else
#ifdef NEED_GETOPT_DECLS
extern char *optarg;
extern int optind; 
#endif /* NEED_GETOPT_DECLS */
#endif /* HAVE_GETOPT_H */

/* logging flags: bitmask! */

#define UPSLOG_STDERR		0x0001
#define UPSLOG_SYSLOG		0x0002
#define UPSLOG_STDERR_ON_FATAL	0x0004
#define UPSLOG_SYSLOG_ON_FATAL	0x0008

#ifndef HAVE_CFMAKERAW
int cfmakeraw(struct termios *termios_p);
#endif

#ifndef HAVE_SETEUID
#	define seteuid(x) setresuid(-1,x,-1)    /* Works for HP-UX 10.20 */
#	define setegid(x) setresgid(-1,x,-1)    /* Works for HP-UX 10.20 */
#endif

#endif /* NUT_COMMON_H */
