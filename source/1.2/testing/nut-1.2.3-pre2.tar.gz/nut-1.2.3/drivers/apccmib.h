/*  apccmib.h - data to monitor APC SNMP devices (Powernet MIB) with NUT
 *
 *  Copyright (C) 2002-2003 
 *  			Dmitry Frolov <frolov@riss-telecom.ru>
 *  			Arnaud Quette <arnaud.quette@free.fr>
 *
 *  data structure and processing principles are inspired by:
 *            Hans Ekkehard Plesser <hans.plesser@itf.nlh.no>
 *
 *  Sponsored by MGE UPS SYSTEMS <http://www.mgeups.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#define APCC_MIB_VERSION	"1.0"

/* SNMP OIDs set */
#define APCC_OID_POWERNET_MIB	".1.3.6.1.4.1.318"
/* info elements */
#define APCC_OID_MODEL_NAME		".1.3.6.1.4.1.318.1.1.1.1.1.1"
#define APCC_OID_UPSIDEN			".1.3.6.1.4.1.318.1.1.1.1.1.2"
#define APCC_OID_FIRMREV			".1.3.6.1.4.1.318.1.1.1.1.2.1"
#define APCC_OID_MFRDATE			".1.3.6.1.4.1.318.1.1.1.1.2.2"
#define APCC_OID_SERIAL			".1.3.6.1.4.1.318.1.1.1.1.2.3"
#define APCC_OID_BATT_STATUS		".1.3.6.1.4.1.318.1.1.1.2.1.1"
/* Defines for APCC_OID_BATT_STATUS */
#define APCC_BATT_UNKNOWN		1	/* unknown -> INFO_STATUS/? */
#define APCC_BATT_NORMAL		2	/* batteryNormal -> INFO_STATUS/? */
#define APCC_BATT_LOW			3	/* batteryLow -> INFO_STATUS/LB */

info_lkp_t apcc_batt_info[] = {
/*	{ APCC_BATT_UNKNOWN, "" }, */
/*	{ APCC_BATT_NORMAL, "" }, */
	{ APCC_BATT_LOW, "LB" },
	{ 0, "\0" }
} ;

#define APCC_OID_BATTDATE		".1.3.6.1.4.1.318.1.1.1.2.1.3"
#define APCC_OID_BATT_CHARGE	".1.3.6.1.4.1.318.1.1.1.2.2.1"
#define APCC_OID_UPSTEMP		".1.3.6.1.4.1.318.1.1.1.2.2.2"
#define APCC_OID_BATT_RUNTIME	".1.3.6.1.4.1.318.1.1.1.2.2.3"
#define APCC_OID_INVOLT			".1.3.6.1.4.1.318.1.1.1.3.2.1"
#define APCC_OID_INFREQ			".1.3.6.1.4.1.318.1.1.1.3.2.4"
#define APCC_OID_POWER_STATUS	".1.3.6.1.4.1.318.1.1.1.4.1.1"

/* Defines for APCC_OID_POWER_STATUS */
#define APCC_PWR_OTHER			1	/* other -> INFO_STATUS/? */
#define APCC_PWR_NORMAL			2	/* normal -> INFO_STATUS/OL */
#define APCC_PWR_BATTERY		3	/* battery -> INFO_STATUS/OB */
#define APCC_PWR_BOOSTER		4	/* booster -> INFO_STATUS/BOOST */
#define APCC_PWR_SLEEPING		5	/* timedSleeping -> INFO_STATUS/OFF */
#define APCC_PWR_SOFT_BYPASS	6	/* bypass -> INFO_STATUS/? */
#define APCC_PWR_NONE			7	/* none -> INFO_STATUS/OFF */
#define APCC_PWR_REBOOTING		8	/* rebooting -> INFO_STATUS/? */
#define APCC_PWR_HARD_BYPASS	9	/* bypass -> INFO_STATUS/? */
#define APCC_PWR_FAIL_BYPASS	10	/* bypass -> INFO_STATUS/? */
#define APCC_PWR_SLEEPING2		11	/* sleepingUntilPowerReturn -> INFO_STATUS/OFF */
#define APCC_PWR_REDUCER		12	/* reducer -> INFO_STATUS/TRIM */

info_lkp_t apcc_pwr_info[] = {
/*	{ APCC_PWR_OTHER, "" }, */
	{ APCC_PWR_NORMAL, "OL" },
	{ APCC_PWR_BATTERY, "OB" },
	{ APCC_PWR_BOOSTER, "BOOST" },
	{ APCC_PWR_SLEEPING, "OFF" },
/*	{ APCC_PWR_SOFT_BYPASS, "OFF" }, */
/*	{ APCC_PWR_NONE, "" }, */
/*	{ APCC_PWR_REBOOTING, "" }, */
/*	{ APCC_PWR_HARD_BYPASS, "" }, */
/*	{ APCC_PWR_FAIL_BYPASS, "" }, */
	{ APCC_PWR_SLEEPING2, "OFF" },
	{ APCC_PWR_REDUCER, "TRIM" },
	{ 0, "\0" }
} ;

#define APCC_OID_OUTVOLT		".1.3.6.1.4.1.318.1.1.1.4.2.1"
#define APCC_OID_LOADPCT		".1.3.6.1.4.1.318.1.1.1.4.2.3"
#define APCC_OID_HIGHXFER		".1.3.6.1.4.1.318.1.1.1.5.2.2"
#define APCC_OID_LOWXFER		".1.3.6.1.4.1.318.1.1.1.5.2.3"
#define APCC_OID_SLFTSTRES		".1.3.6.1.4.1.318.1.1.1.7.2.3"
/* XXX can't find appropriate OID for INFO_BATTVOLT. */
/*#define APCC_OID_BATT_VOLTAGE	".1.3.6.1.4.1.318.???"*/
/* commands */
#define APCC_OID_OFF			".1.3.6.1.4.1.318.1.1.1.6.2.1"
#define APCC_OFF_DO 2
#define APCC_OFF_GRACEFUL 3
#define APCC_OID_REBOOT			".1.3.6.1.4.1.318.1.1.1.6.2.2"
#define APCC_REBOOT_DO			2
#define APCC_REBOOT_GRACEFUL	3
#if 0	/* not used. */
	#define APCC_OID_SLEEP		".1.3.6.1.4.1.318.1.1.1.6.2.3"
	#define APCC_SLEEP_ON			"2"
	#define APCC_SLEEP_GRACEFUL		"3"
#endif
#define APCC_OID_SIMPWF			".1.3.6.1.4.1.318.1.1.1.6.2.4"
#define APCC_SIMPWF_DO			2
#define APCC_OID_FPTEST			".1.3.6.1.4.1.318.1.1.1.6.2.5"
#define APCC_FPTEST_DO			2
#define APCC_OID_ON				".1.3.6.1.4.1.318.1.1.1.6.2.6"
#define APCC_ON_DO				2
#define APCC_OID_BYPASS			".1.3.6.1.4.1.318.1.1.1.6.2.7"
#define APCC_BYPASS_ON			2
#define APCC_BYPASS_OFF			3
#define APCC_OID_SELFTEST		".1.3.6.1.4.1.318.1.1.1.7.2.2"
#define APCC_SELFTEST_DO		2
#define APCC_OID_CAL			".1.3.6.1.4.1.318.1.1.1.7.2.5"
#define APCC_CAL_DO				2
#define APCC_CAL_CANCEL			3
#define APCC_OID_CAL_RESULTS	".1.3.6.1.4.1.318.1.1.1.7.2.6"
#define APCC_CAL_OK				1
#define APCC_CAL_INVALID		2
#define APCC_CAL_INPROGRESS		3
/*#define APCC_OID_OUTPUT_TAB	"XXX"*/
#define APCC_OID_OUTCURRENT		".1.3.6.1.4.1.318.1.1.1.4.2.4"
#define APCC_OID_REQOUTVOLT		".1.3.6.1.4.1.318.1.1.1.5.2.1"
#define APCC_OID_RETCAPACITY	".1.3.6.1.4.1.318.1.1.1.5.2.6"
#define APCC_OID_CONSERVE		".1.3.6.1.4.1.318.1.1.1.6.1.1"
#define APCC_CONSERVE_DO		2
#define APCC_OID_NEEDREPLBATT	".1.3.6.1.4.1.318.1.1.1.2.2.4"
#define APCC_RB_NONEED			1
#define APCC_RB_NEED			2
#define APCC_OID_SENS			".1.3.6.1.4.1.318.1.1.1.5.2.7"
#define APCC_OID_GRACEDELAY		".1.3.6.1.4.1.318.1.1.1.5.2.10"
#define APCC_OID_RETDELAY		".1.3.6.1.4.1.318.1.1.1.5.2.9"
#define APCC_OID_LOBATTIME		".1.3.6.1.4.1.318.1.1.1.5.2.8"


snmp_info_t apcc_mib[] = {

	/* info elements. */
	{ INFO_MFR, FLAG_STRING, SU_INFOSIZE, NULL, "APC",
		SU_FLAG_STATIC | SU_FLAG_ABSENT | SU_FLAG_OK, NULL },
	{ INFO_MODEL, FLAG_STRING, SU_INFOSIZE, APCC_OID_MODEL_NAME,
		"Generic Powernet SNMP device", SU_FLAG_STATIC | SU_FLAG_OK, NULL },
	{ INFO_SERIAL, FLAG_STRING, SU_INFOSIZE, APCC_OID_SERIAL, "",
		SU_FLAG_STATIC | SU_FLAG_OK, NULL },
	{ INFO_MFRDATE, FLAG_STRING, SU_INFOSIZE, APCC_OID_BATTDATE, "",
		SU_FLAG_OK | SU_FLAG_STATIC, NULL },
	{ INFO_UTILITY, 0, 1, APCC_OID_INVOLT, "", SU_FLAG_OK, NULL },
	{ INFO_BATTPCT, 0, 1, APCC_OID_BATT_CHARGE, "", SU_FLAG_OK, NULL },
	{ INFO_STATUS, FLAG_STRING, SU_INFOSIZE, APCC_OID_POWER_STATUS, "OFF",
		SU_FLAG_OK | SU_STATUS_PWR, &apcc_pwr_info[0] },
	{ INFO_STATUS, FLAG_STRING, SU_INFOSIZE, APCC_OID_BATT_STATUS, "",
		SU_FLAG_OK | SU_STATUS_BATT, &apcc_batt_info[0] },
	{ INFO_STATUS, FLAG_STRING, SU_INFOSIZE, APCC_OID_CAL_RESULTS, "",
		SU_FLAG_OK | SU_STATUS_CAL, NULL },
	{ INFO_STATUS, FLAG_STRING, SU_INFOSIZE, APCC_OID_NEEDREPLBATT, "",
		SU_FLAG_OK | SU_STATUS_RB, NULL },
	{ INFO_UPSTEMP, 0, 1, APCC_OID_UPSTEMP, "", SU_FLAG_OK, NULL },
	{ INFO_ACFREQ, 0, 1, APCC_OID_INFREQ, "", SU_FLAG_OK, NULL },
	{ INFO_LOADPCT, 0, 1, APCC_OID_LOADPCT, "", SU_FLAG_OK, NULL },
	{ INFO_FIRMREV, 0, 0, APCC_OID_FIRMREV, "",
		SU_FLAG_STATIC | SU_FLAG_OK, NULL },
	{ INFO_RUNTIME, 0, 1, APCC_OID_BATT_RUNTIME, "", SU_TYPE_TIME |  SU_FLAG_OK, NULL },
	/* can't find appropriate OID for INFO_BATTVOLT. */
	/*{ INFO_BATTVOLT, 0, 1, APCC_OID_BATT_VOLTAGE, "", SU_FLAG_OK, NULL },*/
	{ INFO_OUTVOLT, 0, 1, APCC_OID_OUTVOLT, "", SU_FLAG_OK, NULL },
	{ INFO_UPSIDENT, FLAG_STRING | FLAG_RW, 8, APCC_OID_UPSIDEN, "",
		SU_FLAG_OK | SU_FLAG_STATIC | SU_TYPE_STRING, NULL },
	{ INFO_BATTDATE, FLAG_STRING | FLAG_RW, 8, APCC_OID_MFRDATE, "",
		SU_FLAG_OK | SU_FLAG_STATIC | SU_TYPE_STRING, NULL },
	{ INFO_SLFTSTRES, FLAG_STRING, SU_INFOSIZE, APCC_OID_SLFTSTRES, "",
		SU_FLAG_OK, NULL },
	{ INFO_LOWXFER, FLAG_STRING | FLAG_RW, 3, APCC_OID_LOWXFER, "",
		SU_TYPE_INT | SU_FLAG_OK, NULL },
	{ INFO_HIGHXFER, FLAG_STRING | FLAG_RW, 3, APCC_OID_HIGHXFER, "",
		SU_TYPE_INT | SU_FLAG_OK, NULL },
	{ INFO_CURRENT, 0, 0, APCC_OID_OUTCURRENT, "", SU_FLAG_OK, NULL },
	{ INFO_REQVOLT, FLAG_STRING | FLAG_RW, 3, APCC_OID_REQOUTVOLT, "",
		SU_TYPE_INT | SU_FLAG_OK, NULL },
	{ INFO_WAKETHRSH, FLAG_STRING | FLAG_RW, 3, APCC_OID_RETCAPACITY, "",
		SU_TYPE_INT | SU_FLAG_OK, NULL },
	{ INFO_LINESENS, FLAG_STRING | FLAG_RW, 1, APCC_OID_SENS, "",
		SU_TYPE_INT | SU_FLAG_OK, NULL },
	{ INFO_GRACEDELAY, FLAG_STRING | FLAG_RW, 3, APCC_OID_GRACEDELAY, "",
		SU_TYPE_TIME | SU_FLAG_OK, NULL },
	{ INFO_WAKEDELAY, FLAG_STRING | FLAG_RW, 3, APCC_OID_RETDELAY, "",
		SU_TYPE_TIME | SU_FLAG_OK, NULL },
	{ INFO_LOBATTIME, FLAG_STRING | FLAG_RW, 3, APCC_OID_LOBATTIME, "",
		SU_TYPE_TIME | SU_FLAG_OK, NULL },

	/* instant commands. */
	{ CMD_OFF, 0, APCC_OFF_DO, APCC_OID_OFF, "", SU_FLAG_OK, NULL },
	{ CMD_ON, 0, APCC_ON_DO, APCC_OID_ON, "", SU_FLAG_OK, NULL },
	{ CMD_SHUTDOWN, 0, APCC_OFF_GRACEFUL, APCC_OID_OFF, "", SU_FLAG_OK, NULL },
	{ CMD_SDRET, 0, APCC_REBOOT_GRACEFUL, APCC_OID_REBOOT, "", SU_FLAG_OK, NULL },
	{ CMD_SOFTDOWN, 0, APCC_CONSERVE_DO, APCC_OID_CONSERVE, "", SU_FLAG_OK, NULL },
	{ CMD_SIMPWF, 0, APCC_SIMPWF_DO, APCC_OID_SIMPWF, "", SU_FLAG_OK, NULL },
	{ CMD_FPTEST, 0, APCC_FPTEST_DO, APCC_OID_FPTEST, "", SU_FLAG_OK, NULL },
	{ CMD_BYPASS, 0, APCC_BYPASS_ON, APCC_OID_BYPASS, "", SU_FLAG_OK, NULL },
	{ CMD_BTEST1, 0, APCC_SELFTEST_DO, APCC_OID_SELFTEST, "", SU_FLAG_OK, NULL },
	{ CMD_CAL0, 0, APCC_CAL_CANCEL, APCC_OID_CAL, "", SU_FLAG_OK, NULL },
	{ CMD_CAL1, 0, APCC_CAL_DO, APCC_OID_CAL, "", SU_FLAG_OK, NULL },

	/* end of structure. */
	{ INFO_UNUSED, 0, 0, NULL, NULL, 0, NULL }
};
