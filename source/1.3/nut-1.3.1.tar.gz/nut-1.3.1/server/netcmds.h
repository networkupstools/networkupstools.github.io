/* netcmds.h - upsd support structure details

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

static void do_sendver(struct sockaddr_in *dest, char *arg, char *rest);
static void do_sendans(struct sockaddr_in *dest, char *arg, char *rest);
static void do_sendhelp(struct sockaddr_in *dest, char *arg, char *rest);
static void do_listvars(struct sockaddr_in *dest, char *arg, char *rest);
static void do_logout(struct sockaddr_in *dest, char *arg, char *rest);
static void do_login(struct sockaddr_in *dest, char *arg, char *rest);
static void do_password(struct sockaddr_in *dest, char *arg, char *rest);
static void do_listrw(struct sockaddr_in *dest, char *arg, char *rest);
static void do_vartype(struct sockaddr_in *dest, char *arg, char *rest);
static void do_vardesc(struct sockaddr_in *dest, char *arg, char *rest);
static void do_enum(struct sockaddr_in *dest, char *arg, char *rest);
static void do_set(struct sockaddr_in *dest, char *arg, char *rest);
static void do_instcmd(struct sockaddr_in *dest, char *arg, char *rest);
static void do_listinstcmd(struct sockaddr_in *dest, char *arg, char *rest);
static void do_instcmddesc(struct sockaddr_in *dest, char *arg, char *rest);
static void do_fsd(struct sockaddr_in *dest, char *arg, char *rest);
static void do_master(struct sockaddr_in *dest, char *arg, char *rest);
static void do_username(struct sockaddr_in *dest, char *arg, char *rest);
void do_starttls(struct sockaddr_in *dest, char *arg, char *rest);

/* flags for the netcmds */

#define FLAG_TCP	0x0001		/* must be on a TCP connection      */
#define FLAG_USER	0x0002		/* requires valid username+password */
#define FLAG_CMD	0x0004		/* command must be allowed          */

/* netcmd levels */

                                /* 76543210 */
#define LEVEL_BASE      1       /* .......* */
#define LEVEL_MONITOR   3       /* ......** */
#define LEVEL_ALL       255     /* ******** */

/* netcmds[] - map net commands to functions */

struct {
	char	*name;
	void	(*func)(struct sockaddr_in *dest, char *arg, char *rest);
	int	flags;
	int	level;
}	netcmds[] =
{
	{ "VER",	do_sendver,	0,		LEVEL_BASE	},
	{ "HELP",	do_sendhelp,	0,		LEVEL_BASE	},

	{ "REQ",	do_sendans,	0,		LEVEL_MONITOR	},
	{ "LISTVARS",	do_listvars,	0,		LEVEL_MONITOR	},
	{ "LISTRW",	do_listrw,	0,		LEVEL_MONITOR	},
	{ "VARTYPE",	do_vartype,	0,		LEVEL_MONITOR	},
	{ "VARDESC",	do_vardesc,	0,		LEVEL_MONITOR	},
	{ "ENUM",	do_enum,	0,		LEVEL_MONITOR	},
	{ "LISTINSTCMD",do_listinstcmd,	0,		LEVEL_MONITOR	},
	{ "INSTCMDDESC",do_instcmddesc,	0,		LEVEL_MONITOR	},

	{ "LOGOUT", 	do_logout,	FLAG_TCP,	LEVEL_BASE	},
	{ "STARTTLS",	do_starttls,	FLAG_TCP,	LEVEL_BASE	},
	{ "USERNAME",	do_username,	FLAG_TCP,	LEVEL_BASE	},
	{ "PASSWORD",	do_password,	FLAG_TCP,	LEVEL_BASE	},

	/* things that authenticate through upsd.users */

	{ "LOGIN",	do_login,	FLAG_TCP|FLAG_USER,	LEVEL_MONITOR },
	{ "MASTER",	do_master,	FLAG_TCP|FLAG_USER,	LEVEL_MONITOR },

	{ "SET",	do_set,		FLAG_TCP|FLAG_USER,	LEVEL_MONITOR },
	{ "FSD",	do_fsd,		FLAG_TCP|FLAG_USER,	LEVEL_MONITOR },

	{ "INSTCMD",	do_instcmd,	FLAG_TCP|FLAG_USER|FLAG_CMD,	LEVEL_MONITOR },

	{ NULL,		(void(*)())(NULL), 0, 0	}
};
