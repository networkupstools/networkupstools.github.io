/* dummycons.c - a simple testing driver for the console

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

/* TODO: this may need to be much bigger */
#define INFO_MAX 64

#include "config.h"
#include "proto.h"
#include "shared.h"
#include "shared-tables.h"
#include "shared-tables-init.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"
#include "parseconf.h"
#include "dstate.h"
#include "extstate.h"

	int	info_max = INFO_MAX;
	PCONF_CTX	ctx;

static void initinfo(void)
{
	/* setup the basics */

	addinfo(INFO_MFR, "Console testing", 0, 0);
	addinfo(INFO_MODEL, "Dummy UPS", 0, 0);
	addinfo(INFO_STATUS, "OL", 0, 0);
}

#if 0
/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	/* TODO: future */
}
#endif

static void do_help(void)
{
	printf("\nNetwork UPS Tools dummycons %s help\n\n", UPS_VERSION);
	printf("? / h / help	- show this help\n");
	printf("a / add VAR VAL	- add variable VAR with value VAL\n");
	printf("ac CMD		- add command name CMD\n");
	printf("ae VAR ENUM	- add enum value ENUM to VAR\n");
	printf("d VAR		- delete variable VAR\n");
	printf("dc CMD		- delete command name CMD\n");
	printf("de VAR ENUM	- delete enum value ENUM from VAR\n");
	printf("l / list	- show current variables in use\n");
	printf("L / List	- show all possible variables and settings\n");
	printf("s / set VAR VAL - set variable VAR to VAL\n");
	printf("                  example: s STATUS OL\n");
	printf("sf VAR FLAG	- set flag FLAG on variable VAR\n");
	printf("q / quit	- quit\n");
	printf("\n");
	printf("Values can use \"quotes\" to store values with embedded spaces.\n");
	printf("Example: s status \"OL LB\"\n");
}

static void do_set(const char *var, const char *val)
{
	int	i;
	const	char	*dp = NULL;

	if ((!var) || (!val)) {
		printf("Error: need variable and desired values as arguments.\n");
		return;
	}

	for (i = 0; netvars[i].name != NULL; i++)
		if (!strcasecmp(netvars[i].name, var)) {
			dp = getdata(netvars[i].type);

			if (!dp) {
				printf("Error: %s doesn't exist yet.  (Use 'add' before calling set)\n",
					var);
				return;
			}

			printf("INFO_%s (%04X) = %s\n", 
				netvars[i].name, netvars[i].type, val);
			setinfo(netvars[i].type, "%s", val);
			return;
		}

	printf("Error: %s unrecognized.\n", var);
}

static void do_list(int all)
{
	int	i;
	const	char	*dp;
	char	vn[50];

	printf("\n");

	for (i = 0; netvars[i].name != NULL; i++) {
		dp = getdata(netvars[i].type);

		snprintf(vn, sizeof(vn), "INFO_%s (%s)", netvars[i].name,
			netvars[i].desc);

		if (!dp) {
			if (all) {
				printf("%-50s (%04X) = (undefined)\n",
					vn, netvars[i].type);
			}
		}
		else
			printf("%-50s (%04X) = %s\n", 
				vn, netvars[i].type, dp);
	}
}	

/* for future cleanup activities */
static void do_quit(void)
{
	pconf_finish(&ctx);

	exit(0);
}

static void do_add(const char *var, const char *val)
{
	int	i;

	if ((!var) || (!val)) {
		printf("Error: need variable and desired values as arguments.\n");
		return;
	}

	/* TODO: handle special types (enums, etc) */
	for (i = 0; netvars[i].name != NULL; i++) {
		if (!strcasecmp(netvars[i].name, var)) {
			addinfo(netvars[i].type, val, 0, 0);

			printf("INFO_%s (%04X) = %s\n", 
				netvars[i].name, netvars[i].type, val);
			return;
		}
	}

	printf("Error: variable name \"%s\" unrecognized.\n", var);
}

static void fake_shutdown(void)
{
	printf("dummycons: not a driver, nothing to shutdown...\n");
	exit(0);
}

static void help(const char *progname)
{
	printf("Dummy UPS driver - for testing and development\n\n");

	printf("usage: %s [-h]\n", progname);
	printf("       %s -k <portname>\n", progname);
	printf("       %s [-m <num>] [-k] <portname>\n\n", progname);

	printf("  -h		- display this help\n");
	printf("  -k		- fake a shutdown\n");
	printf("  -m <num>	- allow <num> items to be added\n");
	printf("  <portname>	- fake port name (for state file)\n");

	exit(0);
}

static int parse_args(int numargs, char **arg)
{
	if (numargs < 1)
		return 0;

	if ((!strcmp(arg[0], "q")) || (!strcmp(arg[0], "quit"))) {
		do_quit();
		/* NOTREACHED */
	}

	if ((!strcmp(arg[0], "l")) || (!strcmp(arg[0], "list"))) {
		do_list(0);
		return 1;
	}

	if ((!strcmp(arg[0], "L")) || (!strcmp(arg[0], "List"))) {
		do_list(1);
		return 1;
	}

	if ((!strcmp(arg[0], "h")) || (!strcmp(arg[0], "help")) ||
		(!strcmp(arg[0], "?"))) {
		do_help();
		return 1;
	}

	if ((!strcmp(arg[0], "d")) || (!strcmp(arg[0], "delete"))) {
		if (!dstate_delinfo(arg[1]))
			printf("Can't delete (%s) - not found\n", arg[1]);
		else
			printf("Deleted %s\n", arg[1]);

		return 1;
	}

	if ((!strcmp(arg[0], "ac")) || (!strcmp(arg[0], "addcmd"))) {
		dstate_addcmd(arg[1]);
		printf("Added cmd %s\n", arg[1]);
		return 1;
	}

	if ((!strcmp(arg[0], "dc")) || (!strcmp(arg[0], "delcmd"))) {
		if (!dstate_delcmd(arg[1]))
			printf("Can't delete cmd (%s) - not found\n", arg[1]);
		else
			printf("Deleted cmd %s\n", arg[1]);

		return 1;
	}

	if (numargs < 3)
		return 0;

	if ((!strcmp(arg[0], "s")) || (!strcmp(arg[0], "set"))) {
		do_set(arg[1], arg[2]);
		return 1;
	}

	if ((!strcmp(arg[0], "a")) || (!strcmp(arg[0], "add"))) {
		do_add(arg[1], arg[2]);
		return 1;
	}

	if ((!strcmp(arg[0], "de")) || (!strcmp(arg[0], "delenum"))) {
		if (!dstate_delenum(arg[1], arg[2]))
			printf("Can't delete enum (%s,%s) - not found\n", 
				arg[1], arg[2]);
		else
			printf("Deleted enum %s,%s\n", 
				arg[1], arg[2]);

		return 1;
	}

	if ((!strcmp(arg[0], "ae")) || (!strcmp(arg[0], "addenum"))) {
		if (!dstate_addenum(arg[1], "%s", arg[2]))
			printf("Can't add enum (%s,%s) - not found\n", 
				arg[1], arg[2]);
		else
			printf("Added enum %s,%s\n", 
				arg[1], arg[2]);

		return 1;
	}

	/* FIXME: this should accept multiple args */
	if ((!strcmp(arg[0], "sf")) || (!strcmp(arg[0], "setflags"))) {
		int	stflags;

		stflags = 0;

		if (!strcasecmp(arg[2], "RW"))
			stflags |= ST_FLAG_RW;

		if (!strcasecmp(arg[2], "STRING"))
			stflags |= ST_FLAG_STRING;

		dstate_setflags(arg[1], stflags);

		printf("Flags (%s) = %04x\n", arg[1], stflags);

		return 1;
	}

	return 0;
}

void dc_setvar(int auxcmd, int dlen, char *data)
{
	printf("SETVAR from socket: auxcmd=%d, dlen=%d, data [%s]\n",
		auxcmd, dlen, data);
}

void dc_instcmd(int auxcmd, int dlen, char *data)
{
	printf("INSTCMD from socket: auxcmd=%d\n", auxcmd);
}

int main(int argc, char **argv)
{
	int	res, i;
	char	buf[128], *portname, *prog;

	printf("Network UPS Tools - Dummy console UPS driver %s\n", UPS_VERSION);

	prog = argv[0];

	while ((i = getopt(argc, argv, "+hkm:")) != EOF) {
		switch(i) {
			case 'k':
				fake_shutdown();
				break;

			case 'm':
				info_max = atoi(optarg);
				break;

			case 'h':
				help(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	if (argc != 1)
		portname = "null";
	else
		portname = argv[0];

	printf("Socket: %s/dummycons-%s\n", STATEPATH, portname);

	droproot();
	initinfo();

	setup_signals();
	atexit(exit_cleanup);

	/* clear out callback handler data */
	memset(&upsh, '\0', sizeof(upsh));

	/* install dummy handlers for SET and INSTCMD */
	upsh.setvar = dc_setvar;
	upsh.instcmd = dc_instcmd;

	dstate_init("dummycons", portname);

	printf("\nCommand (? for help): ");
	fflush(stdout);

	pconf_init(&ctx, NULL);

	for (;;) {
		struct	timeval	tv;
		fd_set	rfd;		

		tv.tv_sec = 2;
		tv.tv_usec = 0;
		FD_ZERO(&rfd);
		FD_SET(fileno(stdin), &rfd);

		res = select(fileno(stdin) + 1, &rfd, NULL, NULL, &tv);

		if (res < 0)
			fatal("select");

		/* FIXME - this should be checked in a single select above */
		dstate_poll_fds(0);

		/* idle loop */
		if (res == 0)
			continue;

		fgets(buf, sizeof(buf), stdin);

		/* split into usable chunks */
		if (pconf_line(&ctx, buf)) {
			if (pconf_parse_error(&ctx))
				printf("Parse error: %s\n", ctx.errmsg);
			else {
				
				if (!parse_args(ctx.numargs, ctx.arglist))
					printf("Unrecognized command\n");
			}
		}

		printf("\nCommand (? for help): ");
		fflush(stdout);

	}	/* for (;;) */
}
