/* netinstcmd.c - INSTCMD handler for upsd

   Copyright (C) 2003  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include "common.h"

#include "upstype.h"
#include "upsd.h"
#include "sstate.h"
#include "state.h"

#include "user.h"			/* for user_checkinstcmd */

static void send_instcmd(ctype *client, const char *upsname, 
	const char *cmdname)
{
	int	found;
	upstype	*ups;
	const	struct  cmdlist_t  *ctmp;
	char	sockcmd[SMALLBUF];

	ups = get_ups_ptr(upsname);

	if (!ups) {
		sendback(client, "ERR UNKNOWN-UPS\n");
		return;
	}

	if (!ups_available(ups, client))
		return;

	ctmp = sstate_getcmdlist(ups);

	found = 0;

	while (ctmp) {
		if (!strcasecmp(ctmp->name, cmdname)) {
			found = 1;
			break;
		}

		ctmp = ctmp->next;
	}

	if (!found) {
		sendback(client, "ERR CMD-NOT-SUPPORTED\n");
		return;
	}

	/* see if this user is allowed to do this command */
	if (!user_checkinstcmd(&client->sock, client->username, 
		client->password, cmdname)) {
		sendback(client, "ERR ACCESS-DENIED\n");
		return;
	}

	upslogx(LOG_INFO, "Instant command: %s@%s did %s on %s",
	       client->username, client->addr, cmdname, 
	       ups->name);

	snprintf(sockcmd, sizeof(sockcmd), "INSTCMD %s\n", cmdname);

	if (sstate_sendline(ups, sockcmd)) {
		sendback(client, "OK\n");
	} else {
		upslogx(LOG_INFO, "Set command send failed");
		sendback(client, "ERR INSTCMD-FAILED\n");
	}
}

int net_instcmd(ctype *client, int numarg, char **arg)
{
	if (numarg < 2) {

		/* can't do this until 2.0 - backwards compatibilty */
		/* sendback(client, "ERR INVALID-ARGUMENT\n"); */

		return 0;	/* not handled - fall through */
	}

	/* the old way only had one arg, so 2 args is for us */

	send_instcmd(client, arg[0], arg[1]);
	return 1;	/* handled */
}
