/* dummycons.c - a simple testing driver for the console

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

/* TODO: this may need to be much bigger */
#define INFO_MAX 64

#include "config.h"
#include "proto.h"
#include "shared.h"
#include "shared-tables.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"
#include "parseconf.h"

	int	info_max = INFO_MAX;
	PCONF_CTX	ctx;

static void initinfo(void)
{
	create_info(info_max, 1);

	/* setup the basics */

	addinfo(INFO_MFR, "Console testing", 0, 0);
	addinfo(INFO_MODEL, "Dummy UPS", 0, 0);
	addinfo(INFO_STATUS, "OL", 0, 0);

	info_ready();
}

#if 0
/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	/* TODO: future */
}
#endif

static void do_help(void)
{
	printf("\nNetwork UPS Tools dummycons %s help\n\n", UPS_VERSION);
	printf("? / h / help	- show this help\n");
	printf("a / add VAR VAL	- add variable VAR with value VAL\n");
	printf("l / list	- show current variables in use\n");
	printf("L / List	- show all possible variables and settings\n");
	printf("s / set VAR VAL - set variable VAR to VAL\n");
	printf("                  example: s STATUS OL\n");
	printf("q / quit	- quit\n");
	printf("\n");
	printf("Values can use \"quotes\" to store values with embedded spaces.\n");
	printf("Example: s status \"OL LB\"\n");
}

static void do_set(const char *var, const char *val)
{
	int	i;
	char	*dp = NULL;

	if ((!var) || (!val)) {
		printf("Error: need variable and desired values as arguments.\n");
		return;
	}

	for (i = 0; netvars[i].name != NULL; i++)
		if (!strcasecmp(netvars[i].name, var)) {
			dp = getdata(netvars[i].type);

			if (!dp) {
				printf("Error: %s doesn't exist yet.  (Use 'add' before calling set)\n",
					var);
				return;
			}

			printf("INFO_%s = %s\n", netvars[i].name, val);
			setinfo(netvars[i].type, "%s", val);
			return;
		}

	printf("Error: %s unrecognized.\n", var);
}

static void do_list(int all)
{
	int	i;
	char	*dp, vn[50];

	printf("\n");

	for (i = 0; netvars[i].name != NULL; i++) {
		dp = getdata(netvars[i].type);

		snprintf(vn, sizeof(vn), "INFO_%s (%s)", netvars[i].name,
			netvars[i].desc);

		if (!dp) {
			if (all) {
				printf("%-50s = (undefined)\n", vn);
			}
		}
		else
			printf("%-50s = %s\n", vn, dp);
	}
}	

/* for future cleanup activities */
static void do_quit(void)
{
	pconf_finish(&ctx);

	exit(0);
}

static void do_add(const char *var, const char *val)
{
	int	i;

	if ((!var) || (!val)) {
		printf("Error: need variable and desired values as arguments.\n");
		return;
	}

	/* TODO: handle special types (enums, etc) */
	for (i = 0; netvars[i].name != NULL; i++) {
		if (!strcasecmp(netvars[i].name, var)) {
			addinfo(netvars[i].type, val, 0, 0);
			printf("INFO_%s = %s\n", netvars[i].name, val);
			return;
		}
	}

	printf("Error: variable name \"%s\" unrecognized.\n", var);
}

static void fake_shutdown(void)
{
	printf("dummycons: not a driver, nothing to shutdown...\n");
	exit(0);
}

static void help(const char *progname)
{
	printf("Dummy UPS driver - for testing and development\n\n");

	printf("usage: %s [-h]\n", progname);
	printf("       %s -k <portname>\n", progname);
	printf("       %s [-m <num>] [-k] <portname>\n\n", progname);

	printf("  -h		- display this help\n");
	printf("  -k		- fake a shutdown\n");
	printf("  -m <num>	- allow <num> items to be added\n");
	printf("  <portname>	- fake port name (for state file)\n");

	exit(0);
}

static int parse_args(int numargs, char **arg)
{
	if (numargs < 1)
		return 0;

	if ((!strcmp(arg[0], "q")) || (!strcmp(arg[0], "quit"))) {
		do_quit();
		return 1;
	}

	if ((!strcmp(arg[0], "l")) || (!strcmp(arg[0], "list"))) {
		do_list(0);
		return 1;
	}

	if ((!strcmp(arg[0], "L")) || (!strcmp(arg[0], "List"))) {
		do_list(1);
		return 1;
	}

	if ((!strcmp(arg[0], "h")) || (!strcmp(arg[0], "help")) ||
		(!strcmp(arg[0], "?"))) {
		do_help();
		return 1;
	}

	if (numargs < 3)
		return 0;

	if ((!strcmp(arg[0], "s")) || (!strcmp(arg[0], "set"))) {
		do_set(arg[1], arg[2]);
		return 1;
	}

	if ((!strcmp(arg[0], "a")) || (!strcmp(arg[0], "add"))) {
		do_add(arg[1], arg[2]);
		return 1;
	}

	return 0;
}

int main(int argc, char **argv)
{
	int	res, i;
	char	buf[128], *portname, *prog;

	printf("Network UPS Tools - Dummy console UPS driver %s\n", UPS_VERSION);

	prog = argv[0];

	while ((i = getopt(argc, argv, "+hkm:")) != EOF) {
		switch(i) {
			case 'k':
				fake_shutdown();
				break;

			case 'm':
				info_max = atoi(optarg);
				break;

			case 'h':
				help(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	if (argc != 1)
		portname = "null";
	else
		portname = argv[0];

	snprintf(statefn, sizeof(statefn), "%s/dummycons-%s", STATEPATH, portname);

	printf("State file: %s\n", statefn);

	droproot();
	initinfo();

	printf("\nCommand (? for help): ");
	fflush(stdout);

	pconf_init(&ctx, NULL);

	for (;;) {
		struct	timeval	tv;
		fd_set	rfd;		

		tv.tv_sec = 2;
		tv.tv_usec = 0;
		FD_ZERO(&rfd);
		FD_SET(fileno(stdin), &rfd);

		res = select(fileno(stdin) + 1, &rfd, NULL, NULL, &tv);

		if (res < 0)
			fatal("select");

		/* idle loop */
		if (res == 0) {
			writeinfo();
			continue;
		}

		fgets(buf, sizeof(buf), stdin);

		/* split into usable chunks */
		if (pconf_line(&ctx, buf)) {
			if (pconf_parse_error(&ctx))
				printf("Parse error: %s\n", ctx.errmsg);
			else {
				
				if (!parse_args(ctx.numargs, ctx.arglist))
					printf("Unrecognized command\n");
			}
		}

		writeinfo();

		printf("\nCommand (? for help): ");
		fflush(stdout);

	}	/* for (;;) */
}
