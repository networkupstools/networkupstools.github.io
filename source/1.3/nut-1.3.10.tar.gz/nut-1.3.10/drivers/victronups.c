/*
 *
 *  newvictron.c - Model specific routines for IMV/Victron  units
 *  Match, Match Lite, NetUps
 *  Revision 0.1.1
 *           
 * Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>
 * Copyright (C) 2000  Radek Benedikt <benedikt@lphard.cz>
 * old style "victronups"
 * Copyright (C) 2001  Daniel.Prynych <Daniel.Prynych@hornet.cz>
 * porting to now style "newvictron"
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *                                       
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *                                       
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 */

#define DRV_VERSION "0.1.2"

#include "main.h"

#define ENDCHAR	'\r'
#define IGNCHARS	""

#define UPS_DELAY 150000
#define UPS_LONG_DELAY 450000

#define VICTRON_OVER 128
#define VICTRON_RB 1
#define VICTRON_OB 2
#define VICTRON_LB 4

int  sdwdelay = 0;  /* shutdown after 0 second */

extern  int     sddelay; /* doba po kterou ceka driver po vypnuti ups */
extern  char    upssend_endchar;
extern  int     upsc_debug;
char *model_name;

 
void upsdrv_initinfo(void)
{
	dstate_setinfo("ups.mfr", "Victron");
	if (!model_name)
		dstate_setinfo("ups.model", "Unknown");
	else
		dstate_setinfo("ups.model", "%s", model_name);

	dstate_setinfo("input.transfer.low", "187");
	dstate_setinfo("input.transfer.high", "264");

	/* upsh.instcmd = instcmd; */

	dstate_setinfo("driver.version.internal", "%s", DRV_VERSION);
}

void upsdrv_updateinfo(void)
{
	 int flags; 
	 char temp[256]; 

	/* status */ 
   upssend ("vAa?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   flags = atoi (temp+3);

   status_init();

   if (flags & VICTRON_OVER)
	status_set("OVER");

   if (flags & VICTRON_RB)
	status_set("RB");

   if (flags & VICTRON_LB)
	status_set("LB");

   if (flags & VICTRON_LB)
	status_set("OB");
   else
	status_set("OL");

   status_commit();

   upsdebugx(1, "ups.status = %s", dstate_getinfo("ups.status"));
   
   /* input voltage */
   upssend ("vI0U?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("input.voltage", "%s", temp+4);
   upsdebugx(1, "input.voltage >%s<>%s<",temp,temp+4);   

                                                                               
   /* ups load percent */
   upssend ("vO0L?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("ups.load", "%s", temp+4);
   upsdebugx(1, "ups.load >%s<>%s<\n",temp,temp+4);   
                                                                                                                                                          
   /* ups temp */
   upssend ("vBT?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("ups.temperature", "%s", temp+3);
   upsdebugx(1, "ups.temperature >%s<>%s<\n",temp,temp+3);   

   /* battery charge */
   upssend ("vBC?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("battery.charge", "%s", temp+3);
   upsdebugx(1, "battery.charge >%s<>%s<\n",temp,temp+3);   
                                                                    
   /* input freq */
   upssend ("vI0f?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("input.frequency", "%2.1f", atof(temp+4) / 10.0);
   upsdebugx(1, "input.frequency >%s<>%s<\n",temp,temp+4);   
                                                                                                                                            
   /* battery voltage */
   upssend ("vBU?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("battery.voltage", "%2.1f", atof(temp+3) / 10.0);
   upsdebugx(1, "battery.voltage >%s<>%s<\n",temp,temp+3);   
                                                                                                                                                                                                         
   /* output voltage */
   upssend ("vO0U?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("output.voltage", "%s", temp+4);
   upsdebugx(1, "output.voltage >%s<>%s<\n",temp,temp+4);   

   /* output current */
   upssend ("vO0I?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("output.current", "%2.1f", atof(temp+4) / 10.0);
   upsdebugx(1, "output.current >%s<>%s<\n",temp,temp+4);   
        
   /* predicted runtime on batt */
   upssend ("vBt?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("battery.runtime", "%s", temp+3);
   upsdebugx(1, "battery.runtime >%s<>%s<\n",temp,temp+3);   


   /* battery temperature */
   upssend ("vBT?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("battery.temperature", "%s", temp+3);
   upsdebugx(1, "battery.temperature >%s<>%s<\n",temp,temp+3);   


   /* battery current */
   upssend ("vBI?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   dstate_setinfo("battery.current", "%2.1f", atof(temp+4) / 10.0);
   upsdebugx(1, "battery.current >%s<>%s<\n",temp,temp+4);   

}

void upsdrv_shutdown(void)
{
    upssend ("vCc0!");
    usleep (UPS_DELAY);
                 
    upssend ("vCb%i!",sdwdelay);
}


void instcmd (int auxcmd, int dlen, char *data)
{
	/* TODO: reply to upsd? */

	switch (auxcmd) {
		/* case CMD_BTEST0:	* stop battery test *
		 *	upssend("???");
		 *	break;
		 * case CMD_BTEST1:	* start battery test *
		 *	upssend("???");
		 *	break;
		 */
		default:
			upslogx(LOG_INFO, "instcmd: unknown type 0x%04x", auxcmd);
	}
}


void upsdrv_help(void)
{
}

/* list flags and values that you want to receive via -x */
void upsdrv_makevartable(void)
{
   addvar(VAR_VALUE, "usd", "Seting delay before shutdown");
   addvar(VAR_VALUE, "modelname", "Seting model name"); 
}

void upsdrv_banner(void)
{
	printf("Network UPS Tools - New Victron UPS driver %s (%s)\n\n",
		DRV_VERSION, UPS_VERSION);
}

void upsdrv_initups(void)
{
   char temp[256], *usd = NULL;  /* = NULL je dulezite jen pro prekladac */

	/* this driver doesn't do sanity checks in upsdrv_updateinfo */
	broken_driver = 1;
	return;

   upssend_endchar=ENDCHAR;
   if (nut_debug_level > 1) upsc_debug = nut_debug_level - 1; /* docasne reseni */
   
   upssend_delay = 0; /* zpozdeni mezi odeslanim jednotlivych znaku bude 0 sec */ 
	  open_serial(device_path, B1200); 

    /* vyzkousime novy typ otevreni serioveho port
     * ze souboru upscommon.c */
    
    if ((usd = getval("usd"))) sdwdelay=atoi(usd);
       
    model_name = getval("modelname"); /* kdyz modelname nebylo zadano je vraceno NULL*/ 

    upsdebugx(1, "(-x) Delay before shutdown %i",sdwdelay);
    upsdebugx(1, "(-x) UPS Name %s",model_name);
    
   /* inicializace a synchronizace UPS */

   upssendchar (ENDCHAR);
   usleep (UPS_LONG_DELAY);
   upssend ("?");
   usleep (UPS_LONG_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   upssend ("?");
   usleep (UPS_LONG_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
   upssend ("?");
   usleep (UPS_DELAY);
   upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

    
	/* the upsh handlers can't be done here, as they get initialized
	 * shortly after upsdrv_initups returns to main.
	 */
}

void upsdrv_cleanup(void)
{
}
