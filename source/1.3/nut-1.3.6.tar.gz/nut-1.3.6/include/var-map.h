/* var-map.h - translate between old INFO #defines and new names */

struct var_map_t {
	int	type;
	char	*old;
	char	*name;
};
