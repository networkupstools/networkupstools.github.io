/*  mgemib.h - data to monitor MGE UPS SYSTEMS SNMP devices with NUT
 *
 *  Copyright (C) 2002-2003 
 *  			Dmitry Frolov <frolov@riss-telecom.ru>
 *  			Arnaud Quette <arnaud.quette@free.fr>
 *
 *  data structure and processing principles are inspired by:
 *            Hans Ekkehard Plesser <hans.plesser@itf.nlh.no>
 *
 *  Sponsored by MGE UPS SYSTEMS <http://www.mgeups.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#define MGE_MIB_VERSION	"0.1"

/* SNMP OIDs set */
#define MGE_OID_UPS_MIB			".1.3.6.1.4.1.705"
#define MGE_OID_MODEL_NAME		".1.3.6.1.4.1.705.1.1.1"
#define MGE_OID_ONBATT_STATUS	".1.3.6.1.4.1.705.1.7.3"
#define MGE_ONBATT		1
#define MGE_NOT_ONBATT	2

info_lkp_t mge_onbatt_info[] = {
	{ MGE_ONBATT, "OB" },
	{ MGE_NOT_ONBATT, "OL" },
	{ 0, "\0" }
};
#define MGE_OID_OVERBATT_STATUS	".1.3.6.1.4.1.705.1.7.10"
#define MGE_BATT_OVERLOAD		1
#define MGE_NOT_BATT_OVERLOAD	2

info_lkp_t mge_overbatt_info[] = {
	{ MGE_BATT_OVERLOAD, "OVER" },
	{ MGE_NOT_BATT_OVERLOAD, "" },
	{ 0, "\0" }
};

#define MGE_OID_BATT_RUNTIME 	".1.3.6.1.4.1.705.1.5.1"
#define MGE_OID_SERIAL			".1.3.6.1.4.1.705.1.1.7"
#define MGE_OID_LOBATTPCT		".1.3.6.1.4.1.705.1.4.8"

/* Snmp2NUT lookup table */

snmp_info_t mge_mib[] = {
	
	/* info elements. */
	{ INFO_MFR, FLAG_STRING, SU_INFOSIZE, NULL, "MGE UPS SYSTEMS",
		SU_FLAG_STATIC | SU_FLAG_ABSENT | SU_FLAG_OK, NULL },
	{ INFO_MODEL, FLAG_STRING, SU_INFOSIZE, MGE_OID_MODEL_NAME,
		"Generic SNMP UPS", SU_FLAG_STATIC | SU_FLAG_OK, NULL },
	{ INFO_SERIAL, FLAG_STRING, SU_INFOSIZE, MGE_OID_SERIAL, "",
		SU_FLAG_STATIC | SU_FLAG_OK, NULL },
	{ INFO_STATUS, FLAG_STRING, SU_INFOSIZE, MGE_OID_ONBATT_STATUS, "",
		SU_FLAG_OK | SU_STATUS_BATT, &mge_onbatt_info[0] },
	{ INFO_RUNTIME, 0, 1, MGE_OID_BATT_RUNTIME, "", SU_TYPE_TIME | SU_FLAG_OK, NULL },
	{ INFO_LOBATTPCT, FLAG_STRING | FLAG_RW, 2, MGE_OID_LOBATTPCT, "",
		SU_TYPE_INT | SU_FLAG_OK, NULL },	
	
	/* instant commands. */

	/* end of structure. */
	{ INFO_UNUSED, 0, 0, NULL, NULL, 0, NULL }
};
