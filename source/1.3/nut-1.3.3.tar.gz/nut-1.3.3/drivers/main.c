/* main.c - Network UPS Tools driver core

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include "main.h"
#include "dstate.h"

	unsigned int sddelay = 90;	/* wait 90 seconds for shutdown */
	const char *progname = NULL, *upsname = NULL;
	const char *device_name = NULL, *device_path = NULL;
	const char *statepath = NULL;
	int	do_forceshutdown = 0;
	vartab_t	*vartab_h = NULL;
	int	experimental_driver = 0;

	/* stuff from upscommon */
	extern	int	do_lock_port;
	extern	char	*pidfn;

	/* stuff from common */
	extern	int	upslog_flags;

	/* for detecting -a values that don't match anything */
	int	upsname_found = 0;

/* power down the attached load immediately */
static void forceshutdown(void)
{
	upslogx(LOG_NOTICE, "Initiating UPS shutdown");
	printf("Initiating forced UPS shutdown!\n");

	upsdrv_shutdown();

	if (sddelay > 0) {
		printf("Waiting for poweroff...\n");
		sleep(sddelay);
		printf("Hmm, did the shutdown fail?  Oh well...\n");
		exit(1);
	}
	exit(0);
}

static void help(void)
{
	vartab_t	*tmp;

	printf("\nusage: %s [OPTIONS] [<device>]\n\n", progname);

	printf(
		"  -a <id>        - autoconfig using ups.conf section <id>\n"
		"  -d <num>       - wait <num> seconds after sending shutdown command\n"
		"                 - note: -x and -d after -a override ups.conf settings\n"
		"  -D             - raise debugging level\n"
		"  -h             - display this help\n"
		"  -k             - force shutdown\n"
		"  -r <dir>       - chroot to <dir>\n"
		"  -u <user>      - switch to <user> (if started as root)\n"
		"  -x <var>=<val> - set driver variable <var> to <val>\n"
		"                 - example: -x cable=940-0095B\n"
		"\n"
		"  <device>       - /dev entry corresponding to UPS port\n"
		"                 - Only optional when using -a!\n"
		"\n");

	if (vartab_h) {
		tmp = vartab_h;

		printf("Acceptable values for -x in this driver:\n\n");

		while (tmp) {
			if (tmp->vartype == VAR_VALUE)
				printf("%40s : -x %s=<value>\n", 
				       tmp->desc, tmp->var);
			else
				printf("%40s : -x %s\n", tmp->desc, tmp->var);
			tmp = tmp->next;
		}
	}

	upsdrv_help();
	exit(1);
}

/* cram var [= <val>] data into storage */
static void storeval(const char *var, char *val)
{
	vartab_t	*tmp, *last;

	tmp = last = vartab_h;

	while (tmp) {
		last = tmp;

		/* sanity check */
		if (!tmp->var) {
			tmp = tmp->next;
			continue;
		}

		/* later definitions overwrite earlier ones */
		if (!strcasecmp(tmp->var, var)) {
			if (tmp->val)
				free(tmp->val);

			if (val)
				tmp->val = xstrdup(val);

			tmp->found = 1;
			return;
		}

		tmp = tmp->next;
	}

	printf("Error: -x %s is not valid for this driver.\n\n", var);
	help();
}

/* retrieve the value of variable <var> if possible */
char *getval(const char *var)
{
	vartab_t	*tmp = vartab_h;

	while (tmp) {
		if (!strcasecmp(tmp->var, var))
			return(tmp->val);
		tmp = tmp->next;
	}

	return NULL;
}

/* see if <var> has been defined, even if no value has been given to it */
int testvar(const char *var)
{
	vartab_t	*tmp = vartab_h;

	while (tmp) {
		if (!strcasecmp(tmp->var, var))
			return tmp->found;
		tmp = tmp->next;
	}

	return 0;	/* not found */
}

/* callback from driver - create the table for -x/conf entries */
void addvar(int vartype, const char *name, const char *desc)
{
	vartab_t	*tmp, *last;

	tmp = last = vartab_h;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = xmalloc(sizeof(vartab_t));

	tmp->vartype = vartype;
	tmp->var = xstrdup(name);
	tmp->val = NULL;
	tmp->desc = xstrdup(desc);
	tmp->found = 0;
	tmp->next = NULL;

	if (last)
		last->next = tmp;
	else
		vartab_h = tmp;
}	

/* handle -x / ups.conf config details that are for this part of the code */
static int main_arg(char *var, char *val)
{
	/* flags for main: just 'nolock' for now */

	if (!strcmp(var, "nolock")) {
		do_lock_port = 0;
		return 1;	/* handled */
	}

	/* any other flags are for the driver code */
	if (!val)
		return 0;

	/* variables for main: port and sddelay */

	if (!strcmp(var, "port")) {
		device_path = xstrdup(val);
		device_name = xbasename(device_path);
		return 1;	/* handled */
	}

	if (!strcmp(var, "sddelay")) {
		sddelay = atoi(val);
		return 1;	/* handled */
	}

	/* only for upsdrvctl - ignored here */
	if (!strcmp(var, "sdorder"))
		return 1;	/* handled */

	return 0;	/* unhandled, pass it through to the driver */
}

void do_upsconf_args(char *confupsname, char *var, char *val)
{
	/* ignore global stuff in here */
	if (!confupsname)
		return;

	/* no match = not for us */
	if (strcmp(confupsname, upsname) != 0)
		return;

	upsname_found = 1;

	if (main_arg(var, val))
		return;

	/* flags (no =) now get passed to the driver-level stuff */
	if (!val) {
		storeval(var, NULL);
		return;
	}

	/* don't let the user shoot themselves in the foot */
	if (!strcmp(var, "driver")) {
		if (strcmp(val, progname) != 0)
			fatalx("Error: UPS [%s] is for driver %s, but I'm %s!\n",
				confupsname, val, progname);
		return;
	}

	/* everything else must be for the driver */

	storeval(var, val);
}

/* split -x foo=bar into 'foo' and 'bar' */
static void splitxarg(char *inbuf)
{
	char	*eqptr, *val, *buf;

	/* make our own copy - avoid changing argv */
	buf = xstrdup(inbuf);

	eqptr = strchr(buf, '=');

	if (!eqptr)
		val = NULL;
	else {
		*eqptr++ = '\0';
		val = eqptr;
	}

	/* see if main handles this first */
	if (main_arg(buf, val))
		return;

	/* otherwise store it for later */
	storeval(buf, val);
}

/* special version to deal with the nasty sync issues in here */
static void main_background(void)
{
	int	pid;

	if ((pid = fork()) < 0)
		fatal("Unable to enter background");

	xbit_set(&upslog_flags, UPSLOG_SYSLOG);
	xbit_clear(&upslog_flags, UPSLOG_STDERR);

	close(0);
	close(1);
	close(2);

	if (pid != 0)		/* parent */
		exit(0);

	/* child */

	/* make fds 0-2 point somewhere defined */
	if (open("/dev/null", O_RDWR) != 0)
		fatal("open /dev/null");
	dup(0);
	dup(0);

#ifdef HAVE_SETSID
	setsid();		/* make a new session to dodge signals */
#endif

	upslogx(LOG_INFO, "Startup successful");
}

/* dump the list from the vartable for external parsers */
void listxarg(void)
{
	vartab_t	*tmp;

	tmp = vartab_h;

	if (!tmp)
		return;

	while (tmp) {

		switch (tmp->vartype) {
			case VAR_VALUE: printf("VALUE"); break;
			case VAR_FLAG: printf("FLAG"); break;
			default: printf("UNKNOWN"); break;
		}

		printf(" %s \"%s\"\n", tmp->var, tmp->desc);

		tmp = tmp->next;
	}
}

int main(int argc, char **argv)
{
	char	*chroot_path = NULL, *user = NULL;
	struct	passwd	*new_uid = NULL;
	int	i;

	/* pick up a default from configure --with-user */
	user = RUN_AS_USER;

	upsdrv_banner();

	if (experimental_driver) {
		printf("Warning: This is an experimental driver.\n");
		printf("Some features may not function correctly.\n\n");
	}

	progname = xbasename(argv[0]);
	open_syslog(progname);

	if ((statepath = getenv("NUT_STATEPATH")) == NULL)
		statepath = STATEPATH;

	/* build the driver's extra (-x) variable table */
	upsdrv_makevartable();

	while ((i = getopt(argc, argv, "+a:d:kDhx:Lr:u:V")) != EOF) {
		switch (i) {
			case 'a':
				upsname = optarg;

				read_upsconf(1);

				if (!upsname_found)
					upslogx(LOG_WARNING, "Warning: Section %s not found in ups.conf",
						optarg);
				break;
			case 'd':
				sddelay = atoi(optarg);
				break;
			case 'D':
				nut_debug_level++;
				break;
			case 'k':
				do_lock_port = 0;
				do_forceshutdown = 1;
				break;
			case 'L':
				listxarg();
				exit(0);
			case 'r':
				chroot_path = optarg;
				break;
			case 'u':
				user = optarg;
				break;
			case 'V':
				/* already printed the banner, so exit */
				exit(0);
			case 'x':
				splitxarg(optarg);
				break;
			case 'h':
			default:
				help();
				break;
		}
	}

	argc -= optind;
	argv += optind;
	optind = 1;

	/* we need to get the port from somewhere */
	if (argc < 1) {
		if (!device_path) {
			fprintf(stderr, "Error: You must specify a port name in ups.conf or on the command line.\n");
			help();
		}
	}

	/* allow argv to override the ups.conf entry if specified */
	else {
		device_path = argv[0];
		device_name = xbasename(device_path);
	}

	pidfn = xmalloc(SMALLBUF);
	snprintf(pidfn, SMALLBUF, "%s/%s-%s.pid", 
		ALTPIDPATH, progname, device_name);

	upsdebugx(1, "debug level is '%d'", nut_debug_level);

	upsdrv_initups();

	if (do_forceshutdown)
		forceshutdown();

	if ((new_uid = get_user_pwent(user)) == NULL)
		fatal("getpwnam(%s)", user);
	
	if (chroot_path)
		chroot_start(chroot_path);

	become_user(new_uid);

	if (chdir(statepath))
		fatal("Can't chdir to %s", statepath);

	setup_signals();

	/* clear out callback handler data */
	memset(&upsh, '\0', sizeof(upsh));

	/* get the base data established before allowing connections */
	upsdrv_initinfo();
	upsdrv_updateinfo();

	/* now we can start servicing requests */
        dstate_init(progname, device_name);

	if (nut_debug_level == 0) {
		main_background();
		writepid(pidfn);
	}

	/* safe to do this now that the parent has exited */
	atexit(exit_cleanup);

	for (;;) {
		upsdrv_updateinfo();

		/* XXX: make this delay configurable */
		dstate_poll_fds(2);
	}

	/* NOTREACHED */
	return 0;
}
