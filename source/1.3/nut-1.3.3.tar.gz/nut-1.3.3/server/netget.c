/* netget.c - GET handlers for upsd

   Copyright (C) 2003  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include "common.h"

#include "upstype.h"
#include "upsd.h"
#include "sstate.h"
#include "state.h"

static void get_numlogins(ctype *client, const char *upsname)
{
	const	upstype	*ups;

	ups = get_ups_ptr(upsname);

	if (!ups) {
		sendback(client, "ERR UNKNOWN-UPS\n");
		return;
	}

	sendback(client, "NUMLOGINS %s %d\n", upsname, ups->numlogins);
}

static void get_desc(ctype *client, const char *upsname, const char *var)
{
	const	upstype	*ups;

	ups = get_ups_ptr(upsname);

	if (!ups) {
		sendback(client, "ERR UNKNOWN-UPS\n");
		return;
	}

	/* XXX write me */
	sendback(client, "DESC %s %s \"Unavailable\"\n", upsname, var);
}

static void get_cmddesc(ctype *client, const char *upsname, const char *cmd)
{
	const	upstype	*ups;

	ups = get_ups_ptr(upsname);

	if (!ups) {
		sendback(client, "ERR UNKNOWN-UPS\n");
		return;
	}

	/* XXX write me */
	sendback(client, "CMDDESC %s %s \"Unavailable\"\n", upsname, cmd);
}

static void get_type(ctype *client, const char *upsname, const char *var)
{
	const	upstype	*ups;
	const	struct	st_tree_t	*node;

	ups = get_ups_ptr(upsname);

	if (!ups) {
		sendback(client, "ERR UNKNOWN-UPS\n");
		return;
	}

	node = sstate_getnode(ups, var);

	if (!node) {
		sendback(client, "ERR VAR-NOT-SUPPORTED\n");
		return;
	}

	if (node->enum_list) {
		sendback(client, "TYPE %s %s ENUM\n", upsname, var);
		return;
	}

	if (node->flags & ST_FLAG_STRING) {
		sendback(client, "TYPE %s %s STRING %d\n", 
			upsname, var, node->aux);
		return;
	}

	/* hmm... */

	sendback(client, "TYPE %s %s UNKNOWN\n", upsname, var);
}		

static void get_var(ctype *client, const char *upsname, const char *var)
{
	const	upstype	*ups;
	const	char	*val;

	ups = get_ups_ptr(upsname);

	if (!ups) {
		sendback(client, "ERR UNKNOWN-UPS\n");
		return;
	}

	val = sstate_getinfo(ups, var);

	if (!val) {
		sendback(client, "ERR VAR-NOT-SUPPORTED\n");
		return;
	}

	sendback(client, "VAR %s %s \"%s\"\n", upsname, var, val);
}

void net_get(ctype *client, int numarg, char **arg)
{
	if (numarg < 2) {
		sendback(client, "ERR INVALID-ARGUMENT\n");
		return;
	}

	/* GET NUMLOGINS UPS */
	if (!strcasecmp(arg[0], "NUMLOGINS")) {
		get_numlogins(client, arg[1]);
		return;
	}

	if (numarg < 3) {
		sendback(client, "ERR INVALID-ARGUMENT\n");
		return;
	}

	/* GET VAR UPS VARNAME */
	if (!strcasecmp(arg[0], "VAR")) {
		get_var(client, arg[1], arg[2]);
		return;
	}

	/* GET TYPE UPS VARNAME */
	if (!strcasecmp(arg[0], "TYPE")) {
		get_type(client, arg[1], arg[2]);
		return;
	}

	/* GET DESC UPS VARNAME */
	if (!strcasecmp(arg[0], "DESC")) {
		get_desc(client, arg[1], arg[2]);
		return;
	}

	/* GET CMDDESC UPS CMDNAME */
	if (!strcasecmp(arg[0], "CMDDESC")) {
		get_cmddesc(client, arg[1], arg[2]);
		return;
	}

	sendback(client, "ERR INVALID-ARGUMENT\n");
}
