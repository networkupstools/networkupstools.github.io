/* cmd-map-init.h - translate between old CMD #defines and new names */

struct cmd_map_t cmd_map[] =
{
	{ CMD_OFF,	"OFF",		"load.off"		},
	{ CMD_ON,	"ON",		"load.on"		},

	{ CMD_SOFTDOWN,	"SOFTDOWN",	"shutdown.return"	},
	{ CMD_SHUTDOWN,	"SHUTDOWN",	"shutdown.stayoff"	},
	{ CMD_STOPSHUTD,"STOPSHUTD",	"shutdown.stop"		},

	{ CMD_FPTEST,	"FPTEST",	"test.panel.start"	},
	{ CMD_SIMPWF,	"SIMPWF",	"test.failure.start"	},
	{ CMD_BTEST1,	"BTEST1",	"test.battery.start"	},
	{ CMD_BTEST0,	"BTEST0",	"test.battery.stop"	},

	{ CMD_CAL1,	"CAL1",		"calibrate.start"	},
	{ CMD_CAL0,	"CAL0",		"calibrate.stop"	},

	{ CMD_BYPASS,	"BYPASS"	"bypass.start"		},

	{ 0,		NULL,		NULL			}
};
