/* shared-tables.h - tables of info from shared.h, but 
   prolly only used for info output/parsing

   Copyright (C) 2000 Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

/* Originally in upsd.h, separated out because I wanted the text
   strings while working on table driven stuff in the apc-smart
   module
	Nigel Metheringham <Nigel.Metheringham@vdata.co.uk>
*/

#ifndef SHARED_TABLES_H_SEEN
#define SHARED_TABLES_H_SEEN 1

/* netvars[] - map text strings from the network to internal identifiers */

struct netvars_t {
	char	*name;
	int	type;
	char	*desc;
};

/* instcmds[] - instant commands sent via SysV IPC msg queues */
struct instcmds_t {
	char	*name;
	int	cmd;
	char	*desc;
};

#endif	/* SHARED_TABLES_H_SEEN */
