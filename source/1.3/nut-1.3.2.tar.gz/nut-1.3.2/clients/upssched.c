/* upssched.c - upsmon's scheduling helper for offset timers

   Copyright (C) 2000  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

/* design notes for the curious: 
 *
 * 1. we get called with a upsname and notifytype from upsmon
 * 2. the config file is searched for an AT condition that matches
 * 3. the conditions on any matching lines are parsed
 * 
 * starting a timer: the timer is added to the daemon's timer queue
 * cancelling a timer: the timer is removed from that queue
 * execute a command: the command is passed straight to the cmdscript
 *
 * if the daemon is not already running and is required (to start a timer)
 * it will be started automatically
 *
 * when the time arrives, the command associated with a timer will be
 * executed by the daemon (via the cmdscript)
 *
 * timers can be cancelled at any time before they trigger
 *
 * the daemon will shut down automatically when no more timers are active
 * 
 */

#include "common.h"

#include <sys/socket.h>
#include <sys/un.h>

#include "upssched.h"
#include "timehead.h"
#include "parseconf.h"

typedef struct {
	char	*name;
	time_t	etime;
	void	*next;
}	ttype;

	ttype	*thead = NULL;
	char	*cmdscript = NULL, *pipefn = NULL, *lockfn = NULL;
	int	verbose = 0;		/* use for debugging */

	/* ups name and notify type (string) as received from upsmon */
	const	char	*upsname, *notify_type;

#define PARENT_STARTED		-2
#define PARENT_UNNECESSARY	-3
#define MAX_TRIES 30

/* --- server functions --- */

static void exec_cmd(char *cmd)
{
	int err;
	char	buff[LARGEBUF];

	snprintf(buff, sizeof(buff), "%s %s", cmdscript, cmd);

	err = system(buff);
	if (err)
		upslog(LOG_ERR, "Execute command failure: %s", cmd);

	return;
}

static void removetimer(ttype *tfind)
{
	ttype	*tmp, *last;

	last = NULL;
	tmp = thead;

	while (tmp) {
		if (tmp == tfind) {	/* found it */
			if (tmp->name)
				free(tmp->name);

			if (last == NULL)	/* deleting first */
				thead = tmp->next;
			else
				last->next = tmp->next;

			free(tmp);
			return;
		}

		last = tmp;
		tmp = tmp->next;
	}

	/* this one should never happen */

	upslogx(LOG_ERR, "removetimer: failed to locate target at %p", tfind);
}

static void checktimers(void)
{
	ttype	*tmp, *tmpnext;
	time_t	now;

	/* if the queue is empty then we're done */
	if (!thead) {
		if (verbose)
			upslogx(LOG_INFO, "Timer queue empty, exiting");
		unlink(pipefn);

		exit(0);
	}

	/* flip through LL, look for activity */
	tmp = thead;

	time(&now);
	while (tmp) {
		tmpnext = tmp->next;

		if (now >= tmp->etime) {
			if (verbose)
				upslogx(LOG_INFO, "Event: %s ", tmp->name);

			exec_cmd(tmp->name);

			/* delete from queue */
			removetimer(tmp);
		}

		tmp = tmpnext;
	}
}

static void start_timer(char *name, char *ofsstr)
{
	time_t	now;
	int	ofs;
	ttype	*tmp, *last;

	/* get the time */
	time(&now);

	/* add an event for <now> + <time> */
	ofs = strtol(ofsstr, (char **) NULL, 10);

	if (ofs < 0) {
		upslogx(LOG_INFO, "bogus offset for timer, ignoring");
		return;
	}

	if (verbose)
		upslogx(LOG_INFO, "New timer: %s (%d seconds)", name, ofs);

	/* now add to the queue */
	tmp = last = thead;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = xmalloc(sizeof(ttype));
	tmp->name = xstrdup(name);
	tmp->etime = now + ofs;
	tmp->next = NULL;

	if (last)
		last->next = tmp;
	else
		thead = tmp;
}

static void cancel_timer(char *name, char *cname)
{
	ttype	*tmp;

	for (tmp = thead; tmp != NULL; tmp = tmp->next) {
		if (!strcmp(tmp->name, name)) {		/* match */
			if (verbose)
				upslogx(LOG_INFO, "Cancelling timer: %s", name);
			removetimer(tmp);
			return;
		}
	}

	/* this is not necessarily an error */
	if (cname && cname[0]) {
		if (verbose)
			upslogx(LOG_INFO, "Cancel %s, event: %s", name, cname);

		exec_cmd(cname);
	}
}

/* handle received messages from the unix domain socket */
static void parsecmd(cmdtype cbuf)
{
	/* basic sanity check */
	if (cbuf.magic != CMDMAGIC) {
		upslogx(LOG_INFO, "Received packet with bad magic: %x", cbuf.magic);
		return;
	}

	switch (cbuf.cmd) {
		case CMD_START_TIMER:
			start_timer(cbuf.data1, cbuf.data2);
			break;

		case CMD_CANCEL_TIMER:
			cancel_timer(cbuf.data1, cbuf.data2);
			break;

		default:
			upslogx(LOG_INFO, "Unknown command num %d", cbuf.cmd);
	}
}

static int openlistenpipe(void)
{
	int	ss, ret;
	struct sockaddr_un ssaddr;

	ss = socket(AF_UNIX, SOCK_DGRAM, 0);

	if (ss == -1)
		fatal("socket failed");

	ssaddr.sun_family = AF_UNIX;
	strlcpy(ssaddr.sun_path, pipefn, sizeof(ssaddr.sun_path));
	unlink(pipefn);

	/* keep nosy people out of this file */
	umask(077);

	ret = bind(ss, (struct sockaddr *) &ssaddr, sizeof ssaddr);

	if (ret < 0)
		fatal("bind %s failed", pipefn);

	ret = chmod(pipefn, 0600);

	if (ret < 0)
		fatal("chmod on pipe failed");

	return ss;
}

static void us_serialize(int op)
{
	static	int	pipefd[2];
	int	ret;
	char	ch;

	switch(op) {
		case SERIALIZE_INIT:
			ret = pipe(pipefd);

			if (ret != 0)
				fatal("serialize: pipe");

			break;

		case SERIALIZE_SET:
			close(pipefd[0]);
			close(pipefd[1]);
			break;

		case SERIALIZE_WAIT:
			close(pipefd[1]);
			ret = read(pipefd[0], &ch, 1);
			close(pipefd[0]);
			break;
	}
}

static void start_daemon(int lockfd, cmdtype inbuf)
{
	int	pid, pipefd, ret;
	struct	timeval	tv;
	fd_set	rfds;
	cmdtype	cbuf;

	us_serialize(SERIALIZE_INIT);

	if ((pid = fork()) < 0)
		fatal("Unable to enter background");

	if (pid != 0) {		/* parent */

		/* wait for child to set up the listener */
		us_serialize(SERIALIZE_WAIT);

		return;
	}

	/* child */

	close(0);
	close(1);
	close(2);

	(void) open("/dev/null", O_RDWR);
	dup(0);
	dup(0);

	pipefd = openlistenpipe();

	if (verbose)
		upslogx(LOG_INFO, "Timer daemon started");

	/* handle whatever it was that caused us to start */
	parsecmd(inbuf);

	/* release the parent */
	us_serialize(SERIALIZE_SET);

	/* drop the lock now that the background is running */
	unlink(lockfn);
	close(lockfd);

	/* now watch for activity */

	for (;;) {
		/* wait at most 1s so we can check our timers regularly */
		tv.tv_sec = 1;
		tv.tv_usec = 0;

		FD_ZERO(&rfds);
		FD_SET(pipefd, &rfds);

		ret = select(pipefd + 1, &rfds, NULL, NULL, &tv);

		if (ret) {
			memset(&cbuf, '\0', sizeof(cbuf));
			ret = read(pipefd, &cbuf, sizeof(cbuf) - 1);

			if (ret < 0)
				upslog(LOG_ERR, "read error");
			else
				parsecmd(cbuf);
		}
 
		checktimers();
	}
}

/* --- 'client' functions --- */

static int try_connect(const char *pipefn)
{
	int	pipefd, ret;
	struct sockaddr_un pipeaddr;

	pipefd = socket(AF_UNIX, SOCK_DGRAM, 0);

	if (pipefd == -1)
		fatal("socket");

	pipeaddr.sun_family = AF_UNIX;
	strlcpy(pipeaddr.sun_path, pipefn, sizeof(pipeaddr.sun_path));

	ret = connect(pipefd, (const struct sockaddr *)&pipeaddr, 
	              sizeof(pipeaddr));

	if (ret != -1)
		return pipefd;

	return -1;	
}

static int get_lock(const char *fn)
{
	int	fd;

	fd = open(fn, O_RDONLY | O_CREAT | O_EXCL, 0);

	return fd;
}

/* try to connect to bg process, and start one if necessary */
static int check_parent(cmdtype cbuf)
{
	int	pipefd, lockfd, tries = 0;

	for (tries = 0; tries < MAX_TRIES; tries++) {

		pipefd = try_connect(pipefn);

		if (pipefd != -1)
			return pipefd;

		/* timer daemon isn't running */

		/* it's not running, so there's nothing to cancel */
		if (cbuf.cmd == CMD_CANCEL_TIMER)
			return PARENT_UNNECESSARY;

		/* we need to start the daemon, so try to get the lock */

		lockfd = get_lock(lockfn);

		if (lockfd != -1) {
			start_daemon(lockfd, cbuf);
			return PARENT_STARTED;	/* started successfully */
		}

		/* we didn't get the lock - must be two upsscheds running */

		/* blow this away in case we crashed before */
		unlink(lockfn);

		/* give the other one a chance to start it, then try again */
		usleep(250000);
	}

	upslog(LOG_ERR, "Failed to connect to parent and failed to create parent");
	exit(1);
}

static void sendcmd(int type, const char *arg1, const char *arg2)
{
	int	pipefd, ret;
	cmdtype	cbuf;

	cbuf.magic = CMDMAGIC;
	cbuf.cmd = type;

	strlcpy(cbuf.data1, arg1 ? arg1 : "", sizeof(cbuf.data1));
	strlcpy(cbuf.data2, arg2 ? arg2 : "", sizeof(cbuf.data2));

	/* see if the parent needs to be started (and maybe start it) */

	pipefd = check_parent(cbuf);

	/* starting the parent also handles our cbuf */
	if (pipefd == PARENT_STARTED)
		return;

	/* special case for CANCEL when no parent is running */
	if (pipefd == PARENT_UNNECESSARY)
		return;

	/* otherwise we just connected to an existing one */

	ret = write(pipefd, &cbuf, sizeof(cbuf));

	if (ret < 1)
		fatal("write");

	close(pipefd);
}

static void parse_at(const char *ntype, const char *un, const char *cmd, 
		const char *ca1, const char *ca2)
{
	/* complain both ways in case we don't have a tty */	

	if (!cmdscript) {
		printf("CMDSCRIPT must be set before any ATs in the config file!\n");
		fatalx("CMDSCRIPT must be set before any ATs in the config file!");
	}

	if (!pipefn) {
		printf("PIPEFN must be set before any ATs in the config file!\n");
		fatalx("PIPEFN must be set before any ATs in the config file!");
	}

	if (!lockfn) {
		printf("LOCKFN must be set before any ATs in the config file!\n");
		fatalx("LOCKFN must be set before any ATs in the config file!");
	}

	/* check upsname: does this apply to us? */
	if (strcmp(upsname, un) != 0)
		if (strcmp(un, "*") != 0)
			return;		/* not for us, and not the wildcard */

	/* see if the current notify type matches the one from the .conf */
	if (strcasecmp(notify_type, ntype) != 0)
		return;

	/* if command is valid, send it to the daemon (which may start it) */

	if (!strcmp(cmd, "START-TIMER")) {
		sendcmd(CMD_START_TIMER, ca1, ca2);
		return;
	}

	if (!strcmp(cmd, "CANCEL-TIMER")) {
		sendcmd(CMD_CANCEL_TIMER, ca1, ca2);
		return;
	}

	if (!strcmp(cmd, "EXECUTE")) {
		if (ca1 == '\0') {
			upslogx(LOG_ERR, "Empty EXECUTE command argument");
			return;
		}

		if (verbose)	
			upslogx(LOG_INFO, "Executing command: %s", ca1);

		exec_cmd((char *) ca1);
		return;
	}

	upslogx(LOG_ERR, "Invalid command: %s", cmd);
}

static int conf_arg(int numargs, char **arg)
{
	if (numargs < 2)
		return 0;

	/* CMDSCRIPT <scriptname> */
	if (!strcmp(arg[0], "CMDSCRIPT")) {
		cmdscript = xstrdup(arg[1]);
		return 1;
	}

	/* PIPEFN <pipename> */
	if (!strcmp(arg[0], "PIPEFN")) {
		pipefn = xstrdup(arg[1]);
		return 1;
	}

	/* LOCKFN <filename> */
	if (!strcmp(arg[0], "LOCKFN")) {
		lockfn = xstrdup(arg[1]);
		return 1;
	}

	if (numargs < 5)
		return 0;

	/* AT <notifytype> <upsname> <command> <cmdarg1> [<cmdarg2>] */
	if (!strcmp(arg[0], "AT")) {

		/* don't use arg[5] unless we have it... */
		if (numargs > 5)
			parse_at(arg[1], arg[2], arg[3], arg[4], arg[5]);
		else
			parse_at(arg[1], arg[2], arg[3], arg[4], NULL);

		return 1;
	}

	return 0;
}

/* called for fatal errors in parseconf like malloc failures */
void upssched_err(const char *errmsg)
{
	upslogx(LOG_ERR, "Fatal error in parseconf(upssched.conf): %s", errmsg);
}

static void checkconf(void)
{
	char	fn[SMALLBUF];
	PCONF_CTX	ctx;

	snprintf(fn, sizeof(fn), "%s/upssched.conf", CONFPATH);

	pconf_init(&ctx, upssched_err);

	if (!pconf_file_begin(&ctx, fn))
		fatalx("%s", ctx.errmsg);

	while (pconf_file_next(&ctx)) {
		if (pconf_parse_error(&ctx)) {
			upslogx(LOG_ERR, "Parse error: %s:%d: %s",
				fn, ctx.linenum, ctx.errmsg);
			continue;
		}

		if (ctx.numargs < 1)
			continue;

		if (!conf_arg(ctx.numargs, ctx.arglist)) {
			int	i;
			char	errmsg[SMALLBUF];

			snprintf(errmsg, sizeof(errmsg), 
				"upssched.conf: invalid directive");

			for (i = 0; i < ctx.numargs; i++)
				snprintfcat(errmsg, sizeof(errmsg), " %s", 
					ctx.arglist[i]);

			upslogx(LOG_WARNING, errmsg);
		}
	}

	pconf_finish(&ctx);
}

int main(int argc, char **argv)
{
	verbose = 1;		/* TODO: remove when done testing */

	/* normally we don't have stderr, so get this going to syslog early */
	openlog("upssched", LOG_PID, LOG_DAEMON);
	syslogbit_set();	

	upsname = getenv("UPSNAME");
	notify_type = getenv("NOTIFYTYPE");

	if ((!upsname) || (!notify_type)) {
		printf("Error: UPSNAME and NOTIFYTYPE must be set.\n");
		printf("This program should only be run from upsmon.\n");
		exit(1);
	}

	/* see if this matches anything in the config file */
	checkconf();

	return 0;
}
