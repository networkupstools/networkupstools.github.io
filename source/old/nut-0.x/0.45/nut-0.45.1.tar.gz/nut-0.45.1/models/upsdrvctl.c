/* upsdrvctl.c - UPS model driver controller

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include "config.h"
#include "shared.h"
#include "proto.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"
#include "upsconf.h"

typedef struct {
	char	*upsname;
	char	*driver;
	void	*next;
}	ups_t;

	ups_t	*upstable = NULL;

	int	execwait;

void do_upsconf_args(char *upsname, char *var, char *val)
{
	ups_t	*tmp, *last;

	last = tmp = upstable;

	while (tmp) {
		last = tmp;

		if (!strcmp(tmp->upsname, upsname)) {
			if (!strcmp(var, "driver")) 
				tmp->driver = xstrdup(val);
			return;
		}

		tmp = tmp->next;
	}

	tmp = xmalloc(sizeof(ups_t));
	tmp->upsname = xstrdup(upsname);
	tmp->next = NULL;

	if (!strcmp(var, "driver"))
		tmp->driver = xstrdup(val);

	if (last)
		last->next = tmp;
	else
		upstable = tmp;
}

/* walk ups table, but stop drivers instead */
void stop_drivers(void)
{
	fatalx("This feature is not implemented yet.\n");
}

/* reap exiting children */
void sigchld(int sig)
{
	execwait = 0;
}

void forkexec(char *prog, char *upsname)
{
	int	ret;
	char	*argv[4];

	/* TODO: consider redoing this with wait() depending on portability */

	/* parent spins until the child exits */
	execwait = 1;

	/* catching this will unset execwait */
	signal(SIGCHLD, sigchld);

	ret = fork();

	if (ret < 0)
		fatal("fork");

	/* parent */
	if (ret != 0) {
		/* spin until the child is done */
		while (execwait)
			usleep(250000);
		return;
	}

	argv[0] = xstrdup(prog);
	argv[1] = "-a";
	argv[2] = upsname;
	argv[3] = NULL;

	/* child */
	ret = execve(prog, argv, NULL);

	/* should not be reached */
	fatal("execve");
}
		

/* walk ups table and invoke drivers */
void start_drivers(void)
{
	ups_t	*tmp = upstable;
	char	dfn[SMALLBUF], exec[SMALLBUF];
	int	ret;
	struct	stat	fs;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		snprintf(dfn, sizeof(dfn), "%s/%s", MODELPATH, tmp->driver);
		ret = stat(dfn, &fs);

		if (ret < 0)
			fatal("Can't start %s", dfn);

		snprintf(exec, sizeof(exec), "%s -a %s", 
			dfn, tmp->upsname);

		forkexec(dfn, tmp->upsname);

		tmp = tmp->next;
	}
}

void help(const char *progname)
{
	printf("Starts and stops UPS drivers via ups.conf.\n\n");
	printf("usage: %s [-h] (start | stop)\n\n", progname);

	printf("  -h		display this help\n");
	printf("  start		start all UPSes in ups.conf\n");
	printf("  stop		stop all UPSes in ups.conf (not yet supported)\n");
	exit(1);
}

int main(int argc, char **argv)
{
	int	i;
	char	*prog;

	printf("Network UPS Tools - UPS driver controller 0.10 (%s)\n",
		UPS_VERSION);

	prog = argv[0];
	while ((i = getopt(argc, argv, "+h")) != EOF) {
		switch(i) {
			case 'h':
			default:
				help(argv[0]);
				break;
		}
	}

	argc -= optind;
        argv += optind;

	if (argc < 1)
		help(prog);

	/* TODO: start <foo> -> start just that UPS */

	/* TODO: stop <foo> -> same thing */

	if (!strcmp(argv[0], "start")) {
		read_upsconf(1);
		start_drivers();
		exit(0);
	}

	if (!strcmp(argv[0], "stop")) {
		read_upsconf(1);
		stop_drivers();
		exit(0);
	}

	fatalx("Error: unrecognized command [%s]\n", argv[0]);

	/* NOTREACHED */
	return 0;
}
