/* conf.c - configuration handlers for upsd

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include "upsd.h"
#include "conf.h"

	extern	int	maxage;
	extern	char	*statepath;
	ups_t	*upstable = NULL;

/* parse upsd.conf */
void read_upsdconf(void)
{
	FILE	*conf;
	char	buf[SMALLBUF], fn[SMALLBUF], *arg[5];
	int	i, ln, convwarn = 0;

	snprintf(fn, sizeof(fn), "%s/upsd.conf", CONFPATH);

	conf = fopen(fn, "r");

	if (!conf)
		fatal("Can't open %s/upsd.conf", CONFPATH);

	ln = 0;
	while (fgets(buf, sizeof(buf), conf)) {
		buf[strlen(buf) - 1] = '\0';

		i = parseconf("upsd.conf", ++ln, buf, arg, 5);

		if (i == 0)
			continue;

		/* TODO: remove this once conversion to ups.conf is done */

		/* UPS <upsname> <statefile> [ optional ] *
		 * optional data is not used by upsd      */
		if (!strcmp(arg[0], "UPS")) {
			if ((!arg[1]) || (!arg[2])) {
				upslogx(LOG_ERR, "upsd.conf: UPS directive needs 2 arguments");
				continue;
			}

			addups(arg[2], arg[1]);	/* fn, name */

			if (!convwarn) {
				upslogx(LOG_WARNING, "Warning: UPS definitions in upsd.conf are deprecated - switch to ups.conf");
				convwarn = 1;
			}
		}

		/* ACL <aclname> <ip block> */
		if (!strcmp(arg[0], "ACL"))
			addacl(arg[1], arg[2]);

		/* ACCESS <action> <level> <aclname> <password> */
		if (!strcmp(arg[0], "ACCESS"))
			addaccess(arg[1], arg[2], arg[3], arg[4]);

		/* everything after here needs arg[1] */
		if (!arg[1])
			continue;

		/* MAXAGE <seconds> */
		if (!strcmp(arg[0], "MAXAGE"))
			maxage = atoi(arg[1]);

		/* STATEPATH <dir> */
		if (!strcmp(arg[0], "STATEPATH"))
			statepath = xstrdup(arg[1]);
	}
		
	fclose (conf);
}

/* callback during parsing of ups.conf */
void do_upsconf_args(char *upsname, char *var, char *val)
{
	ups_t	*tmp, *last;

	last = tmp = upstable;

	while (tmp) {
		last = tmp;

		if (!strcmp(tmp->upsname, upsname)) {
			if (!strcmp(var, "driver")) 
				tmp->driver = xstrdup(val);
			if (!strcmp(var, "port")) 
				tmp->port = xstrdup(val);
			return;
		}

		tmp = tmp->next;
	}

	tmp = xmalloc(sizeof(ups_t));
	tmp->upsname = xstrdup(upsname);
	tmp->driver = NULL;
	tmp->port = NULL;
	tmp->next = NULL;

	if (!strcmp(var, "driver"))
		tmp->driver = xstrdup(val);
	if (!strcmp(var, "port"))
		tmp->port = xstrdup(val);

	if (last)
		last->next = tmp;
	else
		upstable = tmp;
}

/* add valid UPSes from ups.conf to the internal structures */
void upsconf_add(void)
{
	ups_t	*tmp = upstable, *next;
	char	statefn[SMALLBUF];

	/* nonfatal for now - eventually this will be required */
	if (!tmp) {
		upslogx(LOG_WARNING, "Warning: no UPS definitions in ups.conf");
		return;
	}

	while (tmp) {

		/* save for later, since we delete as we go along */
		next = tmp->next;

		/* this should always be set, but better safe than sorry */
		if (!tmp->upsname) {
			tmp = next;
			continue;
		}

		if ((!tmp->driver) || (!tmp->port)) {
			upslogx(LOG_WARNING, "Warning: ignoring incomplete configuration for UPS [%s]\n", 
				tmp->upsname);
		} else {
			snprintf(statefn, sizeof(statefn), "%s/%s-%s", 
				STATEPATH, tmp->driver, xbasename(tmp->port));

			addups(statefn, tmp->upsname);
		}

		/* free tmp's resources */

		if (tmp->driver)
			free(tmp->driver);
		if (tmp->port)
			free(tmp->port);
		if (tmp->upsname)
			free(tmp->upsname);
		free(tmp);

		tmp = next;
	}

	/* upstable should be completely gone by this point */
	upstable = NULL;
}
