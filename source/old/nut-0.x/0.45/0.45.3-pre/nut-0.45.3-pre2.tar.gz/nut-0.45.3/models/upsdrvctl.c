/* upsdrvctl.c - UPS model driver controller

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include "config.h"
#include "shared.h"
#include "proto.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"
#include "upsconf.h"

typedef struct {
	char	*upsname;
	char	*driver;
	char	*port;
	void	*next;
}	ups_t;

	ups_t	*upstable = NULL;

	int	execwait, verbose = 0;

void do_upsconf_args(char *upsname, char *var, char *val)
{
	ups_t	*tmp, *last;

	last = tmp = upstable;

	while (tmp) {
		last = tmp;

		if (!strcmp(tmp->upsname, upsname)) {
			if (!strcmp(var, "driver")) 
				tmp->driver = xstrdup(val);
			if (!strcmp(var, "port")) 
				tmp->port = xstrdup(val);
			return;
		}

		tmp = tmp->next;
	}

	tmp = xmalloc(sizeof(ups_t));
	tmp->upsname = xstrdup(upsname);
	tmp->driver = NULL;
	tmp->port = NULL;
	tmp->next = NULL;

	if (!strcmp(var, "driver"))
		tmp->driver = xstrdup(val);
	if (!strcmp(var, "port"))
		tmp->port = xstrdup(val);

	if (last)
		last->next = tmp;
	else
		upstable = tmp;
}

int read_pid_file(char *upsname, char *driver, char *port)
{
	char	pidfn[SMALLBUF], buf[SMALLBUF];
	int	ret, pid;
	struct	stat	fs;
	FILE	*pidf;

	snprintf(pidfn, sizeof(pidfn), "%s/%s-%s.pid", ALTPIDPATH,
		driver, xbasename(port));
	ret = stat(pidfn, &fs);

	if (ret != 0) {
		upslog(LOG_ERR, "Can't open %s", pidfn);
		return -1;
	}

	pidf = fopen(pidfn, "r");

	if (!pidf) {
		upslog(LOG_ERR, "Can't open %s", pidfn);
		return -1;
	}

	fgets(buf, sizeof(buf), pidf);
	fclose(pidf);

	buf[strlen(buf)-1] = '\0';

	pid = strtol(buf, (char **)NULL, 10);

	return pid;
}

/* handle sending the signal */
void send_quit(char *upsname, char *driver, char *port)
{
	char	pidfn[SMALLBUF], buf[SMALLBUF];
	int	ret, pid;
	struct	stat	fs;
	FILE	*pidf;

	printf("Stopping UPS: %s\n", upsname);

	snprintf(pidfn, sizeof(pidfn), "%s/%s-%s.pid", ALTPIDPATH,
		driver, xbasename(port));
	ret = stat(pidfn, &fs);

	if (ret != 0) {
		upslog(LOG_ERR, "Can't open %s", pidfn);
		return;
	}

	pidf = fopen(pidfn, "r");

	if (!pidf) {
		upslog(LOG_ERR, "Can't open %s", pidfn);
		return;
	}

	fgets(buf, sizeof(buf), pidf);
	buf[strlen(buf)-1] = '\0';

	pid = strtol(buf, (char **)NULL, 10);

	if (pid < 2) {
		upslogx(LOG_NOTICE, "Ignoring invalid pid %d in %s",
			pid, pidfn);
		return;
	}

	if (verbose)
		printf("Sending signal: kill -QUIT %d\n", pid);

	ret = kill(pid, SIGQUIT);

	if (ret < 0) {
		upslog(LOG_ERR, "kill pid %d failed", pid);
		return;
	}
}

/* stop user-selected driver */
void stop_one_driver(char *upsname)
{
	ups_t	*tmp = upstable;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		if (!strcmp(tmp->upsname, upsname)) {
			send_quit(tmp->upsname, tmp->driver, tmp->port);
			return;
		}

		tmp = tmp->next;
	}

	fatalx("UPS %s not found in ups.conf", upsname);
}

/* walk ups table, but stop drivers instead */
void stop_all_drivers(void)
{
	ups_t	*tmp = upstable;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		send_quit(tmp->upsname, tmp->driver, tmp->port);

		tmp = tmp->next;
	}

	exit(0);
}

/* check user-selected driver */
void check_one_driver(char *upsname)
{
	ups_t	*tmp = upstable;
	int	pid, stat_error = 0;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		if (!strcmp(tmp->upsname, upsname)) {
			pid = read_pid_file(tmp->upsname, tmp->driver, 
				tmp->port);

			if (pid < 2)
				stat_error = 1;

			if (verbose) {
				if (pid > 1)
					printf("UPS %s: driver %s (PID %d)\n", 
						tmp->upsname, tmp->driver, pid);
				else
					printf("UPS %s: driver %s not running "
						"or invalid PID\n",
						tmp->upsname, tmp->driver);
			}

			exit(stat_error);
		}

		tmp = tmp->next;
	}

	fatalx("UPS %s not found in ups.conf", upsname);
}

/* walk ups table and make sure they're still running */
void check_all_drivers(void)
{
	ups_t	*tmp = upstable;
	int	pid, stat_error = 0;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		pid = read_pid_file(tmp->upsname, tmp->driver, tmp->port);

		if (pid < 2)
			stat_error = 1;

		if (verbose) {
			if (pid > 1)
				printf("UPS %s: driver %s (PID %d)\n", 
					tmp->upsname, tmp->driver, pid);
			else
				printf("UPS %s: driver %s not running or "
					"invalid PID\n",
					tmp->upsname, tmp->driver);
		}

		tmp = tmp->next;
	}

	exit(stat_error);
}

/* reap exiting children */
void sigchld(int sig)
{
	execwait = 0;
}

void forkexec(char *prog, char *upsname)
{
	int	ret;
	char	*argv[4];

	/* TODO: consider redoing this with wait() depending on portability */

	/* parent spins until the child exits */
	execwait = 1;

	/* catching this will unset execwait */
	signal(SIGCHLD, sigchld);

	ret = fork();

	if (ret < 0)
		fatal("fork");

	/* parent */
	if (ret != 0) {
		/* spin until the child is done */
		while (execwait)
			usleep(250000);
		return;
	}

	if (verbose)
		printf("exec: %s -a %s\n", prog, upsname); 

	argv[0] = xstrdup(prog);
	argv[1] = "-a";
	argv[2] = upsname;
	argv[3] = NULL;

	/* child */
	ret = execve(prog, argv, NULL);

	/* should not be reached */
	fatal("execve");
}

void start_driver(char *driver, char *upsname)
{
	char	dfn[SMALLBUF], exec[SMALLBUF];
	int	ret;
	struct	stat	fs;

	snprintf(dfn, sizeof(dfn), "%s/%s", MODELPATH, driver);
	ret = stat(dfn, &fs);

	if (ret < 0)
		fatal("Can't start %s", dfn);

	snprintf(exec, sizeof(exec), "%s -a %s", dfn, upsname);

	forkexec(dfn, upsname);
}

/* start user-selected driver */
void start_one_driver(char *upsname)
{
	ups_t	*tmp = upstable;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		if (!strcmp(tmp->upsname, upsname)) {
			start_driver(tmp->driver, tmp->upsname);
			return;
		}

		tmp = tmp->next;
	}

	fatalx("UPS %s not found in ups.conf", upsname);
}

/* walk ups table and invoke drivers */
void start_all_drivers(void)
{
	ups_t	*tmp = upstable;

	if (!tmp)
		fatalx("Error: no UPS definitions found in ups.conf!\n");

	while (tmp) {
		start_driver(tmp->driver, tmp->upsname);
		tmp = tmp->next;
	}
}

void help(const char *progname)
{
	printf("Starts and stops UPS drivers via ups.conf.\n\n");
	printf("usage: %s [-h] [-v] (start | stop [<ups>])\n\n", progname);

	printf("  -h		display this help\n");
	printf("  -v		enable verbose messages\n");
	printf("  start		start all UPS drivers in ups.conf\n");
	printf("  start	<ups>	only start driver for UPS <ups>\n");
	printf("  stop		stop all UPS drivers in ups.conf\n");
	printf("  stop <ups>	only stop driver for UPS <ups>\n");
	printf("  status	check all driver PIDs, returns 0 on success\n");
	printf("  status <ups>	check just UPS <ups>\n");
	exit(1);
}

int main(int argc, char **argv)
{
	int	i;
	char	*prog;

	printf("Network UPS Tools - UPS driver controller 0.20 (%s)\n",
		UPS_VERSION);

	prog = argv[0];
	while ((i = getopt(argc, argv, "+hv")) != EOF) {
		switch(i) {
			case 'v':
				verbose++;
				break;

			case 'h':
			default:
				help(prog);
				break;
		}
	}

	argc -= optind;
        argv += optind;

	if (argc < 1)
		help(prog);

	if (!strcmp(argv[0], "start")) {
		read_upsconf(1);

		if (argc == 1)
			start_all_drivers();
		else
			start_one_driver(argv[1]);

		exit(0);
	}

	if (!strcmp(argv[0], "stop")) {
		read_upsconf(1);

		if (argc == 1)
			stop_all_drivers();
		else
			stop_one_driver(argv[1]);

		exit(0);
	}

	if (!strcmp(argv[0], "status")) {
		read_upsconf(1);

		if (argc == 1)
			check_all_drivers();
		else
			check_one_driver(argv[1]);
	}

	fatalx("Error: unrecognized command [%s]\n", argv[0]);

	/* NOTREACHED */
	return 0;
}
