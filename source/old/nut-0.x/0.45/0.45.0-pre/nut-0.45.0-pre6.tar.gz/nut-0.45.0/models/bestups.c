/* bestups.c - model specific routines for Best-UPS Fortress models

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include "main.h"

#define INFOMAX  16
#define ENDCHAR  13	/* replies end with CR */
#define UPSDELAY  5
#define MAXTRIES 10

static	char	*modelname, *va;
static	float	lowvolt = 0, highvolt = 0, voltrange = 0;
static	int	linenorm = 0;

static void setmodel(const char *abbr, const char *va)
{
	if (!strcmp(abbr, "FOR")) {
		setinfo(INFO_MFR, "%s", "Best Power");
		setinfo(INFO_MODEL, "Fortress %s", va);
		return;
	}

	if (!strcmp(abbr, "FTC")) {
		setinfo(INFO_MFR, "%s", "Best Power");
		setinfo(INFO_MODEL, "Fortress Telecom %s", va);
		return;
	}

	if (!strcmp(abbr, "PRO")) {
		setinfo(INFO_MFR, "%s", "Best Power");
		setinfo(INFO_MODEL, "Patriot Pro %s", va);
		return;
	}

	if (!strcmp(abbr, "PR2")) {
		setinfo(INFO_MFR, "%s", "Best Power");
		setinfo(INFO_MODEL, "Patriot Pro II %s", va);
		return;
	}

	if (!strcmp(abbr, "520")) {
		setinfo(INFO_MFR, "%s", "Sola Australia");
		setinfo(INFO_MODEL, "Sola 520 %s", va);
		return;
	}

	setinfo(INFO_MFR, "%s", "Unknown");
	setinfo(INFO_MODEL, "Unknown %s (%s)", abbr, va);

	printf ("Unknown model detected - please report this ID: '%s'\n", abbr);

	return;
}

void upsdrv_initinfo(void)
{
	addinfo (INFO_MFR, "", 0, 0);
	addinfo (INFO_MODEL, "", 0, 0);
	addinfo (INFO_UTILITY, "", 0, 0);
	addinfo (INFO_BATTPCT, "", 0, 0);
	addinfo (INFO_BATTVOLT, "", 0, 0);
	addinfo (INFO_STATUS, "", 0, 0);
	addinfo (INFO_ACFREQ, "", 0, 0);
	addinfo (INFO_LOADPCT, "", 0, 0);
	addinfo (INFO_UPSTEMP, "", 0, 0);
        addinfo (INFO_INSTCMD, "", 0, CMD_BTEST0);
        addinfo (INFO_INSTCMD, "", 0, CMD_BTEST1);

	setmodel(modelname, va);
	printf("Detected %s %s on %s\n", getdata(INFO_MFR), getdata(INFO_MODEL), device_path);
}

	/* TODO: adapt to the standard upscommon open/send/recv calls */

static void setup_serial(void)
{	
	struct	termios	tio;

	upsfd = open(device_path, O_RDWR | O_NDELAY);
	if (upsfd == -1)
		fatal("open %s", device_path);

	if (tcgetattr (upsfd, &tio) == -1)
		fatal("tcgetattr");

	tio.c_iflag = IXON | IXOFF;
	tio.c_oflag = 0;
	tio.c_cflag = (B2400 | CS8 | CREAD | HUPCL | CLOCAL);
	tio.c_lflag = 0;
	tio.c_cc[VMIN] = 1;
	tio.c_cc[VTIME] = 0; 

#ifdef HAVE_CFSETISPEED
	cfsetispeed (&tio, B2400);
	cfsetospeed (&tio, B2400);
#endif

	if (tcsetattr (upsfd, TCSANOW, &tio) == -1)
		fatal("tcsetattr");
}

char readchar (void)
{
	char	c;
	int	ret;

	ret = read (upsfd, &c, 1);

	if (ret > 0)
		return (c & 0x7f);
	else
		return 0;
}

/* TODO: also roll this into upscommon */
int xrecv (char *buf)
{
	char	ch, *p;

	p = buf;
	*p = '\0';

	while ((ch = readchar ())) {
		if (ch == 13) {
			*p = '\0';
			return 0;
		}
	
		*p++ = ch;
	}

	*p = '\0';
	return 0;
}

void ups_sync(void)
{
	char	buf[256];
	int	tries = 0;

	printf ("Syncing with UPS: ");
	fflush (stdout);

	for (;;) {
		tries++;
		if (tries > MAXTRIES)
			fatalx("\nFailed - giving up...");
		upssend("%s", "\rQ1\r");
		printf (".");
		fflush (stdout);
		sleep (UPSDELAY);
		printf (".");
		fflush (stdout);
		xrecv (buf);
		printf (".");
		fflush (stdout);
		if (buf[0] == '(')
			break;			
	}

	printf (" done\n");
}

void upsdrv_shutdown(void)
{
	char	temp[256], stat[32];
	int	tries = 0;

	/* basic idea: find out line status and send appropriate command */

	printf ("Checking status: ");
	fflush (stdout);

	for (;;) {
		tries++;
		if (tries > MAXTRIES) {
			printf ("\nFailed - giving up...\n");
			exit (1);
		}
		upssend ("\rQ1\r");
		printf (".");
		fflush (stdout);
		sleep (UPSDELAY);
		printf (".");
		fflush (stdout);
		xrecv (temp);
		printf (".");
		fflush (stdout);
		if ((temp[0] == '(') && (strlen(temp) == 46))
			break;
	}

	printf (" done\n");

	sscanf (temp, "%*s %*s %*s %*s %*s %*s %*s %s", stat);

	/* on battery: send S01<cr>, ups will return by itself on utility */
	/* on line: send S01R0001<cr>, ups will cycle and return soon */

	upssend("%s", "S01");

	if (stat[0] == '0') {			/* on line */
		printf ("On line, sending shutdown+return command...\n");
		upssend("%s", "R0001");
	}
	else
		printf ("On battery, sending normal shutdown command...\n");

	upssend("%s", "\r");	/* end sequence */
}

void ups_ident(void)
{
	char	buf[256], *ptr, *com;
	int	i, tries = 0;

	printf ("Identifying UPS: ");
	fflush (stdout);

	for (;;) {
		tries++;
		if (tries > MAXTRIES) {
			printf ("\nFailed - giving up...\n");
			exit (1);
		}
		upssend("%s", "\r\rID\r");
		printf (".");
		fflush (stdout);
		sleep (UPSDELAY);
		printf (".");
		fflush (stdout);
		xrecv (buf);
		printf (".");
		fflush (stdout);
		if ((buf[0] != '\0') && (buf[0] != '(') &&
		    ((strlen(buf) == 25) || (strlen(buf) == 26)))
			break;
	}

	printf (" done\n");

	modelname = va = NULL;

	/* FOR,750,120,120,20.0,27.6 */
	ptr = buf;

	for (i = 0; i < 6; i++) {
		com = strchr (ptr, ',');

		if (com)
			*com = '\0';

		switch (i) {
			case 0: modelname = xstrdup (ptr);
				break;
			case 1: va = xstrdup (ptr);
				break;
			case 2: linenorm = atoi(ptr);
				break;
			case 4: lowvolt = atof (ptr);
				break;
			case 5: highvolt = atof (ptr);
				voltrange = highvolt - lowvolt;
				break;
			default:
				break;
		}

		if (com)
			ptr = com + 1;
	}
}

void upsdrv_updateinfo(void)
{
	char	utility[16], loadpct[16], acfreq[16], battvolt[16],
		upstemp[16], stat[16], buf[256], temp[VALSIZE];
	float	bvoltp;

	upssend("%s", "\rQ1\r");
	sleep (UPSDELAY); 
	xrecv (buf);

	if ((strlen(buf) < 46) || (buf[0] != '('))
		return;

	sscanf (buf, "%*c%s %*s %*s %s %s %s %s %s", utility, loadpct, 
	        acfreq, battvolt, upstemp, stat);
	
	bvoltp = ((atof (battvolt) - lowvolt) / voltrange) * 100.0;

	if (bvoltp > 100.0)
		bvoltp = 100.0;

	setinfo(INFO_BATTVOLT, "%s", battvolt);
	setinfo(INFO_UTILITY, "%s", utility);
	setinfo(INFO_LOADPCT, "%s", loadpct);
	setinfo(INFO_ACFREQ, "%s", acfreq);
	setinfo(INFO_UPSTEMP, "%s", upstemp);
	setinfo(INFO_BATTPCT, "%02.1f", bvoltp);

	strcpy (temp, "");

	if (stat[0] == '0')
		strcat (temp, "OL ");		/* on line */
	else
		strcat (temp, "OB ");		/* on battery */

	if (stat[1] == '1')
		strcat (temp, "LB ");		/* low battery */

	if (stat[2] == '1') {		/* boost or trim in effect */
		if (atoi(utility) < linenorm)
			strcat (temp, "BOOST");

		if (atoi(utility) > linenorm)
			strcat (temp, "TRIM");
	}

	/* lose trailing space if present */
	if (temp[strlen(temp)-1] == ' ')
		temp[strlen(temp)-1] = 0;

	setinfo(INFO_STATUS, "%s", temp);

	writeinfo();
}

void instcmd (int auxcmd, int dlen, char *data)
{
	/* TODO: reply to upsd? */

	switch (auxcmd) {
		case CMD_BTEST0:	/* stop battery test */
			upssendchar ('C');
			upssendchar ('T');
			upssendchar (13);
			break;
		case CMD_BTEST1:	/* start battery test */
			upssendchar ('T');
			upssendchar (13);
			break;
		default:
			upslogx(LOG_INFO, "instcmd: unknown type 0x%04x\n", auxcmd);
	}
}

void upsdrv_help(void)
{
}

void upsdrv_makevartable(void)
{
}

void upsdrv_banner(void)
{
	printf("Network UPS Tools - Best UPS driver 0.40 (%s)\n", UPS_VERSION);
}

void upsdrv_initups(void)
{
	setup_serial();

	ups_sync();
	ups_ident();

	upsh.instcmd = instcmd;
}
