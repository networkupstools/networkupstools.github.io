/* upscommon.c - functions used in more than one model support module

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <pwd.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "config.h"
#include "proto.h"
#include "shared.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"

#ifdef HAVE_SYS_SHM_H
#include <sys/ipc.h>
#include <sys/shm.h>
#else
#define shmget(a,b,c) (-1)
#define shmctl(a,b,c) /* nop */
struct shmid_ds {
        void *junk;
};
#endif

#ifdef HAVE_UU_LOCK
#include <libutil.h>
#endif

#ifdef HAVE_MSGGET
#include <sys/ipc.h>
#include <sys/msg.h>
#endif

	int	upsfd, shmid = -1, msgid = -1, upsc_debug = 0;
	char	statefn[256], *upsport;

	itype	*info = NULL;
	int	infoused = 0, infomax = 0;

	struct	ups_handler	upsh;

/* need to pick a sane default.  maybe this should be set by open_serial */
	unsigned int upssend_delay = 0;
	char	upssend_endchar = '\0';
	
	int	flag_timeoutfailure = 0;

/* signal handler for SIGALRM when opening a serial port */
void openfail(int sig)
{
	fatal("Fatal error: serial port open timed out");
}

/* try whatever method(s) are available to lock the port for our use */
void lockport (int upsfd, const char *port)
{
	int	res, i;

	/* keep gcc quiet */
	res = i = 0;

#ifdef HAVE_UU_LOCK
	if (upsport)		/* already locked? */
		return;

	/* save for later in case we need it at shutdown */
	upsport = xstrdup(xbasename(port));

	res = uu_lock(upsport);

	if (res != 0)
		fatalx("Can't uu_lock %s: %s", upsport, uu_lockerr(res));

#else			/* no uu_lock */
#ifdef HAVE_FLOCK
	if (flock(upsfd, LOCK_EX | LOCK_NB) != 0)
		fatalx("%s is locked by another process", port);
#endif /* HAVE_FLOCK */
#endif /* HAVE_UU_LOCK */
}


void open_serial_simple(const char *port, speed_t speed, int flags)
{
	signal(SIGALRM, openfail);
	alarm(3);

	if ((upsfd = open(port, O_RDWR)) == -1)
		fatal("Unable to open %s", port);

	/* set "normal" flags - cable power, or whatever */
	if (ioctl(upsfd, TIOCMSET, &flags))
		fatal("ioctl");

	alarm(0);

	lockport(upsfd, port);

	if (speed) {
#ifndef HAVE_CFSETISPEED
#error This system lacks cfsetispeed() and has no other means to set the speed
#endif
		struct	termios	tio;

		tcgetattr(upsfd, &tio);
		cfsetispeed(&tio, speed);
		cfsetospeed(&tio, speed);
		tcsetattr(upsfd, TCSANOW, &tio);
	}
}

/* explain in full detail what's wrong when the open fails */
static void open_error(const char *port)
{
	struct	passwd	*user;
	struct	stat	fs;

	/* see if port even exists first - typo check */
	if (stat(port, &fs)) {
		printf("Can't stat() %s - did you specify a nonexistent /dev file?\n",
		       port);
		fatal("Unable to open %s", port);
		exit(1);
	}

	user = getpwuid(getuid());
	if (user)
		printf("This program is currently running as %s (UID %d)\n",
		       user->pw_name, user->pw_uid);

	user = getpwuid(fs.st_uid);
	if (user)
		printf("%s is owned by user %s (UID %d), mode %04o\n\n", port, 
		       user->pw_name, user->pw_uid, fs.st_mode & 07777);

	printf("Change the port name, or fix the permissions or ownership\n"
	       "of %s and try again.\n\n", port);

	fatal("Unable to open %s", port);
}

/* open a serial port and setup the flags properly at a given speed */
void open_serial(const char *port, speed_t speed)
{
	struct	termios	tio;
	int	fcarg;

	/* this double open code harks back to the *old* days when
         * opening the port on BSD/OS would stick miserably, requiring tip
         * to unstick it.  If nobody needs this code, it will be chopped
         * out in a couple of releases, since it's broken on NetBSD.
         */

#ifdef NEED_DOUBLE_OPEN
	signal (SIGALRM, openfail);
	alarm (3);

	/* there's a 'double open' here since this unsticks the port for us */

	upsfd = open (port, O_RDWR | O_NOCTTY | O_NONBLOCK | O_EXCL);
	alarm (0);

	if (upsfd < 0)
		open_error(port);

	upsport = NULL;
	lockport (upsfd, port);

	tcgetattr (upsfd, &tio);
	tio.c_lflag = 0 | ECHOE | ECHOKE | ECHOCTL | PENDIN;
	tio.c_iflag = 0 | IXANY | IMAXBEL | IXOFF;
	tio.c_oflag = 0 | ONLCR;
	tio.c_cflag = 0 | CREAD | CS8 | HUPCL | CLOCAL;

#ifdef HAVE_CFSETISPEED
	cfsetispeed (&tio, speed);
	cfsetospeed (&tio, speed);
#else
#error This system lacks cfsetispeed() and has no other means to set the speed
#endif

	tio.c_cc[VMIN] = 1;
	tio.c_cc[VTIME] = 0;
	tcflush (upsfd, TCIFLUSH);
	tcsetattr(upsfd, TCSANOW, &tio);
	close (upsfd);
#endif	/* NEED_DOUBLE_OPEN */

	/* reopen for normal use */

	signal (SIGALRM, openfail);
	alarm (3);

	upsfd = open (port, O_RDWR | O_NOCTTY | O_EXCL | O_NONBLOCK);
	alarm (0);

	if (upsfd < 0)
		open_error(port);

	fcarg = fcntl(upsfd, F_GETFL, 0);
	if (fcarg < 0 || fcntl(upsfd, F_SETFL, fcarg & ~O_NONBLOCK) < 0)
		fatal("Unable to clear O_NONBLOCK 2 %s", port);

	signal (SIGALRM, SIG_IGN);

	lockport (upsfd, port);

	tcgetattr (upsfd, &tio);
	tio.c_cflag = CS8 | CLOCAL | CREAD;
	tio.c_iflag = IGNPAR;
	tio.c_oflag = 0;
	tio.c_lflag = 0;
	tio.c_cc[VMIN] = 1;
	tio.c_cc[VTIME] = 0;

#ifdef HAVE_CFSETISPEED
	cfsetispeed (&tio, speed);
	cfsetospeed (&tio, speed);
#else
#error This system lacks cfsetispeed() and has no other means to set the speed
#endif

	tcflush (upsfd, TCIFLUSH);
	tcsetattr (upsfd, TCSANOW, &tio);
}

/* put a notice in the syslog */
void notice (const char *msg)
{
	upslogx(LOG_NOTICE, "Notice: %s", msg);
}

/* function for erasing "timeout"-conditions */
void nolongertimeout(void)
{
	/* if override enabled, then return without changing anything */
	if (flag_timeoutfailure == -1)
		return;

	if (flag_timeoutfailure == 1)
		upslogx(LOG_NOTICE, "Serial port read ok again");
	
	flag_timeoutfailure = 0;
	return;
}

/* signal handler for SIGALRM when trying to read */
void timeout(int sig)
{
	struct sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = SIG_DFL;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	/* if override enabled, then return without changing anything */
	if (flag_timeoutfailure == -1)
		return;

	if (flag_timeoutfailure == 0)
		upslogx(LOG_NOTICE, "Serial port read timed out");
	
	flag_timeoutfailure = 1;
	return;
}

/* wait for an answer in the form <data><endchar> and store in buf */
int upsrecv (char *buf, int buflen, char endchar, const char *ignchars)
{
	char	recvbuf[512], *ptr, in;
	int	ret, cnt;
	struct 	sigaction sa;
	sigset_t sigmask;

	strcpy (recvbuf, "");

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (3);

	ptr = recvbuf;
	*ptr = 0;
	cnt = 0;
	for (;;) {
		ret = read (upsfd, &in, 1);
		if (ret > 0) {

			if (in == endchar) {
				alarm (0);
				signal (SIGALRM, SIG_IGN);
				strlcpy (buf, recvbuf, buflen);
				if (upsc_debug > 0) {
					int i;
					printf ("upsrecv: read %d bytes [", cnt);
					for (i = 0; i < cnt; ++i)
						printf(isprint(buf[i]) ? "%c" : "\\%03o",
							   buf[i]);
					printf ("]\n");
				}
				return (buflen);
			}

			if (strchr(ignchars, in) == NULL) {
				*ptr++ = in;
				*ptr = 0; /* tie off end */
				cnt++;
			}
			
			nolongertimeout();
		}
		else {
			alarm (0);
			signal (SIGALRM, SIG_IGN);
			strlcpy (buf, recvbuf, buflen);
			return (-1);
		}

		/* keep from overrunning the buffer - lame hack */
		if (cnt > (sizeof(recvbuf) - 4)) {
			notice ("UPS is spewing wildly");
			return(-1);
		}
	}

	return (-1);	/* not reached */
}

/* send a single byte to the UPS */
int upssendchar (char data)
{
	if (upsc_debug > 0) {
		printf ("upssendchar: sending [");
		printf (isprint(data) ? "%c" : "\\%03o", data);
		printf ("]\n");
	}

	tcflush (upsfd, TCIFLUSH);
	return (write (upsfd, &data, 1));
}

int upssend(const char *fmt, ...)
{
	char buf[1024], *p;
	int bytes_sent = 0;
	va_list ap;

	va_start(ap, fmt);

	if (vsnprintf(buf, sizeof(buf), fmt, ap) >= sizeof(buf))
		; /* truncated */

	va_end(ap);

	tcflush(upsfd, TCIFLUSH);

	for (p = buf; *p; p++) {
		if (upsc_debug > 0) {
/*			printf ("upssendchar: sending [");
 *			printf (isprint(data) ? "%c" : "\\%03o", data);
 *			printf ("]\n");
 */		}

		if (write(upsfd, p, 1) != 1)
			return -1;
		bytes_sent++;
		usleep(upssend_delay);
	}

	if (upssend_endchar) {
		if (write(upsfd, &upssend_endchar, 1) != 1);
			return -1;
		bytes_sent++;
		usleep(upssend_delay);
	}

	return bytes_sent;
}

/* get data from the UPS and install it in the data array */
void installinfo (int infotype, char reqchar, char endchar, const char *ignchars)
{
	int	i, pos = 0;

	for (i = 0; i < infomax; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0)		/* not found, probably not supported */
		return;

	upssendchar (reqchar);
	upsrecv (info[pos].value, sizeof(info[pos].value), endchar, ignchars);
}

/* store data into the array */
void setinfo(int infotype, const char *fmt, ...)
{
	int	i, pos = 0;
	va_list ap;

	for (i = 0; i < infomax; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0) {	/* not found, probably debugging? */
		upslogx(LOG_ERR, "setinfo: can't find type %i\n", infotype);
		return;
	}

	va_start(ap, fmt);
	if (vsnprintf(info[pos].value, sizeof(info[pos].value), fmt, ap) >= sizeof(info[pos].value))
		; /* truncated */
	va_end(ap);
}

/* set a flag on an existing member of the array */
void setflag (int infotype, int newflags)
{
	int	i, pos = 0;

	for (i = 0; i < infomax; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0) {	/* not found, probably debugging? */
		upslogx(LOG_ERR, "setflag: can't find type %i\n", infotype);
		return;
	}

	info[pos].flags = newflags;
}

/* find data of a given type in the info array */
char *getdata (int infotype)
{
	int	i;

	for (i = 0; i < infomax; i++)
		if (info[i].type == infotype)
			return (info[i].value);
	
	return (NULL);
}

/* write shm data to state file */
static void writeshminfo(itype *writeinfo)
{
	int	sffd, ret;

	if (writeinfo[0].type != INFO_SHMID)
		fatalx("shouldn't be here");

	sffd = open(statefn, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP);
	if (sffd >= 0) {

		ret = write (sffd, writeinfo, sizeof(itype));
		if (ret >= 0) {
			close (sffd);
			return;
		}
	}
	/* ssfd < 0 || ret < 0 */
	fatal("Can't open %s", statefn);
}

void writeinfo(void)
{
	int	sffd, ret;
	struct	shmid_ds shmbuf;

	/* if data is stale, don't write it so the information ages */
	if (flag_timeoutfailure == 1)
		return;

	if (info[0].type == INFO_SHMID)
		fatalx("shouldn't be here2");

	/* if in shm mode exit immediately */
	if (shmid >= 0) {
		/* this updates the ctime that upsd wants to see */
		shmctl (shmid, IPC_STAT, &shmbuf);
		shmctl (shmid, IPC_SET, &shmbuf);
		return;
	}

	sffd = open (statefn, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP);
	if (sffd >= 0) {
		int	writelen = sizeof(itype) * infomax;

		ret = write(sffd, info, writelen);
		if (ret >= 0) {
			close (sffd);
			return;
		}
	}
	/* ssfd < 0 || ret < 0 */
	fatal("Can't open %s", statefn);
}

#ifdef HAVE_SHMAT
static void test_writeinfo(void) 
{
        int sffd = open (statefn, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP);
        int tmperr;

        /* tests a write to the file only so the user
	   can see if something is wrong before it enters the background */

	if (sffd < 0) {
		tmperr = errno;
		printf("Can't open %s: %s\n", statefn, strerror(tmperr));

		if (tmperr == EACCES) {
			struct	passwd	*user;
			user = getpwuid(getuid());

			if (user) {
				printf ("This program is currently running as "
				        "%s (UID %d)\n", user->pw_name, 
				         user->pw_uid);
			}
		}
		exit (1);
	}
	close (sffd);
}


static void cleanup(void)
{
	if (shmid == -1)
		return;

	/* mark for deletion after total detachment */
	shmctl (shmid, IPC_RMID, NULL);                

	shmdt ((char *) info);	/* detach */

	/* clean up msg queue if necessary */
#ifdef HAVE_MSGGET
	if (msgid != -1)
		msgctl (msgid, IPC_RMID, NULL);
#endif	/* HAVE_MSGGET */

#ifdef HAVE_UU_LOCK
	uu_unlock (upsport);
#endif

	unlink(statefn);
}
#endif	/* HAVE_SHMAT */

void sigdie(int sig)
{
	upslogx(LOG_INFO, "Signal %d: Shutting down", sig);
	exit (0);
}

/* install handler for sigterm */
void catch_sigterm(void)
{
	struct sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = sigdie;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGTERM, &sa, NULL);
}

void create_info (int numinfo, int shmok)
{
	int	i;
#ifdef HAVE_SHMAT
	key_t	shmkey = IPC_PRIVATE;
	itype	shminfo[1];
#endif

	infomax = numinfo;

	catch_sigterm();
	signal(SIGINT, sigdie);
	signal(SIGQUIT, sigdie);
	if (atexit(cleanup))
		fatal("atexit");

#ifdef HAVE_SHMAT
        test_writeinfo();

/*
 * The use of SHM_R and SHM_W is not portable. Neither Posix nor
 * SUSv2 specify it. Solaris and Linux have them (as well as newer
 * versions of NetBSD) but either do not document them (Solaris) or
 * explicitly depreceate their use (NetBSD).
 */ 
#ifdef SHM_R
#define IPC_MODE IPC_CREAT|SHM_R|SHM_W|S_IRGRP|S_IWGRP
#else
#define IPC_MODE IPC_CREAT|0600|S_IRGRP|S_IWGRP
#endif
        
	if (shmok == 1) {
		/* get some shared memory for the array */
		shmid = shmget (shmkey, sizeof(itype) * numinfo, 
		                IPC_MODE);

		if (shmid == -1) {
			upslog(LOG_ERR, "shmget");
			shmid = -1;
		}
		else {		/* got a good ID, now attach to it */
			info = (itype *) shmat (shmid, 0, 0);

			if (info == (itype *) (-1)) {
				upslog(LOG_ERR, "shmat");
				shmid = -1;
			}
		}

		if (shmid != -1) {
			/* create state file with SHM id */
			shminfo[0].type = INFO_SHMID;
			snprintf (shminfo[0].value, sizeof(shminfo[0].value), 
			          "%i", shmid);
		
			writeshminfo(shminfo);
		}
	}	/* if shmok == 1 */

#endif	/* HAVE_SHMAT */

	if (shmid == -1) {	/* shm failed or is disabled - fallback */
		info = xcalloc (numinfo, sizeof(itype));
	}

	/* initialize the array */
	for (i = 0; i < infomax; i++)
		info[i].type = INFO_UNUSED;

	infoused++;
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, VALSIZE, "%i", infomax);
}

/* add a member to the info struct */
void addinfo (int type, const char *value, int flags, int auxdata)
{
	int	i;

	for (i = 0; i < infomax; i++) {
		if (info[i].type == INFO_UNUSED) {	/* found open spot */
			infoused++;
			info[i].type = type;
			strlcpy(info[i].value, value, sizeof(info[i].value));
			info[i].flags = flags;
			info[i].auxdata = auxdata;
			return;
		}
	}

	upslogx(LOG_ERR, "Unable to add new member to info array!");

	return;
}

/* add a new ENUM info entry and do other related housekeeping */
void addenum (int basetype, const char *value)
{
	int	i;

	/* first find the basetype in the struct */
	for (i = 0; i < infomax; i++)
		if (info[i].type == basetype) {

			/* add the enum value, then increment the enum count */
			addinfo (INFO_ENUM, value, 0, basetype);
			info[i].auxdata++;
			return;
		}

	upslogx(LOG_ERR, "Unable to add enumerated type for base 0x%04x", basetype);

	return;
}

#ifndef HAVE_MSGGET

/* stubs */
void createmsgq(void) {}

/* this *has* to sleep, or the caller will burn up lots of CPU */
int getupsmsg(int wait) 
{
	sleep(wait);
}

void sendupsmsg(msgtype *buf) {}

#else

/* create a SysV IPC message queue */

void msgget_fail(int signal)
{
	upslogx(LOG_ERR, "Can't create message queue! (SIGSYS)");
	return;
}

void createmsgq(void)
{
	char	tempid[16];

	/* init handlers early */
	memset (&upsh, '\0', sizeof(upsh));

	/* FreeBSD throws SIGSYS if sysv messaging isn't in the kernel */
#ifdef SIGSYS
	signal (SIGSYS, msgget_fail);
#endif
	msgid = msgget (IPC_PRIVATE, IPC_CREAT | 0660);
#ifdef SIGSYS
	signal (SIGSYS, SIG_IGN);
#endif

	if (msgid == -1) {
		upslog(LOG_ERR, "msgget");
		return;
	}

	snprintf (tempid, sizeof(tempid), "%i", msgid);
	addinfo (INFO_MSGID, tempid, 0, 0);
}

/* handler for when msgrcv times out */
void nomsg(int sig)
{
	return;
}

/* make our own struct since some systems don't have struct msgbuf */
typedef struct {
	long    mtype;
	msgtype	msg;
}       mbuf;           

/* get a message if one's waiting in the queue */
int getupsmsg(int wait)
{
	mbuf	*mb;
	int	ret;

	/* if no queue exists, still sleep since the caller is expecting it */
	if (msgid == -1) {
		sleep(wait);
		return 0;
	}

	mb = xmalloc(sizeof(mbuf) + UPSMSG_MAXLEN);

	/* set up alarm handler and schedule an alarm */
	signal(SIGALRM, nomsg);
	alarm(wait);

	ret = msgrcv(msgid, (struct msgbuf *) mb, UPSMSG_MAXLEN, UPSMSG_TOMODEL, 0);

	/* cancel the alarm */
	alarm(0);
	signal(SIGALRM, SIG_IGN);

	if (ret == -1) {
		free(mb);
		return 0;	/* no msg received */
	}

	/* now parse the message and deal with it */
	switch (mb->msg.cmdtype) {
		case UPSMSG_CMDSET:
			if (upsh.setvar)
				upsh.setvar(mb->msg.auxcmd, mb->msg.dlen,
				            &mb->msg.data);
			break;
		case UPSMSG_INSTCMD:
			if (upsh.instcmd)
				upsh.instcmd(mb->msg.auxcmd, mb->msg.dlen,
				             &mb->msg.data);
			break;
		default: 
			upslogx(LOG_INFO, "Unknown msgcmd 0x%04x",
			        mb->msg.cmdtype);
	}		

	free(mb);
	return 1;	/* msg received */
}

/* send a message to the upsd process */
void sendupsmsg (const msgtype *buf)
{
	mbuf	*mb;
	int	ret;

	if (msgid == -1)	/* no queue was created */
		return;

	mb = xmalloc (sizeof(mbuf) + UPSMSG_MAXLEN);

	mb->mtype = UPSMSG_TOUPSD;
	memcpy (&mb->msg, buf, UPSMSG_MAXLEN);

	ret = msgsnd (msgid, (struct msgbuf *) mb, UPSMSG_MAXLEN, 0);
	free (mb);
}

#endif	/* HAVE_MSGGET */

void msgreply (int reptype)
{
	msgtype	msg;

	msg.cmdtype = reptype;
	msg.auxcmd = 0;
	msg.dlen = 0;
	msg.data = '\0';

	sendupsmsg (&msg);
}

#ifdef OLD_RTRIM
char *rtrim(char *in)
{
   int  i;
   char tmp[256];
 
   strlcpy(tmp, in, sizeof(tmp));
 
   for (i = 0; i < strlen(tmp); i++)
      if (tmp [i] == ' ') tmp[i] = 0;
 
   return(xstrdup(tmp));
}

#else

char *rtrim(char *in, char sep)
{
	char *p = strchr(in, sep);

	if (p)
		*p++ = '\0';
	return p;
}
#endif

/* try to unlock the port using any methods that are available */
void unlockport (int upsfd, const char *port)
{
	int	res, i;

	/* keep gcc quiet */
	res = i = 0;

#ifdef HAVE_UU_LOCK
	if (!upsport)		/* not already locked? */
		return;

	res = uu_unlock(upsport);

	/* free up allocated memory */
	free(upsport);

	if (res != 0)
		fatalx("Can't uu_unlock %s: %s", upsport, uu_lockerr(res));

#else			/* no uu_lock */
#ifdef HAVE_FLOCK
	if (flock(upsfd, LOCK_UN) != 0)
		fatalx("can't unlock %s!", port);
#endif /* HAVE_FLOCK */
#endif /* HAVE_UU_LOCK */
}
