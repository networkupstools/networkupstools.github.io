/* 
   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include "main.h"

// need a way to set this dynamically
#define INFOMAX  32

	char	statefn[256], pidfn[256];
	unsigned int sddelay = 90;	/* wait 90 seconds for shutdown */
	int	debug_level = 0;
	const char *progname = NULL;
	const char *device_name = NULL, *device_path = NULL;
	const char *statepath = NULL;
	int	do_forceshutdown = 0;
	varlist_t	*vlhead = NULL;

/* power down the attached load immediately */
static void forceshutdown(void)
{
	upslogx(LOG_NOTICE, "Initiating UPS shutdown");
	printf("Initiating forced UPS shutdown!\n");

	upsdrv_shutdown();

	if (sddelay > 0) {
		printf("Waiting for poweroff...\n");
		sleep(sddelay);
		printf("Hmm, did the shutdown fail?  Oh well...\n");
		exit(1);
	}
	exit(0);
}

void usage(void)
{
	printf ("usage: %s [-h] [-d <num>] [-k] [-x <var>=<val>] <device>\n", 
	        progname);
	printf("\n");
	printf("Example: %s /dev/ttyS0\n", progname);
	exit(1);
}

void help(void)
{
	printf ("usage: %s [-h] [-d <num>] [-k] [-x <var>=<val>] <device>\n", 
	        progname);

	printf (
		"-d <num>	- wait <num> seconds after sending shutdown command\n"
		"-k		- force shutdown\n"
		"-h		- display this help\n"
		"-x <var>=<val>	- set driver variable <var> to <val>\n"
		"		- example: -x cable=940-0095B\n"
		"\n"
		"<device> - /dev entry corresponding to UPS port\n"
		"\n");

	upsdrv_help();
	exit(1);
}

/* split inbuf into <var>[=<val>] pairs and store it */
static void storeval(char *inbuf)
{
	char	*eqptr, *val, *buf;
	varlist_t	*tmp, *last;

	/* make our own copy - avoid changing argv */
	buf = xstrdup(inbuf);

	eqptr = strchr(buf, '=');

	if (!eqptr)
		val = NULL;
	else {
		*eqptr++ = '\0';
		val = eqptr;
	}

	tmp = last = vlhead;

	while (tmp) {
		last = tmp;

		/* overwrite existing values */
		if (!strcasecmp(tmp->var, buf)) {
			if (tmp->val)
				free(tmp->val);
			tmp->val = xstrdup(val);
			return;
		}

		tmp = tmp->next;
	}

	tmp = malloc(sizeof(varlist_t));
	tmp->var = buf;

	/*
	 * copying val looks like a waste, but if we call free on it above,
	 * then we had better pass it a real pointer, rather than an offset! 
	 */

	if (val)
		tmp->val = xstrdup(val);
	else
		tmp->val = NULL;

	tmp->next = NULL;

	if (last)
		last->next = tmp;
	else
		vlhead = tmp;
}

/* retrieve the value of variable <var> if possible */
char *getval(char *var)
{
	varlist_t	*tmp = vlhead;

	while (tmp) {
		if (!strcasecmp(tmp->var, var))
			return(tmp->val);
		tmp = tmp->next;
	}

	return NULL;
}

/* see if <var> has been defined, even if no value has been given to it */
int testvar(char *var)
{
	varlist_t	*tmp = vlhead;

	while (tmp) {
		if (!strcasecmp(tmp->var, var))
			return 1;		/* found */
		tmp = tmp->next;
	}

	return 0;	/* not found */
}

int main(int argc, char **argv)
{
	int	i;

	droproot();

	upsdrv_banner();

	progname = basename(argv[0]);
	openlog(progname, LOG_PID, LOG_FACILITY);

	if ((statepath = getenv("NUT_STATEPATH")) == NULL)
		statepath = STATEPATH;

	/* FUTURE: parse ups.conf here */

	while ((i = getopt(argc, argv, "+d:k:Dhx:")) != EOF) {
		switch (i) {
			case 'd':
				sddelay = atoi(optarg);
				break;
			case 'k':
				do_forceshutdown = 1;
				break;
			case 'D':
				debug_level++;
				break;
			case 'V':
				printf("Network UPS Tools (%s)\n", UPS_VERSION);
				exit(0);
			case 'x':
				storeval(optarg);
				break;
			case 'h':
				help();
				break;
			default:
				usage();
				break;
		}
	}

	argc -= optind;
	argv += optind;
	optind = 1;

	if (argc < 1)
		usage();

	device_path = argv[0];
	device_name = basename(device_path);

	snprintf(statefn, sizeof(statefn), "%s/%s-%s", statepath, progname, device_name);
	snprintf(pidfn, sizeof(pidfn), "%s/%s-%s.pid", STATEPATH, progname, device_name);

	upsdrv_initups();

	if (chdir(statepath))
		fatal("Can't chdir to %s", statepath);

	if (do_forceshutdown)
		forceshutdown();

	create_info(INFOMAX, 1);
	createmsgq();

	upsdrv_initinfo();

	if (debug_level == 0) {
		background();
//		writepid(pidfn);
	}

	for (;;) {
		upsdrv_updateinfo();

		if (getupsmsg(2))       
			upslogx(LOG_DEBUG, "Received a message from upsd");
	}

	return 0;
}
