#include <stdarg.h>
#include <sys/types.h>
#include "config.h"
#include "proto.h"
#include "shared.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"

/* public functions & variables from main.c */
extern const char *progname;
extern const char *device_name;
extern const char *device_path;
void help(void);
void usage(void);

/* functions & variables required in each driver */
// extern const char *upsdrv_version;
void upsdrv_initups(void);
void upsdrv_initinfo(void);
void upsdrv_updateinfo(void);
void upsdrv_shutdown(void);
void upsdrv_help(void);
void upsdrv_usage(void);
void upsdrv_banner(void);
void upsdrv_arg(int i, char *optarg);
extern const char *driver_arguments;

/* details for the variable/value sharing */

typedef struct {   
        char    *var;
        char    *val;
        void    *next;
}       varlist_t;

extern	varlist_t	*vlhead;

/* retrieve the value of variable <var> if possible */
char *getval(char *var);

/* see if <var> has been defined, even if no value has been given to it */
int testvar(char *var);
