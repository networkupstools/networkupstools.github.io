/* 
   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include "main.h"

// need a way to set this dynamically
#define INFOMAX  32

	char	statefn[256], pidfn[256];
	unsigned int sddelay = 90;	/* wait 90 seconds for shutdown */
	int	debug_level = 0;
	const char *progname = NULL;
	const char *device_name = NULL, *device_path = NULL;
	const char *statepath = NULL;
	int	do_forceshutdown = 0;

/* power down the attached load immediately */
static void forceshutdown(void)
{
	upslogx(LOG_NOTICE, "Initiating UPS shutdown");
	printf("Initiating forced UPS shutdown!\n");

	upsdrv_shutdown();

	if (sddelay > 0) {
		printf("Waiting for poweroff...\n");
		sleep(sddelay);
		printf("Hmm, did the shutdown fail?  Oh well...\n");
		exit(1);
	}
	exit(0);
}

void usage(void)
{
	printf("\nusage: %s [-h] [-d <num>] [-k] <device> [-h] ", progname);
	upsdrv_usage();
	printf("\n");
	printf("Example: %s /dev/ttyS0\n", progname);
	exit(1);
}

void help(void)
{
	printf ("usage: %s [-h] [-d <num>] [-k] <device> [-h] ", progname);
	upsdrv_usage();
	printf ("\n\n"
		"common options are:\n"
		"-d <num> - wait <num> seconds after sending shutdown command\n"
		"-k       - force shutdown\n"
		"-h       - display this help\n"
		"\n"
		"<device> - /dev entry corresponding to UPS port\n"
		"\n"
		"device specific options are:\n");
	upsdrv_help();
	printf ("-h       - display this help\n");
	exit(1);
}

int main(int argc, char **argv)
{
	int	i;
static	char	arglist[SMALLBUF] = "+d:k:Dh";

	droproot();

	upsdrv_banner();

	progname = basename(argv[0]);
	openlog(progname, LOG_PID, LOG_FACILITY);

	if ((statepath = getenv("NUT_STATEPATH")) == NULL)
		statepath = STATEPATH;

	if (driver_arguments)
		strlcat(arglist, driver_arguments, sizeof(arglist));

	while ((i = getopt(argc, argv, arglist)) != EOF) {
		switch (i) {
			case 'd':
				sddelay = atoi(optarg);
				break;
			case 'k':
				do_forceshutdown = 1;
				break;
			case 'D':
				debug_level++;
				break;
			case 'V':
				printf("Network UPS Tools (%s)\n", UPS_VERSION);
				exit(0);
			case 'h':
				help();
				break;
			default:

				/* no driver args means this was invalid */
				if (!driver_arguments)
					usage();

				/* not found in driver args, same idea */
				if (!strchr(driver_arguments, i))
					usage();

				/* otherwise let the driver figure it out */
				upsdrv_arg(i, optarg);
				break;
		}
	}

	argc -= optind;
	argv += optind;
	optind = 1;

	if (argc < 1)
		usage();

	device_path = argv[0];
	device_name = basename(device_path);

	snprintf(statefn, sizeof(statefn), "%s/%s-%s", statepath, progname, device_name);
	snprintf(pidfn, sizeof(pidfn), "%s/%s-%s.pid", PIDPATH, progname, device_name);

	upsdrv_initups();

	if (chdir(statepath))
		fatal("Can't chdir to %s", statepath);

	if (do_forceshutdown)
		forceshutdown();

	create_info(INFOMAX, 1);
	createmsgq();

	upsdrv_initinfo();

	if (debug_level == 0) {
		background();
//		writepid(pidfn);
	}

	for (;;) {
		upsdrv_updateinfo();

		if (getupsmsg(2))       
			upslogx(LOG_DEBUG, "Received a message from upsd");
	}

	return 0;
}
