#define UPS_VERSION "0.45.0-pre2"
