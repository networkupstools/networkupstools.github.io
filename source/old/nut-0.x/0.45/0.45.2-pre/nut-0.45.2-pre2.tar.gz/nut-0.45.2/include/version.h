#define UPS_VERSION "0.45.2-pre2"
