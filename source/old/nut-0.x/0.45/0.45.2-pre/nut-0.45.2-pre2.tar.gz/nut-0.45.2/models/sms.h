/* sms.h - model capability table to SMS Ltda ( brazilian ups )

   This code is derived from Russell Kroll <rkroll@exploits.org>,
   Fenton UPS Driver

   Copyright (C) 2001  Marcio Gomes  <tecnica@microlink.com.br>
   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

   2001/05/17 - Version 0.1 - Initial release 
   2001/06/01 - Version 0.2 - Add Battery Informations in driver
   2001/06/04 - Version 0.3 - Updated Battery Volts range, to reflect a correct
                              percent ( % )
 
   Microlink ISP contributed with MANAGER III 1300, MANAGER III 650 UPS 
   for my tests
   
*/

struct {
	char	*mtext;
	char	*desc;
	float	lowvolt;
	float	voltrange;
	int	lowxfer;
	int	lownorm;
	int	highnorm;
	int	highxfer;
	int	has_temp;
}	modeltab[] =
{

   
	/* Manager III models */
        
	{ "1300",  "Manager III 1300",  9.6,  3.8, 84, 98, 126, 142, 1 },
	/* non SMS, yet compatible models */
	{ NULL,    NULL,		  0, 0,   0,   0,   0,   0, 0 }
};
