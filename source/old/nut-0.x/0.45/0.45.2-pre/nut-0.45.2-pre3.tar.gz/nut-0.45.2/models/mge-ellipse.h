/* defines related to nut */

#define INFOMAX 9


/* Ellipse command set */
#define PING "\x16"
#define L_PING 1
#define NACK "\x15"
#define L_NACK 1
#define BATT_STATUS "\x06\x81\x88\xA1\x01\x16\x03\x00\x00\x20\x00\x95"
#define BATT_STATUS_TYPE 0x16
#define BATT_STATUS_DATALEN 4
#define L_CMDPKT 12
#define POWER_STATUS "\x06\x81\x88\xA1\x01\x02\x03\x00\x00\x20\00\x81"
#define POWER_STATUS_TYPE 0x02
#define POWER_STATUS_DATALEN 3
#define LOAD_LEVEL "\x06\x81\x88\xA1\x01\x0E\x03\x00\x00\x00\x18\xB5"
#define LOAD_LEVEL_TYPE 0x0E
#define LOAD_LEVEL_DATALEN 3
#define UNKNOWN1 "\x06\x81\x88\xA1\x01\x01\x03\x00\x00\x20\x00\x82"
#define UNKNOWN1_TYPE 0x01
#define UNKNOWN1_DATALEN 2
#define AUTO_RESTART "\x06\x81\x88\xA1\x01\x11\x03\x00\x00\x20\x00\x92"
#define AUTO_RESTART_TYPE 0x11
#define AUTO_RESTART_DATALEN 4
#define KILL_POWER "\x06\x81\x88\xA1\x01\x0F\x03\x00\x00\x20\x00\x8C"
#define KILL_POWER_TYPE 0x0F
#define KILL_POWER_DATALEN 4

/* functions
 * for Ellipse */
void usage(char *progname);
void instcmd(int cmd, int datalen, char *data);
int e_ups_start(void);
int e_kill_power();
int e_ups_status(void);
int e_ups_load(void);
int e_battery_charge(void);
int e_autonomy(void);
int e_set_autorestart(void);
char *e_packet_recv(char pkt_type, int datalen);
void setline(int set);
void initinfo(void);
int serial_read(void);
int serial_send(char *buf, int len);
void debug_message(const char * msg, ...);
void dump_hex(const char *msg, const unsigned char *buf, int len);
