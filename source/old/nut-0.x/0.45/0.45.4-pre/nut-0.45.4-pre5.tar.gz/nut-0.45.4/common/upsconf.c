/* upsconf.c - code for handling ups.conf ini-style parsing

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "upsconf.h"
#include "common.h"

/* open the ups.conf, parse it, and call back do_upsconf_args() */
void read_upsconf(int required)
{
	int	ret, ln = 0;
	FILE	*conf;
	char	fn[SMALLBUF], buf[SMALLBUF], *arg[5], *ep;
	char	*upsname, *driver, *port, *val;

	upsname = driver = port = NULL;

	snprintf(fn, sizeof(fn), "%s/ups.conf", CONFPATH);
	conf = fopen(fn, "r");

	if (!conf) {
		if (required)
			fatal("fopen %s", fn);
		else
			return;
	}

	while(fgets(buf, sizeof(buf), conf)) {
		buf[strlen(buf) - 1] = '\0';

		ret = parseconf(fn, ++ln, buf, arg, 5);

		if (ret == 0)
			continue;

		if (!arg[0])
			continue;

		if ((arg[0][0] == '[') && (arg[0][strlen(arg[0])-1] == ']')) {
			if (upsname)
				free(upsname);

			/* strip off [] */
			upsname = xstrdup(arg[0] + 1);	
			upsname[strlen(upsname) - 1] = '\0';
			continue;
		}

		/* handle 'foo=bar' (compressed form) */
		ep = strchr(arg[0], '=');
		if (ep) {
			val = ep + 1;
			*ep = '\0';
			do_upsconf_args(upsname, arg[0], val);
			continue;
		}

		/* handle 'foo' (flag) */
		if (!arg[1]) {
			do_upsconf_args(upsname, arg[0], NULL);
			continue;
		}

		/* handle 'foo = bar' (split form) */
		if (!strcmp(arg[1], "=")) {
			do_upsconf_args(upsname, arg[0], arg[2]);
			continue;
		}
	}

	fclose(conf);
}
