/* upssched.h - supporting structures */

/* internal values for the unix domain socket */
#define CMD_START_TIMER 1
#define CMD_CANCEL_TIMER 2

/* what actually goes over the socket */
#define CMDMAGIC 0xf00fc7c8

typedef struct {
	int     magic;
	int     cmd;
	char    data1[SMALLBUF]; 
	char    data2[SMALLBUF];
}	cmdtype;
