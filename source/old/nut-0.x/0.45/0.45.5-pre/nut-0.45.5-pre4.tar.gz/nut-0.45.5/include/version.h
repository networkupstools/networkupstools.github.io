#define UPS_VERSION "0.45.5-pre4"
