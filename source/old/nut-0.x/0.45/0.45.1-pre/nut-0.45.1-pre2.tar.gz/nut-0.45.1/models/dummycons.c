/* dummyups.c - Dummy model driver for testing shutdowns nondestructively

   Copyright (C) 2000  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

#define _MIT_POSIX_THREADS 1
#include <pthread.h>

/* TODO: this may need to be much bigger */
#define INFO_MAX 64

#include "config.h"
#include "proto.h"
#include "shared.h"
#include "shared-tables.h"
#include "version.h"
#include "upscommon.h"
#include "genericups.h"
#include "common.h"

	char	statefn[256];

	static	pthread_t	thread;
	static	pthread_attr_t	threadattr;

void initinfo (void)
{
	create_info (INFO_MAX, 1);

	/* setup the basics */

	addinfo (INFO_MFR, "Console testing", 0, 0);
	addinfo (INFO_MODEL, "Dummy UPS", 0, 0);
	addinfo (INFO_STATUS, "OL", 0, 0);
}

/* background thread - keep the struct current so upsd is happy */
static void *updateinfo (void *ptr)
{
	for (;;) {
/*		printf ("writeinfo\n"); */
		writeinfo();
		sleep (2);
	}
}

#if 0
/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	/* TODO: future */
}
#endif

void do_help(void)
{
	printf("Network UPS Tools dummycons help\n\n");
	printf("? / h / help	- show this help\n");
	printf("a / add VAR VAL	- add variable VAR with value VAR\n");
	printf("l / list	- show current variables in use\n");
	printf("L / List	- show all possible variables and settings\n");
	printf("s / set VAR VAL - set variable VAR to VAL\n");
	printf("q / quit	- quit\n");
	printf("\n");
	printf("Values can use \"quotes\" to store values with embedded spaces.\n");
}

void do_set(char *var, char *val)
{
	int	i;
	char	*dp = NULL;

	if ((!var) || (!val)) {
		printf("Error: need variable and desired values as arguments.\n");
		return;
	}

	for (i = 0; netvars[i].name != NULL; i++)
		if (!strcasecmp(netvars[i].name, var)) {
			dp = getdata(netvars[i].type);

			if (!dp) {
				printf("Error: %s doesn't exist yet.  (Use 'add' before calling set)\n",
					var);
				return;
			}

			printf("INFO_%s = %s\n", netvars[i].name, val);
			setinfo(netvars[i].type, "%s", val);
			return;
		}

	printf("Error: %s unrecognized.\n", var);
}

void do_list(int all)
{
	int	i;
	char	*dp, vn[50];

	for (i = 0; netvars[i].name != NULL; i++) {
		dp = getdata(netvars[i].type);

		snprintf(vn, sizeof(vn), "INFO_%s (%s)", netvars[i].name,
			netvars[i].desc);

		if (!dp) {
			if (all) {
				printf("%-50s = (undefined)\n", vn);
			}
		}
		else
			printf("%-50s = %s\n", vn, dp);
	}
}	

void do_quit(void)
{
	/* TODO: anything special to bring down the other thread? */
	exit(0);
}

void do_add(char *var, char *val)
{
	int	i;

	if ((!var) || (!val)) {
		printf("Error: need variable and desired values as arguments.\n");
		return;
	}

	/* TODO: handle special types (enums, etc) */
	for (i = 0; netvars[i].name != NULL; i++) {
		if (!strcasecmp(netvars[i].name, var)) {
			addinfo(netvars[i].type, val, 0, 0);
			printf("INFO_%s = %s\n", netvars[i].name, val);
			return;
		}
	}

	printf("Error: %s unrecognized.\n", var);
}

int main (int argc, char **argv)
{
	int	res;
	char	status[32], buf[128], *portname;
	char	*arg[3];

	printf ("Network UPS Tools - Dummy console UPS driver 0.10 (%s)\n", UPS_VERSION);

	if (argc < 2)
		portname = "null";
	else
		portname = argv[1];

	snprintf (statefn, sizeof(statefn), "%s/dummycons-%s", STATEPATH, portname);

	printf ("State file: %s\n", statefn);

	droproot();
	initinfo();

	pthread_attr_init(&threadattr);
	pthread_attr_setscope(&threadattr, PTHREAD_SCOPE_SYSTEM);
	res = pthread_create (&thread, &threadattr, updateinfo, NULL);

	strcpy (status, "OL");

	for (;;) {
		printf("Command (? for help): ");
		fflush(stdout);
		fgets(buf, sizeof(buf), stdin);

		if (!strncmp(buf, "?", 1))
			do_help();

		res = parseconf(NULL, 0, buf, arg, 3);

		if (res < 1)
			continue;

		if (!strcmp(arg[0], "set"))
			do_set(arg[1], arg[2]);

		if (!strcmp(arg[0], "s"))
			do_set(arg[1], arg[2]);

		if (!strcmp(arg[0], "quit"))
			do_quit();

		if (!strcmp(arg[0], "q"))
			do_quit();

		if (!strcmp(arg[0], "list"))
			do_list(0);

		if (!strcmp(arg[0], "l"))
			do_list(0);

		if (!strcmp(arg[0], "List"))
			do_list(1);

		if (!strcmp(arg[0], "L"))
			do_list(1);

		if (!strcmp(arg[0], "help"))
			do_help();

		if (!strcmp(arg[0], "h"))
			do_help();

		if (!strcmp(arg[0], "a"))
			do_add(arg[1], arg[2]);

		if (!strcmp(arg[0], "add"))
			do_add(arg[1], arg[2]);
	}
}
