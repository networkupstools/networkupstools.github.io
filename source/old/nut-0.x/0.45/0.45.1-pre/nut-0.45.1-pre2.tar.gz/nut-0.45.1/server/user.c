/* user.c - user handling functions for upsd

   Copyright (C) 2001  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include "upsd.h"
#include "user.h"

	extern	instcmds_t instcmds[];
	extern	acltype	*firstacl;
	ulist_t	*users = NULL;

/* create a new user entry */
void user_add(const char *un)
{
	ulist_t	*tmp, *last;

	if (!un)
		return;
	
	tmp = last = users;

	while (tmp) {
		last = tmp;

		if (!strcmp(tmp->username, un)) {
			fprintf(stderr, "Ignoring duplicate user %s\n", un);
			return;
		}

		tmp = tmp->next;
	}

	tmp = malloc(sizeof(ulist_t));
	tmp->username = strdup(un);
	tmp->firstacl = NULL;
	tmp->password = NULL;
	tmp->firstcmd = NULL;
	tmp->firstaction = NULL;
	tmp->next = NULL;

	if (last)
		last->next = tmp;
	else
		users = tmp;	
}

acllist *addallow(acllist *base, char *acl)
{
	acllist	*tmp, *last;

	if (!acl)
		return base;

	tmp = last = base;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = malloc(sizeof(acltype));
	tmp->aclname = strdup(acl);
	tmp->next = NULL;

	if (last) {
		last->next = tmp;
		return base;
	}

	return tmp;
}

/* attach allowed hosts to user */
void user_allow(const char *un, char *h1, char *h2, char *h3, char *h4, char *h5)
{
	ulist_t	*tmp = users;

	while (tmp) {
		if (!strcmp(tmp->username, un)) {

			/* ugh ... */
			tmp->firstacl = addallow(tmp->firstacl, h1);
			tmp->firstacl = addallow(tmp->firstacl, h2);
			tmp->firstacl = addallow(tmp->firstacl, h3);
			tmp->firstacl = addallow(tmp->firstacl, h4);
			tmp->firstacl = addallow(tmp->firstacl, h5);
			return;
		}

		tmp = tmp->next;
	}

	fprintf(stderr, "Ignoring allow definition for nonexistent user %s\n", un);
}

/* set password */
void user_password(const char *un, const char *pw)
{
	ulist_t	*tmp = users;

	if ((!un) || (!pw))
		return;

	while (tmp) {
		if (!strcmp(tmp->username, un)) {
			if (tmp->password) {
				fprintf(stderr, "Ignoring duplicate password for %s\n", un);
				return;
			}

			tmp->password = strdup(pw);
			return;
		}

		tmp = tmp->next;
	}

	fprintf(stderr, "Ignoring password definition for nonexistent user %s\n", un);
}

instcmdlist *addinstcmd(instcmdlist *base, char *cmd)
{
	instcmdlist	*tmp, *last;
	int	cmdnum = -1, i;

	if (!cmd)
		return base;

	tmp = last = base;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	/* 'all' is a special case */
	if (!strcasecmp(cmd, "all"))
		cmdnum = CMD_ALL;
	else {
		for (i = 0; instcmds[i].name != NULL; i++)
			if (!strcasecmp(instcmds[i].name, cmd)) {
				cmdnum = instcmds[i].cmd;
				break;
			}		
	}

	if (cmdnum == -1) {
		fprintf(stderr, "Ignoring unknown command name: %s\n", cmd);
		return base;
	}

	tmp = malloc(sizeof(instcmdlist));
	tmp->cmd = cmdnum;
	tmp->next = NULL;

	if (last) {
		last->next = tmp;
		return base;
	}

	return tmp;
}

/* attach allowed instcmds to user */
void user_add_instcmds(char *un, char *c1, char *c2, char *c3, char *c4, char *c5)
{
	ulist_t	*tmp = users;

	while (tmp) {
		if (!strcmp(tmp->username, un)) {

			/* ugh ... */
			tmp->firstcmd = addinstcmd(tmp->firstcmd, c1);
			tmp->firstcmd = addinstcmd(tmp->firstcmd, c2);
			tmp->firstcmd = addinstcmd(tmp->firstcmd, c3);
			tmp->firstcmd = addinstcmd(tmp->firstcmd, c4);
			tmp->firstcmd = addinstcmd(tmp->firstcmd, c5);
			return;
		}

		tmp = tmp->next;
	}

	fprintf(stderr, "Ignoring instcmds definition for nonexistent user %s\n", un);
}

actionlist *addaction(actionlist *base, char *action)
{
	actionlist	*tmp, *last;

	if (!action)
		return base;

	tmp = last = base;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = malloc(sizeof(actionlist));
	tmp->action = strdup(action);
	tmp->next = NULL;

	if (last) {
		last->next = tmp;
		return base;
	}

	return tmp;
}

/* attach allowed actions to user */
void user_add_actions(char *un, char *a1, char *a2, char *a3, char *a4, char *a5)
{
	ulist_t	*tmp = users;

	while (tmp) {
		if (!strcmp(tmp->username, un)) {

			/* ugh ... */
			tmp->firstaction = addaction(tmp->firstaction, a1);
			tmp->firstaction = addaction(tmp->firstaction, a2);
			tmp->firstaction = addaction(tmp->firstaction, a3);
			tmp->firstaction = addaction(tmp->firstaction, a4);
			tmp->firstaction = addaction(tmp->firstaction, a5);
			return;
		}

		tmp = tmp->next;
	}

	fprintf(stderr, "Ignoring action definition for nonexistent user %s\n", un);
}

void user_load(void)
{
	FILE	*uf;
	char	ufn[SMALLBUF], buf[SMALLBUF], *arg[8];
	int	ln = 0, i;

	snprintf(ufn, sizeof(ufn), "%s/upsd.users", CONFPATH);

	uf = fopen(ufn, "r");

	/* this file is not required, so this isn't fatal */
	if (!uf) {
		syslog(LOG_INFO, "Can't open %s/upsd.users", CONFPATH);
		return;
	}

	ln = 0;
	while (fgets(buf, sizeof(buf), uf)) {
 		buf[strlen(buf) - 1] = '\0';

		i = parseconf("upsd.users", ++ln, buf, arg, 8);
		if (i == 0)
			continue;

		/* user <username> */
		if (!strcasecmp(arg[0], "user")) {
			user_add(arg[1]);
			continue;
		}

		/* ugh: this should be open ended instead of limited to 5 */

		/* allow <username> <host1> ... <host5> */
		if (!strcasecmp(arg[0], "allow")) {
			user_allow(arg[1], arg[2], arg[3], arg[4], arg[5],
			           arg[6]);
			continue;
		}

		/* password <username> <password> */
		if (!strcasecmp(arg[0], "password")) {
			user_password(arg[1], arg[2]);
			continue;
		}

		/* ugh: same thing as allow here */

		/* instcmds <username> <command1> ... <command5> */
		if (!strcasecmp(arg[0], "instcmds")) {
			user_add_instcmds(arg[1], arg[2], arg[3], arg[4], 
			                  arg[5], arg[6]);
			continue;
		}

		/* actions <username> <action1> ... <action5> */
		if (!strcasecmp(arg[0], "actions")) {
			user_add_actions(arg[1], arg[2], arg[3], arg[4], arg[5],
			                 arg[6]);
			continue;
		}
	}

	fclose(uf);
}

int user_matchacl(ulist_t *user, struct sockaddr_in *addr)
{
	acllist	*tmp = user->firstacl;

	/* no acls means no access (fail-safe) */
	if (!tmp)
		return 0;		/* good */

	while (tmp) {
		if (checkacl(tmp->aclname, addr) == 1)
			return 1;	/* good */
	
		tmp = tmp->next;
	}

	return 0;	/* fail */
}

int user_matchinstcmd(ulist_t *user, int cmd)
{
	instcmdlist	*tmp = user->firstcmd;

	/* no commands means no access (fail-safe) */
	if (!tmp)
		return 0;	/* fail */

	while (tmp) {
		if ((tmp->cmd == cmd) || (tmp->cmd == CMD_ALL))
			return 1;	/* good */
		tmp = tmp->next;
	}

	return 0;	/* fail */
}

int user_checkinstcmd(struct sockaddr_in *addr, char *username, char *password,
               int cmd)
{
	ulist_t	*tmp = users;

	while (tmp) {

		/* let's be paranoid before we call strcmp */

		if ((!tmp->username) || (!tmp->password) ||
		   (!username) || (!password)) {
			tmp = tmp->next;
			continue;
		}

		if (!strcmp(tmp->username, username)) {
			if (!strcmp(tmp->password, password)) {
				if (!user_matchacl(tmp, addr))
					return 0;		/* fail */

				if (!user_matchinstcmd(tmp, cmd))
					return 0;		/* fail */

				/* passed all checks */
				return 1;	/* good */
			}

			/* password mismatch */
			return 0;	/* fail */
		}

		tmp = tmp->next;
	}		

	/* username not found */
	return 0;	/* fail */
}

int user_matchaction(ulist_t *user, char *action)
{
	actionlist	*tmp = user->firstaction;

	/* no actions means no access (fail-safe) */
	if (!tmp)
		return 0;	/* fail */

	while (tmp) {
		if (!strcasecmp(tmp->action, action))
			return 1;	/* good */
		tmp = tmp->next;
	}

	return 0;	/* fail */
}

int user_checkaction(struct sockaddr_in *addr, char *username, char *password,
                     char *action)
{
	ulist_t	*tmp = users;

	while (tmp) {

		/* let's be paranoid before we call strcmp */

		if ((!tmp->username) || (!tmp->password) ||
		   (!username) || (!password)) {
			tmp = tmp->next;
			continue;
		}

		if (!strcmp(tmp->username, username)) {
			if (!strcmp(tmp->password, password)) {
				if (!user_matchacl(tmp, addr))
					return 0;		/* fail */

				if (!user_matchaction(tmp, action))
					return 0;		/* fail */

				/* passed all checks */
				return 1;	/* good */
			}

			/* password mismatch */
			return 0;	/* fail */
		}

		tmp = tmp->next;
	}		

	/* username not found */
	return 0;	/* fail */
}
