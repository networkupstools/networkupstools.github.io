/* 
   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include "main.h"
#include <string.h>

/* FIXME: need a way to set this dynamically */
#define INFOMAX  128

	char	statefn[256], pidfn[256];
	unsigned int sddelay = 90;	/* wait 90 seconds for shutdown */
	int	debug_level = 0;
	const char *progname = NULL, *upsname = NULL;
	const char *device_name = NULL, *device_path = NULL;
	const char *statepath = NULL;
	int	do_forceshutdown = 0;
	vartab_t	*vartab_h = NULL;

/* power down the attached load immediately */
static void forceshutdown(void)
{
	upslogx(LOG_NOTICE, "Initiating UPS shutdown");
	printf("Initiating forced UPS shutdown!\n");

	upsdrv_shutdown();

	if (sddelay > 0) {
		printf("Waiting for poweroff...\n");
		sleep(sddelay);
		printf("Hmm, did the shutdown fail?  Oh well...\n");
		exit(1);
	}
	exit(0);
}

void usage(void)
{
	printf ("usage: %s [-h] [-a <id>] [-d <num>] [-k] [-x <var>=<val>] [<device>]\n", 
	        progname);
	printf("\n");
	printf("Examples:\n");
	printf("         %s -a myups       - new method: use ups.conf section myups\n",
		progname);
	printf("         %s /dev/ttyS0     - old method: start up on port /dev/ttyS0\n", 
		progname);
	exit(1);
}

void help(void)
{
	vartab_t	*tmp;

	printf ("usage: %s [-h] [-a <id>] [-d <num>] [-k] [-x <var>=<val>] [<device>]\n", 
	        progname);

	printf (
		"  -a <id>        - autoconfig using ups.conf section <id>\n"
		"                 - note: -x options after -a override ups.conf settings\n"
		"  -d <num>       - wait <num> seconds after sending shutdown command\n"
		"  -k             - force shutdown\n"
		"  -h             - display this help\n"
		"  -x <var>=<val> - set driver variable <var> to <val>\n"
		"                 - example: -x cable=940-0095B\n"
		"\n"
		"  <device>       - /dev entry corresponding to UPS port\n"
		"                 - Only optional when using -a!\n"
		"\n");

	if (vartab_h) {
		tmp = vartab_h;

		printf ("Acceptable values for -x in this driver:\n\n");

		while (tmp) {
			if (tmp->vartype == VAR_VALUE)
				printf("%40s : -x %s=<value>\n", 
				       tmp->desc, tmp->var);
			else
				printf("%40s : -x %s\n", tmp->desc, tmp->var);
			tmp = tmp->next;
		}
	}

	upsdrv_help();
	exit(1);
}

/* split inbuf into <var>[=<val>] pairs and store it */
static void storeval(char *inbuf)
{
	char	*eqptr, *val, *buf;
	vartab_t	*tmp, *last;

	/* make our own copy - avoid changing argv */
	buf = xstrdup(inbuf);

	eqptr = strchr(buf, '=');

	if (!eqptr)
		val = NULL;
	else {
		*eqptr++ = '\0';
		val = eqptr;
	}

	tmp = last = vartab_h;

	while (tmp) {
		last = tmp;

		/* sanity check */
		if (!tmp->var) {
			tmp = tmp->next;
			continue;
		}

		/* later definitions overwrite earlier ones */
		if (!strcasecmp(tmp->var, buf)) {
			if (tmp->val)
				free(tmp->val);

			if (val)
				tmp->val = xstrdup(val);

			tmp->found = 1;
			return;
		}

		tmp = tmp->next;
	}

	printf("Error: -x %s is not valid for this driver.\n\n", buf);
	help();
}

/* retrieve the value of variable <var> if possible */
char *getval(char *var)
{
	vartab_t	*tmp = vartab_h;

	while (tmp) {
		if (!strcasecmp(tmp->var, var))
			return(tmp->val);
		tmp = tmp->next;
	}

	return NULL;
}

/* see if <var> has been defined, even if no value has been given to it */
int testvar(char *var)
{
	vartab_t	*tmp = vartab_h;

	while (tmp) {
		if (!strcasecmp(tmp->var, var))
			return tmp->found;
		tmp = tmp->next;
	}

	return 0;	/* not found */
}

/* callback from driver - create the table for future -x entries */
void addvar(int vartype, char *name, char *desc)
{
	vartab_t	*tmp, *last;

	tmp = last = vartab_h;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = xmalloc(sizeof(vartab_t));

	tmp->vartype = vartype;
	tmp->var = xstrdup(name);
	tmp->val = NULL;
	tmp->desc = xstrdup(desc);
	tmp->found = 0;
	tmp->next = NULL;

	if (last)
		last->next = tmp;
	else
		vartab_h = tmp;
}	

void do_upsconf_args(char *confupsname, char *var, char *val)
{
	char	tmp[SMALLBUF];

	/* this shouldn't happen, but ... */
	if (!upsname)
		return;

	/* no match = not for us */
	if (strcmp(confupsname, upsname) != 0)
		return;

	/* right now, the only flags (no =) are down in the drivers */
	if (!val) {
		storeval(var);
		return;
	}

	/* don't let the user shoot themselves in the foot */
	if (!strcmp(var, "driver")) {
		if (strcmp(val, progname) != 0)
			fatalx("Error: UPS [%s] is for driver %s, but I'm %s!\n",
				confupsname, val, progname);
		return;
	}

	if (!strcmp(var, "port")) {
		device_path = xstrdup(val);
		device_name = xbasename(device_path);
		return;
	}

	if (!strcmp(var, "sddelay")) {
		sddelay = atoi(val);
		return;
	}

	/* everything else must be for the driver */

	/* FIXME: ok, this is a lame hack for now */
	snprintf(tmp, sizeof(tmp), "%s=%s", var, val);
	storeval(tmp);
}	

int main(int argc, char **argv)
{
	int	i;

	droproot();

	upsdrv_banner();

	progname = xbasename(argv[0]);
	openlog(progname, LOG_PID, LOG_FACILITY);

	if ((statepath = getenv("NUT_STATEPATH")) == NULL)
		statepath = STATEPATH;

	/* build the driver's extra (-x) variable table */
	upsdrv_makevartable();

	while ((i = getopt(argc, argv, "+a:d:k:Dhx:")) != EOF) {
		switch (i) {
			case 'a':
				upsname = optarg;
				read_upsconf(0);
				break;
			case 'd':
				sddelay = atoi(optarg);
				break;
			case 'k':
				do_forceshutdown = 1;
				break;
			case 'D':
				debug_level++;
				break;
			case 'V':
				printf("Network UPS Tools (%s)\n", UPS_VERSION);
				exit(0);
			case 'x':
				storeval(optarg);
				break;
			case 'h':
				help();
				break;
			default:
				usage();
				break;
		}
	}

	argc -= optind;
	argv += optind;
	optind = 1;

	/* we need to get the port from somewhere */
	if (argc < 1) {
		if (!device_path) {
			fprintf(stderr, "Error: You must specify a port name in ups.conf or on the command line.\n");
			usage();
		}
	}

	/* allow argv to override the ups.conf entry if specified */
	else {
		device_path = argv[0];
		device_name = xbasename(device_path);
	}

	snprintf(statefn, sizeof(statefn), "%s/%s-%s", 
		statepath, progname, device_name);
	snprintf(pidfn, sizeof(pidfn), "%s/%s-%s.pid", 
		STATEPATH, progname, device_name);

	upsdrv_initups();

	if (chdir(statepath))
		fatal("Can't chdir to %s", statepath);

	if (do_forceshutdown)
		forceshutdown();

	create_info(INFOMAX, 1);
	createmsgq();

	upsdrv_initinfo();

	if (debug_level == 0) {
		background();
		/* writepid(pidfn); */
	}

	for (;;) {
		upsdrv_updateinfo();

		if (getupsmsg(2))       
			upslogx(LOG_DEBUG, "Received a message from upsd");
	}

	return 0;
}
