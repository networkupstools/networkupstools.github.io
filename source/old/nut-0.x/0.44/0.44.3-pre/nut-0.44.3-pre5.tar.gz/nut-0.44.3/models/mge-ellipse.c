/*  mge-ellipse.c - monitor MGE Pulsar UPS for NUT
 * 
 *  Copyright (C) 2001 Philippe Marzouk <philm@users.sourceforge.net>
 *  some parts are Copyright (C) Russel Kroll <rkroll@exploits.org>
 *  some parts are Copyright (C) Canon driver developpers for Gphoto
 *         see http://www.gphoto.org for details
 *  All rights reserved.
 *
 */

/*
 *		       GNU GENERAL PUBLIC LICENSE
 *			  Version 2, June 1991
 *
 *  Copyright (C) 1989, 1991 Free Software Foundation, Inc.
 *			     675 Mass Ave, Cambridge, MA 02139, USA
 *  Everyone is permitted to copy and distribute verbatim copies
 *  of this license document, but changing it is not allowed.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

#include "config.h"
#include "proto.h"
#include "shared.h"
#include "version.h"
#include "upscommon.h"
#include "mge-ellipse.h"
#include "common.h"

#define MAX_TRY	3


int shmok = 1;
int autorestart = 1;
int debug = 0;
char recv_buffer[255];
int commstatus = 0;
char statefn[256];
int lowlevel = 15;
int kill_ups_power = 0;
int delay = 0;
int read_timeout = 1000; /* timeout for serial reads in millisecond */

void setuphandlers(void)
{
        upsh.instcmd = instcmd;
}

int main(int argc, char **argv)
{
  char *port,*portname, *prog;
  int i;

  prog = argv[0];

  if (argc == 1)
    usage(prog);
  /* parse command line */
  while ((i = getopt(argc, argv, "d:Dhkl:")) != EOF) {
    switch (i) {
    case 'd':
      delay = atoi(optarg);
      break;
    case 'D':
      debug++;
      break;
    case 'h':
      usage(prog);
      break;
    case 'k':
      kill_ups_power = 1;
      break;
    case 'l':
      lowlevel = atoi(optarg);
      break;
    default:
      usage(prog);
      break;
    }
  }

  argc -= optind;
  argv += optind;

  if (argc < 1) {
    printf ("Error: no device specified!\n");
    usage (prog);
  }
  port = argv[0];
  portname = strrchr(port, '/');
  portname++;

  if (kill_ups_power == 0) 
    openlog("mge-ellipse", LOG_PID, LOG_FACILITY);

  /* initialize serial port */
  open_serial(port, B2400);

  setline(1);

  if ((debug == 0) && (kill_ups_power !=1))
    background();

  droproot();

  if (kill_ups_power==1) {
    e_kill_power();
  }

  snprintf (statefn, sizeof statefn, "%s/mge-ellipse-%s", STATEPATH,portname); 

  initinfo();

  /* IPC messages handling */
  createmsgq();
  setuphandlers();

  /* tell the UPS to restart automatically when power returns
     after a e_set_autorestart(); */

  /* main loop */
  while(1) {
    if(commstatus == 0) {
      e_ups_start();
    }
    
    e_ups_status();
    e_ups_load();
    e_autonomy();
    //    e_battery_charge();
    
    if (getupsmsg(2))
      upslogx(LOG_INFO, "Received a message from upsd\n");

  } /* end main loop */
}

void usage(char *progname)
{
  printf("usage: %s [-h] [-D] [-k] [-l <num>] <device>\n",progname);
  printf("          -h        print this help screen\n"
         "          -d <num>  ignored, for compatability\n" 
         "          -D        print some debug info.\n"
	 "          -k        shutdown the UPS after 120 seconds.\n"
	 "          -l <num>  set low battery level to <num> (default=15).\n"
         "          <device>  Mandatory - port where the UPS is attached.\n");
  exit(1);
}


/*
 * initialize info structure used to communicate
 * with the upsd daemon 
 */
void initinfo()
{
  debug_message("initinfo()\n");

  create_info(INFOMAX, shmok);
  
  addinfo(INFO_MFR,"MGE UPS", FLAG_STRING, 0);
  addinfo(INFO_MODEL,"Ellipse", FLAG_STRING, 0);
  addinfo(INFO_STATUS,"", FLAG_STRING, 0);
  addinfo(INFO_LOADPCT,"",0,0);
  addinfo(INFO_RUNTIME,"", 0, 0);
  addinfo(INFO_BATTPCT,"", 0, 0);
  addinfo(INFO_INSTCMD,"", 0, CMD_SHUTDOWN);


}

void instcmd(int auxcmd, int datalen, char *data)
{

  switch(auxcmd) {
  case CMD_SHUTDOWN:
    e_kill_power();
    break;
  default:
    upslogx(LOG_NOTICE, "%s", "instcmd: unknown type 0x%04x");
    break;
  }

}


/*
 * set RTS to on and DTR to off
 * 
 * set : 1 to set comm
 * set : 0 to stop comm
 */
void setline(int set)
{
  int dtr = TIOCM_DTR;
  int rts = TIOCM_RTS;

  debug_message("setline(%i)\n",set);

  if(set == 1) {
    ioctl(upsfd, TIOCMBIC, &dtr);
    ioctl(upsfd, TIOCMBIS, &rts);
  }
  else {
    ioctl(upsfd, TIOCMBIS, &dtr);
    ioctl(upsfd, TIOCMBIC, &rts);
  }
}

/*
* Initialize communication with UPS
*
* return 0 on success, -1 on failure 
*/
int e_ups_start()
{
  int try, c;

  debug_message("e_ups_start()\n");

  for(try=0; try<MAX_TRY; try++) {
    serial_send(PING,L_PING);
    c = serial_read();
    if (c == 0x16) {
      commstatus=1;
      upslogx(LOG_NOTICE, "Communication with UPS established");
      return 0;
    }
  }

  upslogx(LOG_NOTICE, "No communication with UPS!");
  
  commstatus=0;
  return -1;
}

/*
* Turn UPS Off
*
* return -1 on failure
*/
int e_kill_power()
{
  char *pkt;
  int try, c;

  debug_message("e_kill_power()\n");
  
  /* if called right after himself, communication will not work immediatly 
   * so we add some delay */
  for (try=0; try<MAX_TRY; try++) {
    if(e_ups_start()==0)
	break;
    sleep(2);
  }
 
  if (commstatus==0) {
    printf("No communication with UPS, cannot shutdown UPS\n");
    exit(-1);
  }

  if(e_set_autorestart()==-1)
    printf("Could not set autorestart, the UPS will not restart when power comes back\n");

  /* programming shutdown duration (120 seconds) */
  printf("turning power off\n");
  serial_send("\x06\x01\x88\x21\x09\x0F\x03\x00\x00\x04\x00\x20",L_CMDPKT);
  for (try=1;try<MAX_TRY;try++) {    
    c = serial_read();
    if (c == 0x06) break;
    else if (c == 0x15) return -1;
    else if (try==(MAX_TRY-1)) return -1; 
  }
  serial_send("\x81\x44\x0F\x78\x00\x00\x77",7);
  for (try=1;try<MAX_TRY;try++) {    
    c = serial_read();
    if (c == 0x06) break;
    else if (c == 0x15) return -1;
    else if (try==(MAX_TRY-1)) return -1; 
  }
  /* sending shutdown command */
  for (try=1;try<MAX_TRY;try++) {
    serial_send(KILL_POWER,L_CMDPKT);
    pkt=e_packet_recv(KILL_POWER_TYPE, KILL_POWER_DATALEN);
    if(pkt) {
      printf("UPS will shut off in %i seconds\n",pkt[4]);
      exit(0); 
    }
    else if (try==MAX_TRY) {
      printf("ERROR: Could not turn power off!");
      exit(-1);
    }
  }

  return -1;
}

/*
* Get general status of the UPS
*
* return 0 on success, -1 on failure
*/
int e_ups_status()
{
  char value[255]={0};
  char *pkt;
  int batt=0, on_battery=0;

  debug_message("ups_status()\n");
  
  if (commstatus==0)
    return -1;

  serial_send(POWER_STATUS,L_CMDPKT);
  pkt=e_packet_recv(POWER_STATUS_TYPE,POWER_STATUS_DATALEN);
  if(pkt) {
    if (pkt[4] == 0x24) {
      strcat(value,"OB ");
      on_battery=1;
    } 
    else if (pkt[4] == 0x23) { 
      strcat(value,"OL ");
      on_battery=0;
    }
    /* if battery charge < lowlevel and On Battery then toggle LB */
    batt=e_battery_charge();
    if((batt == 1) && (on_battery == 1)) {
      strcat(value,"LB ");
    } else if (batt == -1)
      return -1;

    if (value[strlen(value)-1] == ' ') value[strlen(value)-1] = 0;
    setinfo(INFO_STATUS, "%s", value);
    writeinfo(info);

   serial_send(UNKNOWN1,L_CMDPKT);
   e_packet_recv(UNKNOWN1_TYPE,UNKNOWN1_DATALEN);

    return 0;
  }

  commstatus=0; /* if we are here, no packet was received */
  return -1;
}

/*
* Get the load of the UPS
*
*
*/
int e_ups_load()
{
  char *pkt;

 debug_message("e_ups_load()\n");

  if (commstatus==0)
    return -1;

  serial_send(LOAD_LEVEL,L_CMDPKT);
  pkt = e_packet_recv(LOAD_LEVEL_TYPE, LOAD_LEVEL_DATALEN);
  if (pkt) {
    setinfo(INFO_LOADPCT, "%i", pkt[5]);
    writeinfo(info);
    
    return 0;
  }

  commstatus=0; /* if we are here, no packet was received */
  return -1;
}

/*
* Get the battery charge
*
* return -1 on failure, 0 on success, 1 on Low battery
*/
int e_battery_charge()
{
  char *pkt;

  debug_message("battery_charge()\n");

  if (commstatus==0)
    return -1;

  serial_send(BATT_STATUS,L_CMDPKT);
  pkt=e_packet_recv(BATT_STATUS_TYPE, BATT_STATUS_DATALEN);
  if(pkt) {
    setinfo(INFO_BATTPCT, "%u", pkt[4]);
    writeinfo(info);
    if (pkt[4]<lowlevel)
      return 1;
    return 0;
  }

  commstatus=0; /* if we are here, no packet was received */
  return -1;
}

/*
* Get the UPS autonomy
*
*
*/
int e_autonomy()
{
  char *pkt;
  
  debug_message("e_autonomy()\n");
  
  if (commstatus==0)
    return -1;

  serial_send(BATT_STATUS,L_CMDPKT);
  
  pkt=e_packet_recv(BATT_STATUS_TYPE, BATT_STATUS_DATALEN);
  if(pkt) {
    setinfo(INFO_RUNTIME, "%i", ((pkt[5] & 0xFF) | (pkt[6] << 8))/60); 
    writeinfo(info);
    
    return 0;
  }
  
  commstatus=0; /* if we are here, no packet was received */
  return -1;
}

/*
* select Autorestart mode
*
* return 0 on success, -1 on failure, -2 on unsupported
*/
int e_set_autorestart()
{
  char *pkt;
  int try, c;

  debug_message("e_set_autorestart()\n");

  if (commstatus==0)
    return -1;

  if (autorestart==1) {
    serial_send("\x06\x01\x88\x21\x09\x11\x03\x00\x00\x04\x00\x3E",L_CMDPKT);
    for (try=1;try<MAX_TRY;try++) {    
      c = serial_read();
      if (c == 0x06) break;
      else if (c == 0x15) return -1;
      else if (try==(MAX_TRY-1)) return -1; 
    }
    serial_send("\x81\x44\x11\x0D\x00\x00\x1C",7);
    for (try=1;try<MAX_TRY;try++) {    
      c = serial_read();
      if (c == 0x06) break;
      else if (c == 0x15) return -1;
      else if (try==(MAX_TRY-1)) return -1; 
    }

    for (try=1;try<MAX_TRY;try++) {
      serial_send(AUTO_RESTART,L_CMDPKT);
      pkt=e_packet_recv(AUTO_RESTART_TYPE, AUTO_RESTART_DATALEN);
      if(pkt) {
	return 0;
      }
    }
  }

  commstatus=0;
  return -1;
}

/*
*	Wait for a complete packet
*
*/
char *e_packet_recv(char pkt_type, int datalen)
{
  
  int c,i,try;
  int pktlen;

  pktlen = datalen + 4;

  debug_message("e_packet_recv()\n");

  i=0;
  try=0;
  while(try<MAX_TRY) {
    while (1) {
      if (i == pktlen) {
	dump_hex("recv",recv_buffer,pktlen);
	//	upslogx(LOG_DEBUG,"Buffer: %s",recv_buffer);
	return recv_buffer;
      }

      c=serial_read();
      if (c == -1)
	return NULL;
      if (c == -2) {
        try++;
        break;
      }

      if (i==255) {
	upslogx(LOG_DEBUG,"Buffer overflow");
	return NULL;
      }
#if 0
      if (debug>0)
	fprintf(stderr,"received: %i %x\n",i, c);
#endif 
      if((i==0) && (c == 0x15)) /* NACK received */
	return NULL;
      if ((i==0) && (c== 0x06)) { /* beginning of packet received */
	recv_buffer[i]=c;
	i++;
	try=0;
	break;
      }
      if((i==1) && (c==0x84)) {
	recv_buffer[i]=c;
	i++;
	try=0;
	break;
      }
      if((i==2) && (c/17==datalen)) {
	recv_buffer[i]=c;
	i++;
	try=0;
	break;
      }
      if ((i==3) && (c==pkt_type)) {
	recv_buffer[i]=c;
	i++;
	try=0;
	break;
      }
      if ((i>3) && (i<pktlen)) {
	recv_buffer[i]=c;
	i++;
	try=0;
	break;
      }

    }    
  }
  return NULL;
}

/* char_read
*
* reads size bytes from the serial port
* return -1 on error, -2 on timeout, 0 on success
*/
int char_read(char *bytes, int size)
{
  struct timeval serial_timeout;
  fd_set readfs;
  int readen = 0;
  int rc=0;

  FD_ZERO(&readfs);
  FD_SET(upsfd, &readfs);

  serial_timeout.tv_usec = (read_timeout % 1000) * 1000; 
  serial_timeout.tv_sec = (read_timeout / 1000);

  rc = select(upsfd + 1, &readfs, NULL, NULL, &serial_timeout);
  if (0 == rc)
    return -2; /* timeout */
  if(FD_ISSET(upsfd, &readfs)) {
    int now = read(upsfd, bytes, size - readen);
    
    if (now < 0) {
      return -1;
    } else {
      bytes += now;
      readen += now;
    }
  } else {
    return -1;
  }
  return readen;
}

/*
* serial_read
*  return data one byte at a time
*
* returns the byte on success, -1 on error, -2 on timeout
*/
int serial_read()
{
  static unsigned char cache[512];
  static unsigned char *cachep = cache;
  static unsigned char *cachee = cache;
  int recv;
  /* if still data in cache, get it */
  if (cachep < cachee) {
    return (int) *cachep++;
  }
  
  recv = char_read(cache, 1);
  
  if (recv == -1) 
    return -1;

  if (recv == -2)
    return -2;

  cachep = cache;
  cachee = cache + recv;
  cachep = cache;
  cachee = cache + recv;
  
  if (recv) {
 //   fprintf(stderr,"received: %x\n",(int) *cachep); 
    return (int) *cachep++;
  }
  
  return -1;
}

int serial_send(char *buf, int len)
{
  tcflush (upsfd, TCIFLUSH);
  dump_hex("sent",buf,len);
  return write(upsfd,buf,len);
}

void debug_message(const char * msg, ...)
{
  va_list ap;
  
  if (debug > 0) {
    va_start(ap, msg);
    vfprintf(stderr,msg, ap);
    va_end(ap);
  }
}

/*****************************************************************************
 *
 * dump_hex
 *
 * Dumps a memory area as hex on the screen.
 *
 * msg  - Info message for the dump
 * buf  - the memory buffer to dump
 * len  - length of the buffer
 *
 ****************************************************************************/


#define NIBBLE(_i)    (((_i) < 10) ? '0' + (_i) : 'A' + (_i) - 10)

void dump_hex(const char *msg, const unsigned char *buf, int len)
{
  int i;
  int nlocal;
  const unsigned char *pc;
  char *out;
  const unsigned char *start;
  char c;
  char line[100];

  if(debug==0) {
	return;
  }
  start = buf;
  fprintf(stderr,"%s: (%d bytes)\n", msg, len);
  while (len > 0) {
    snprintf(line, sizeof(line), "%08x: ", buf - start);
    out = line + 10;
          
    for (i = 0, pc = buf, nlocal = len; i < 16; i++, pc++) {
      if (nlocal > 0) {
        c = *pc;
                  
        *out++ = NIBBLE((c >> 4) & 0xF);
        *out++ = NIBBLE(c & 0xF);
                  
        nlocal--;
      } else {
        *out++ = ' ';
        *out++ = ' ';
      }                        /* end else */
      *out++ = ' ';
    }                   /* end for */
          
    *out++ = '-';
    *out++ = ' ';
          
    for (i = 0, pc = buf, nlocal = len;
         (i < 16) && (nlocal > 0);
         i++, pc++, nlocal--) {
      c = *pc;
              
      if ((c < ' ') || (c >= 126)) {
        c = '.';
      }
              
      *out++ = c;
    }                   /* end for */
          
    *out++ = 0;
          
    fprintf(stderr,"%s\n", line);
          
    buf += 16;
    len -= 16;
  }                               /* end while */
}                               /* end dump */





