/* upsmon - monitor power status over the 'net (talks to upsd via UDP)

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <errno.h>
#include <fcntl.h>                            
#include <stdio.h>
#include <signal.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>

#include "upsfetch.h"
#include "config.h"
#include "version.h"
#include "common.h"

#include "upsmon.h"

	char	*shutdowncmd = NULL, *notifycmd = NULL, *password = NULL;
	char	*powerdownflag = NULL;

	int	minsupplies = 1, upscount = 0, sleepval = 5;

	/* default polling interval = 5 sec */
	int	pollfreq = 5, pollfreqalert = 5;

	/* default alert time = 30 sec */
	int	alerttime = 30;

	/* slave hosts are given 15 sec by default to logout from upsd */
	int hostsync = 15;  

	utype	*firstups = NULL;

void setflag (int *val, int flag)
{
	*val = (*val |= flag);
}
        
void clearflag (int *val, int flag)  
{
	*val = (*val ^= (*val & flag));
}

int isset (int num, int flag)
{
	return ((num & flag) == flag);
}

void wall(char *text)
{
	char	exec[512];

	snprintf (exec, sizeof(exec), "echo \"%s\" | wall", text);
	system (exec);
} 

void notify (char *notice)
{
	char	exec[512];

	syslog (LOG_NOTICE, notice);
	wall (notice);

	if (notifycmd != NULL) {
		snprintf (exec, sizeof(exec), "%s %s", notifycmd, notice);
		system (exec);
	}
}

void heardups(utype *ups)
{
	char	logbuf[256];

	if (isset(ups->status, ST_ALIVE))
		return;

	setflag (&ups->status, ST_ALIVE);
	syslog (LOG_INFO, "Communication with UPS %s established", ups->sys);

	if (ups->pv == 0)	/* monitor only, no need to login */
		return;

	/* not logged in?  then do it */
	if (!isset(ups->status, ST_LOGIN)) {
		if (upslogin (ups->fd, ups->upsname, password) == 0) {
			printf ("Logged into UPS %s\n", ups->sys);
			setflag (&ups->status, ST_LOGIN);
		}
		else {
			snprintf (logbuf, sizeof(logbuf), "Unable to login to %s: %s\n",
			          ups->sys, upsstrerror(upserror));
			syslog (LOG_INFO, logbuf);
			return;
		}
	}
}

void upsgone(utype *ups)
{
	if (isset(ups->status, ST_ALIVE)) {	/* ups is gone, first time */
		syslog (LOG_INFO, "Communication with UPS %s lost", ups->sys);
		close (ups->fd);
		ups->fd = -1;
		ups->status = 0;	/* clear all flags */
	}
}

void upsonbatt(utype *ups)
{
	char	msg[256];

	if (!isset(ups->status, ST_ONBATT)) {
		snprintf (msg, sizeof(msg), "UPS %s: on battery", ups->sys);
		notify (msg);
		setflag (&ups->status, ST_ONBATT);
		clearflag (&ups->status, ST_ONLINE);
	}

	sleepval = pollfreqalert;	/* bump up polling frequency */
}

void upsonline(utype *ups)
{
	char	msg[256];

	if (!isset(ups->status, ST_ONLINE)) {
		snprintf (msg, sizeof(msg), "UPS %s: back on line power", ups->sys);
		notify (msg);
		setflag (&ups->status, ST_ONLINE);
		clearflag (&ups->status, ST_ONBATT);
	}
}

/* the actual shutdown procedure */
void doshutdown()
{
	syslog (LOG_CRIT, "Low battery - Executing automatic power-fail shutdown");
	wall ("Low battery - executing automatic power-fail shutdown\n");

	if (getuid() != 0) {
		syslog (LOG_ALERT, "Not root, unable to shutdown system");
		exit (1);
	}

	/* TODO: more user configurability and less hardcoded mess */

	notify ("Auto logout and shutdown in 15 seconds!");
	sleep (15);

	system (shutdowncmd);
	exit (1);
}

/* create the flag file if necessary */
void setpdflag()
{
	FILE	*pdf;

	if (powerdownflag != NULL) {
		pdf = fopen (powerdownflag, "w");
		fprintf (pdf, SDMAGIC);
		fclose (pdf);
	}
}

void forceshutdown (utype *ups)
{
	printf ("forceshutdown called, but it's not done yet!\n");
	exit (1);

	/* jump to local shutdown if not the master */
	if (!isset(ups->status, ST_MASTER))
		doshutdown();

	/* must be the master */

	/* XXX: lots of code needs to be written beyond this point */

	/* set FSD on the server (forced shutdown in progress) */

	/* get timestamp */

	/* wait up to HOSTSYNC seconds for slaves to logout */

	/* at HOSTSYNC seconds or 1 login (self), do local shutdown */


#if 0		/* ---------- OLD CODE ---------------- */
	time (&start);

	for (;;) {	/* see who's still logged in */
		if (getupsvarfd(ups->fd, ups->upsname, "numlogins", 
		                temp, sizeof(temp)) >= 0) {

			if (atoi(temp) < 2) {
				syslog (LOG_INFO, "Other clients logged out - shutting down...\n");
				setpdflag();
				doshutdown();
			}
		}

		/* check time, bail out if hostsync interval exceeded */
		time (&now);
		if ((now - start) > hostsync) {
			syslog (LOG_INFO, "Host sync timer expired, forcing shutdown...\n");
			setpdflag();
			doshutdown();
		}

		/* poll every 250ms - try not to flood the network */
		usleep (250000);
	}
#endif
}

/* recalculate the online power value and see if things are still OK */
void recalc (void)
{
	utype	*ups;
	int	val_ol = 0;

	ups = firstups;
	while (ups != NULL) {
		if ((isset(ups->status, ST_ONBATT)) && 
		    (isset(ups->status, ST_LOWBATT))) 
			printf ("Critical UPS: %s\n", ups->sys);
		else
			val_ol += ups->pv;
		ups = ups->next;
	}

	printf ("Current power value: %d\n", val_ol);
	printf ("Minimum power value: %d\n", minsupplies);

	if (val_ol < minsupplies)
		forceshutdown(ups);
}		

void upslowbatt(utype *ups)
{
	char	msg[256];

	setflag (&ups->status, ST_LOWBATT);

	snprintf (msg, sizeof(msg), "UPS %s: battery is critical", ups->sys);
	notify (msg);
}

/* leave some valid fds hanging around that go nowhere */
void dupfds(void)
{
	int	tempfd;

	/* this is done so that certain programs (sendmail...) work */
	tempfd = open ("/dev/null", O_RDWR);
	if (tempfd != STDIN_FILENO) {
		dup2 (tempfd, STDIN_FILENO);
		close (tempfd);
	}
	dup2 (STDIN_FILENO, STDOUT_FILENO);
	dup2 (STDIN_FILENO, STDERR_FILENO);
}

void addups (char *sys, char *pv, char *pw, char *master)
{
	utype	*tmp, *last;
	char	*upsname, *ptr;

	last = tmp = firstups;

	while (tmp) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = malloc (sizeof(utype));
	tmp->fd = -1;
	tmp->sys = strdup (sys);

	/* parse out <upsname>@<host> for later */
	upsname = strdup (sys);
	ptr = strchr (upsname, '@');
	if (ptr) {
		*ptr = '\0';
		tmp->upsname = strdup (upsname);
		tmp->host = strdup (++ptr);
	}
	else {
		tmp->upsname = NULL;
		tmp->host = strdup (sys);
	}

	free (upsname);

	tmp->pv = atoi (pv);
	tmp->pw = strdup (pw);

	tmp->status = 0;

	if (!strcasecmp(master, "master"))
		setflag (&tmp->status, ST_MASTER);

	tmp->next = NULL;

	if (last)
		last->next = tmp;
	else
		firstups = tmp;

	if (tmp->pv) 
		printf ("UPS: %s (%s: value %d)\n", tmp->sys, 
		        isset(tmp->status, ST_MASTER) ? "master" : "slave", tmp->pv);
	else
		printf ("UPS: %s (monitoring only)\n", tmp->sys);

	upscount++;

	/* TODO: lose debug stuff */

	printf ("Connecting... ");
	fflush (stdout);
	tmp->fd = upsconnect (tmp->host);

	if (tmp->fd < 0)
		printf ("%s\n\n", upsstrerror(upserror));
	else
		printf ("OK\n\n");
}		

/* <system> <pwrvalue> <password> ("master"|"slave") */
void do_monitor (char *buf)
{
	char	*ptr, *sp, *sys, *pv, *pw, *master;
	int	i;

	sys = pv = pw = master = NULL;

	ptr = buf;
	for (i = 0; i < 4; i++) {
		sp = strchr (ptr, ' ');

		if (sp)
			*sp = '\0';

		switch (i) {
			case 0: sys = ptr; break;
			case 1: pv = ptr; break;
			case 2: pw = ptr; break;
			case 3: master = ptr; break;
			default: break;
		}

		ptr = sp + 1;
	}

	addups (sys, pv, pw, master);
}

void loadconfig (void)
{
	char	cfn[256], buf[256];
	FILE	*conf;

	snprintf (cfn, sizeof(cfn), "%s/upsmon.conf", CONFPATH);

	conf = fopen(cfn, "r");
	if (conf == NULL) {
		printf ("Can't open %s/upsmon.conf: %s\n", CONFPATH, 
		        strerror(errno));
		exit (1);
	}

	/* TODO: allow overriding stock messages from config file */

	while (fgets(buf, sizeof(buf), conf)) {
		buf[strlen(buf) - 1] = '\0';
		if (!strncmp(buf, "SHUTDOWNCMD", 11))
			shutdowncmd = strdup (&buf[12]);

		if (!strncmp(buf, "NOTIFYCMD", 9)) {
			notifycmd = strdup (&buf[10]);
			syslog (LOG_INFO, "External notify command enabled\n");
		}

		if (!strncmp(buf, "POWERDOWNFLAG", 13)) {
			powerdownflag = strdup (&buf[14]);
			printf ("Using power down flag file %s\n", powerdownflag);
		}

		if (!strncmp(buf, "PASSWORD", 8))
			password = strdup (&buf[9]);

		if (!strncmp(buf, "POLLFREQ", 8))
			pollfreq = atoi(&buf[9]);

		if (!strncmp(buf, "POLLFREQALERT", 13))
			pollfreqalert = atoi(&buf[14]);

		if (!strncmp(buf, "ALERTTIME", 9))
			alerttime = atoi(&buf[10]);

		if (!strncmp(buf, "HOSTSYNC", 8))
			hostsync = atoi(&buf[9]);

		if (!strncmp(buf, "MONITOR", 7))
			do_monitor (&buf[8]);

		if (!strncmp(buf, "MINSUPPLIES", 11)) {
			minsupplies = atoi (&buf[12]);
			printf ("Minimum power supplies required: %d\n", 
			        minsupplies);
		}
	}
	
	fclose (conf);
}

/* SIGPIPE handler */
void sigpipe (int sig)
{
	printf ("SIGPIPE: dazed and confused, but continuing...\n");
}

/* basic signal setup to handle SIGPIPE */
void setupsignals()
{
	struct sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = sigpipe;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGPIPE, &sa, NULL);
}

/* handler for alarm when getupsvarfd times out */
void timeout (int sig)
{
	/* don't do anything here, just return */
}

/* see what the status of the UPS is and handle any changes */
void pollups (utype *ups)
{
	char	status[256], *stat, *ptr;
	struct	sigaction sa;
	sigset_t sigmask;

	printf ("pollups: %s (fd %d)\n", ups->sys, ups->fd);

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (10);

	if (getupsvarfd(ups->fd, ups->upsname, "status", status, sizeof(status)) >= 0) {
		signal (SIGALRM, SIG_IGN);
		alarm (0);
		heardups(ups);

		/* clear this one out early if it disappears */
		if (!strstr(status, "LB"))
			clearflag (&ups->status, ST_LOWBATT);

		stat = status;
		while (stat != NULL) {
			ptr = strchr (stat, ' ');
			if (ptr)
				*ptr++ = '\0';

			if (!strcasecmp(stat, "OL"))
				upsonline(ups);
			if (!strcasecmp(stat, "OB"))
				upsonbatt(ups);
			if (!strcasecmp(stat, "LB"))
				upslowbatt(ups);

			/* XXX: FSD */

			stat = ptr;
		} 
	}
	else {					/* fetch failed */
		signal (SIGALRM, SIG_IGN);
		alarm (0);
		upsgone(ups);
	}
}

/* remove the power down flag if it exists and is the proper form */
void clearpdf ()
{
	FILE	*pdf;
	char	buf[256];

	pdf = fopen (powerdownflag, "r");

	if (pdf == NULL)	/* no such file, nothing to do */
		return;

	/* if it exists, see if it has the right text in it */

	fgets (buf, sizeof(buf), pdf);
	fclose (pdf);

	/* reasoning: say upsmon.conf is world-writable (!) and some nasty
	 * user puts something "important" as the power flag file.  This 
	 * keeps upsmon from utterly trashing it when starting up or powering
	 * down at the expense of not shutting down the UPS.
	 *
	 * solution: don't let mere mortals edit that configuration file.
	 */

	if (!strncmp (buf, SDMAGIC, strlen(SDMAGIC)))	/* ok, it's from us */
		unlink (powerdownflag);
	else {
		printf ("%s doesn't seem to be a proper flag file.  Disabling.\n",
		        powerdownflag);
		powerdownflag = NULL;
	}
}

int main(int argc, char *argv[])  
{
	printf ("Network UPS Tools upsmon %s\n", UPS_VERSION);

	/* throw out a warning for now... otherwise pre1 gets to rot 
	   on my drive locally until it's ALL done, which is just painful */

	printf ("***\n");
	printf ("*** WARNING: This version is still in development and will\n");
	printf ("*** not shut down your system when the power fails!\n");
	printf ("***\n");
	printf ("*** Save your 0.43.2 binary until this is finished.\n");
	printf ("***\n");
	printf ("*** Exiting.  See Changes for more information.\n");
	exit (1);

	openlog ("upsmon", LOG_PID, LOG_FACILITY);
	loadconfig();

	if (shutdowncmd == NULL)
		printf ("Warning: no shutdown command defined!\n");

	/* we may need to get rid of a flag from a previous shutdown */
	if (powerdownflag != NULL)
		clearpdf ();

	/* ignore sigpipes before the connection opens */
	setupsignals();

#if 0	/* XXX */
	background();
	dupfds();
#endif

	for (;;) {
		utype	*ups;		

		sleepval = pollfreq;
		for (ups = firstups; ups != NULL; ups = ups->next)
			pollups (ups);

		recalc();
		sleep (sleepval);
	}

	return (1);
}
