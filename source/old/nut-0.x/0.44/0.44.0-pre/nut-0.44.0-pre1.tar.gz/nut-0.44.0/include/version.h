#define UPS_VERSION "0.44.0-pre1"
