/* common.c - common useful functions

   Copyright (C) 2000  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>

#include "config.h"

/* close ttys and become a daemon */
void background()
{
	int	pid;

	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */

	syslog (LOG_INFO, "Startup successful");
}

/* change uid/gid if running as root */
void droproot ()
{
	setgid(RUN_AS_GID);

	if (getuid() == 0)
		if (setuid(RUN_AS_UID) == -1) {
			perror ("setuid");
			exit (1);
		}
}
