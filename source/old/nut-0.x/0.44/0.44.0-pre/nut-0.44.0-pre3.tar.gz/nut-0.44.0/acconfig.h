/* acconfig.h - template for autoheader for config.h.in */

/* path where things get installed by default */
#define BASEPATH "/usr/local/ups"

/* path where configuration files get installed by default */
#define CONFPATH "/usr/local/ups/etc"

/* state files created by the model-specific programs go here */
#define STATEPATH "/var/state/ups"

/* default path for CGI programs */
#define CGIPATH "/usr/local/ups/cgi-bin"

/* default path for model-specific drivers */
#define MODELPATH "/usr/local/ups/bin"

/* port number used for network communications */
#define UDPPORT 3305

/* the UID/GID values may need to be changed for other systems */

/* userid to run as instead of root - typically the value for "nobody" */
#define RUN_AS_UID 65534

/* groupid to run as instead of root - typically the value for "nogroup" */
#define RUN_AS_GID -2

/* logging facility for syslog */
#define LOG_FACILITY LOG_DAEMON

/* define this to use C instead of F for temperature readings */
#undef USE_CELSIUS

/* define this if you have uu_lock for handling serial ports ala FreeBSD */
#undef HAVE_UU_LOCK
