/* apcsmart.c - model specific routines for APC smart protocol units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>
             (C) 2000  Nigel Metheringham <Nigel.Metheringham@Intechnology.co.uk>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <time.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "shared.h"
#include "shared-tables.h"
#include "newapc.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"

	int	shmok = 1;
	char	statefn[256];
	itype	*info;
extern	int	flag_timeoutfailure;
	int	infomax = 128;
	int	upslevel = 0;
	
	int	sddelay = 60;	/* wait 60 seconds for shutdown */
	int	shutdowncmdset = 0; /* The shutdown command set to use */
extern	struct	ups_handler	upsh;

	/* alternate cable handling support */
	char	*cable = NULL;
#define ALT_CABLE_1 "940-0095B"

extern	int	upsfd;
extern	int	upsc_debug;
	int	debug = 0;
/* tables of mappings built on startup */
struct apc_cmdtab_t *cmdmap[256];
struct apc_cmdtab_t **infomap;
int max_info_num = 0;

/* this macro gives you the apc cmd table entry for a cmd char */
#define CMD_LOOKUP(x)	(cmdmap[(x) & 0xFF])
/* this macro gives you the apc cmd table entry for an INFO_ code */
#define INFO_LOOKUP(x)	(((x) < max_info_num) ? infomap[(x)] : NULL)
#define CMDTABNAME(x)	(((x)->info == NULL) ? "UNKNOWN" : (x)->info->name)
#define CMDTABDESC(x)	(((x)->info == NULL) ? "unknown" : (x)->info->desc)
void intialise_data_tables()
{
	struct apc_cmdtab_t * cmd_entry;
	struct netvars_t * netvar_entry;

	/* make sure cmdmap zeroed */
	memset(cmdmap, 0, sizeof(cmdmap));

	/* iterate through the command table setting up cmd mapping */
	for(cmd_entry = &apc_cmdtab[0];
	    (cmd_entry->info_type > 0);
	    cmd_entry++) {
		cmdmap[cmd_entry->cmd & 0xFF] = cmd_entry;
		if (cmd_entry->info_type > max_info_num)
			max_info_num = cmd_entry->info_type;
	}

	/* Now allocate the infomap and zero that out */
	max_info_num++;
	infomap = calloc(max_info_num, sizeof(cmd_entry));
	/* calloc(3) man says it is pre-zeroed - trust it for now */

	/* iterate through the command table setting up info mapping */
	for(cmd_entry = &apc_cmdtab[0];
	    (cmd_entry->info_type > 0);
	    cmd_entry++) {
		infomap[cmd_entry->info_type] = cmd_entry;
	}

	/* Now iterate through the netvars table merging them in */
	for(netvar_entry = &netvars[0];
	    netvar_entry->name;
	    netvar_entry++) {
		cmd_entry = INFO_LOOKUP(netvar_entry->type);
		if (cmd_entry)
			cmd_entry->info = netvar_entry;
	}
}


char * convert_ups2info (struct apc_cmdtab_t * cmd_entry, char * upsval)
{
	char tmp[128];
	int  tval;
	char *ptr;

	/* Do the magic formatting stuff
	   Currently this is inlined - could move to using 
	   function pointers in the command table */
	switch(cmd_entry->driver_flags & APC_FORMATMASK) {
	case APC_F_ST:
		tval = strtol (upsval, 0, 16);
		tval &= 0xFF;

		if (tval > 0) {
			strcpy (tmp, "");
			/* Position the more important ones first */
			if (tval & 8)
				strcat(tmp, "OL ");	/* on line */
			if (tval & 16)
				strcat(tmp, "OB ");	/* on battery */
			if (tval & 32)
				strcat(tmp, "OVER ");	/* overload */
			if (tval & 64)
				strcat(tmp, "LB ");	/* low battery */
			if (tval & 1)
				strcat(tmp, "CAL ");	/* calibration */
			if (tval & 2)
				strcat(tmp, "TRIM ");	/* SmartTrim */
			if (tval & 4)
				strcat(tmp, "BOOST ");	/* SmartBoost */
			if (tval & 128)
				strcat(tmp, "RB ");	/* replace batt */	

				/* lose trailing space if present */
			tmp[strlen(tmp)-1] = 0;
		} else
			strcpy (tmp, "OFF");

		ptr = tmp;
		break;
	case APC_F_PERCENT:
	case APC_F_VOLT:
	case APC_F_CELCIUS:
	case APC_F_SECONDS:
	case APC_F_MINUTES:
	case APC_F_HOURS:
	case APC_F_LEAVE:
				/* All of these just pass through at present */
		ptr = upsval;
		break;
	default:
				/* Moan */
		printf("APC capability: %s (%s) has unknown format\n",
		       CMDTABNAME(cmd_entry), CMDTABNAME(cmd_entry));
		ptr = upsval;
		break;
	}
	return ptr;
}

void do_capabilities (void)
{
	char	upsloc, temp[512], *ptr, cmd, loc, *entptr, etmp[16], *endtemp;
	int	nument, entlen, i, matrix, recvret;
	struct apc_cmdtab_t * cmd_entry;

	if (debug)
		printf("APC: About to get capabilities string\n");
	/* If we can do caps, then we need the Firmware revision which has
	   the locale descriptor as the last character (ugh)
	*/
	ptr = getdata(INFO_FIRMREV);
	if (ptr)
		upsloc =ptr[strlen(ptr) - 1];
	else
		upsloc = 0;

	/* get capability string */
	upssendchar (REQ_CAPABILITIES);	/* ^Z */
	strcpy (temp, "NA");
	recvret = upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if ((recvret == -1) || (!strcmp(temp, "NA"))) {
		/* Early Smart-UPS, not as smart as later ones */
		/* This should never happen since we only call
		   this if the REQ_CAPABILITIES command is supported
		*/
		syslog (LOG_ERR, "ERROR: APC cannot do capabilites but said it could!\n");
		return;
	}

	/* recv always puts a \0 at the end, so this is safe */
	/* however it assumes a zero byte cannot be embedded */
	endtemp = &temp[0] + strlen(temp);

	if (temp[0] != '#') {
		printf ("Unrecognized capability start char %c\n", temp[0]);
		printf ("Please report this error [%s]\n", temp);
		syslog (LOG_ERR, "ERROR: unknown capability start char %c!\n", temp[0]);
		return;
	}

	if (temp[1] == '#') {		/* Matrix-UPS */
		matrix = 1;
		ptr = &temp[0];
	}
	else {
		ptr = &temp[1];
		matrix = 0;
	}

	/* command char, location, # of entries, entry length */

	while (ptr[0] != '\0') {
		if (matrix)
			ptr += 2;	/* jump over repeating ## */

		/* check for idiocy */
		if (ptr >= endtemp) {
			printf ("Capability string has overflowed\n");
			printf ("Please report this error\n");
			syslog (LOG_ERR, "ERROR: capability overflow!\n");
			exit(1);
		}

		cmd = ptr[0];
		loc = ptr[1];
		nument = ptr[2] - 48;
		entlen = ptr[3] - 48;
		entptr = &ptr[4];
		cmd_entry = CMD_LOOKUP(cmd);

		if (debug)
			printf("CAPABILITY %02x (%c) \"%s\" seen\n",
			       cmd,
			       loc,
			       (cmd_entry ? CMDTABNAME(cmd_entry) : "unrecognised"));
		/* Mark this as being a ENUM entry and writable */
		if (cmd_entry && ((loc == upsloc) || (loc == '4'))) {
			setflag(cmd_entry->info_type, FLAG_RW | FLAG_ENUM);
			cmd_entry->info_flags |= FLAG_RW | FLAG_ENUM;
		}
		for (i = 0; i < nument; i++) {
			snprintf (etmp, entlen + 1, "%s", entptr);
			if (cmd_entry && ((loc == upsloc) || (loc == '4')))
				addenum(cmd_entry->info_type,
					convert_ups2info(cmd_entry, etmp));
			entptr += entlen;
		}
		ptr = entptr;
	}
}

int query_ups(int capability,
	       int first)
{
	char	temp[256], *ptr;
	int	recvret, retval;
	struct apc_cmdtab_t * cmd_entry;

	cmd_entry = INFO_LOOKUP(capability);
	if (cmd_entry == NULL) {
		if (debug) {
			printf("APC capability: %c 0x%04x UNKNOWN\n",
			       (isprint(capability) ? capability : ' '),
			       capability);
		}
		return(1);
	}

	retval = 0;
	if (first || (cmd_entry->driver_flags & APC_PRESENT)) {
		upssendchar(cmd_entry->cmd);
		if (first) {
			flag_timeoutfailure = -1;
			strcpy (temp, "NA");
		}
		recvret = upsrecv(temp, sizeof(temp), ENDCHAR, IGNCHARS);
		if (first)
			flag_timeoutfailure = 0;

		if ((recvret == -1) || (strcmp(temp, "NA") == 0)) {	/* not supported */
			if (first)
				cmd_entry->driver_flags &= ~(APC_PRESENT);
			if (debug)
				printf("APC capability: %s NOT OK\n",
				       CMDTABNAME(cmd_entry));
			retval = -1;
		} else {
			/* If its the first time through, mark this
			 * capability as present
			 */
			if (first) {
				cmd_entry->driver_flags |= APC_PRESENT;
				if (debug)
					printf("APC capability: %s OK [%s]\n",
					       CMDTABNAME(cmd_entry), temp);
			}
			ptr = convert_ups2info(cmd_entry, temp);
			if (first)
				addinfo(cmd_entry->info_type, ptr, 0, 0);
			else
				setinfo (cmd_entry->info_type, ptr);
		}
	}
	return retval;
}

void oldapcsetup (void)
{
	char	temp[20];
	int	ret = 0;

	/* really old models ignore REQ_MODEL, so find them first */
	ret = query_ups(INFO_MODEL, 1);

	if (ret != 0) {
		/* force the model name */
		addinfo (INFO_MODEL, "Smart-UPS", 0, 0);
	}

	/* see if this might be an old Matrix-UPS instead */
	upssendchar ('/');
	flag_timeoutfailure = -1;
	strcpy (temp, "NA");
	ret = upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	flag_timeoutfailure = 0;

	/* it returned a useful number, so it must be a Matrix-UPS */
	if ((ret != -1) && (strcmp(temp, "NA")) != 0) {
		setinfo (INFO_MODEL, "Matrix-UPS");
	}

	query_ups(INFO_SERIAL, 1);
	query_ups(INFO_STATUS, 1);
	query_ups(INFO_UTILITY, 1); /* This one may fail... no problem */

	/* If we have come down this path then we dont do capabilites and
	   other shiny features
	*/
}


void getbaseinfo ()
{
	char	temp[512];
	int	recvret = 0;
	char 	*alrts;
	char 	*cmds;
	char	*ptr;

	if (debug)
		printf("APC - Attempting to find command set\n");
	/* Initially we ask the UPS what commands it takes
	   If this fails we are going to need an alternate
	   strategy - we can deal with that if it happens
	*/
	upssendchar (REQ_CMDSET);
	strcpy (temp, "NA");
	/* disable timeout complaints temporarily */
	flag_timeoutfailure = -1;
	recvret = upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	flag_timeoutfailure = 0;

	if ((recvret == -1) || (!strcmp(temp, "NA"))) {
		/* We have an old dumb UPS - go to specific code for old stuff */
		oldapcsetup();
		return;
	}

	if (debug)
		printf("APC - Parsing out command set\n");
	/* We have the version.alert.cmdchars string
	   NB the alert chars are normally in IGNCHARS
	   so will have been pretty much edited out.
	   You will need to change the upsrecv above if
	   you want to check those out too....
	*/
 	alrts = strchr(temp, '.');
	if (alrts == NULL) {
		printf("Unable to split APC version string\n");
		printf("Bailing out\n");
		exit(1);
	}
	*alrts++ = 0;

	cmds = strchr(alrts, '.');
	if (cmds == NULL) {
		printf("Unable to find APC command string\n");
		printf("Bailing out\n");
		exit(1);
	}
	*cmds++ = 0;
	/* Tie off end of command string - seems to be another field here */
	ptr = strchr(cmds, '.');
	if (ptr)
		*ptr = 0;

	for(ptr = cmds; *ptr; ptr++) {
		struct apc_cmdtab_t * cmd_entry;
		cmd_entry = CMD_LOOKUP(*ptr);
		if (cmd_entry) {
			query_ups(cmd_entry->info_type, 1);
		} else if (debug) {
			printf("APC command: %c 0x%02x UNKNOWN - ignored\n",
			       (isprint(*ptr) ? *ptr : ' '),
			       *ptr);
		}
	}
	/* If we can handle capabilities then do them here */
	if (strchr(cmds, REQ_CAPABILITIES) != NULL)
		do_capabilities();

	if (debug)
		printf("APC - UPS capabilities determined\n");
}


/* normal idle loop - keep up with the current state of the UPS */
/* If updateall is non-zero query all known UPS variables */
void updateinfo (int updateall)
{
	char	temp[256];
	struct apc_cmdtab_t * cmd_entry;

	/* try to wake up a dead ups once in awhile */
	if (flag_timeoutfailure == 1) {
		upssendchar (GO_SMART);
		upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	}

	
	for(cmd_entry = &apc_cmdtab[0];
	    (cmd_entry->info_type > 0);
	    cmd_entry++) {
		if (cmd_entry->driver_flags & APC_PRESENT) {
			if (updateall || (cmd_entry->driver_flags & APC_POLL))
				query_ups(cmd_entry->info_type, 0);
		}
	}

	writeinfo(info);
}

/* TODO: roll this into upscommon ala bestups */
void sendstring(char * string, int len, int delay)
{
	int	i;

	for (i=0; (i<len); i++) {
	        upssendchar(string[i]);
		usleep(delay);
	}
}

/* power down the attached load immediately */
void forceshutdown(char *port)
{
	char	temp[32];
	int	tval;

	syslog (LOG_INFO, "Initiating UPS shutdown\n");
	printf ("Initiating forced UPS shutdown!\n");

	open_serial (port, B2400);

	upssendchar (GO_SMART);
	upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	if (strcmp(temp, "SM") != 0)
		printf ("Detection failed.  Trying a shutdown command anyway.\n");

	/* check the line status */

	upssendchar (REQ_STATUS);
	upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	tval = strtol (temp, 0, 16);

	if (shutdowncmdset == 1) {
	/* Send a combined set of shutdown commands which can work better */
	/* if the UPS gets power during shutdown process */
	/* Specifically it sends both the soft shutdown 'S' */
	/* and the powerdown after grace period - '@000' commands */
		printf ("UPS - currently %s - sending shutdown/powerdown\n",
		       (tval & 8) ? "on-line" : "on battery");
		sendstring ("S@000", 4, 50000);
	}
	else {
		/* @000 - shutdown after 'p' grace period             */
		/*      - returns after 000 minutes (i.e. right away) */

		/* S    - shutdown after 'p' grace period, only on battery */
		/*        returns after 'e' charge % plus 'r' seconds      */

		if (tval & 8) {                 /* on line */
			printf ("On line, sending shutdown+return command...\n");
			sendstring ("@000", 4, 50000);
		} 
		else {
			printf ("On battery, sending normal shutdown command...\n");
			upssendchar ('S');
		}
	}
	if (sddelay > 0) {
		sleep (sddelay);
		printf ("Hmm, did the shutdown fail?  Oh well...\n");
		exit (1);
	}
	exit (0);
}

/* set a value in the hardware using the <cmdchar> '-' (repeat) approach */
void hw_set (char cmdchar, char *newval)
{
	char	temp[256], orig[256];
	int	tries;

	upssendchar (cmdchar);
	upsrecv (orig, sizeof(orig), ENDCHAR, IGNCHARS);

	/* don't change it if already set - save wear and tear on the eeprom */
	if (!strcmp(orig, newval))
		return;

	tries = 0;
	while (tries < 6) {
		upssendchar (NEXT_VAL);
		upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

		/* TODO: test for "OK", bail out on "NO", etc */
		upssendchar (cmdchar);
		upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

		if (!strcmp(temp, newval)) 		/* got it */
			return;

		if (!strcmp(temp, orig)) {		/* wrapped around */
			syslog (LOG_ERR, "setvar: variable %c wrapped!\n", 
			        cmdchar);
			return;
		}

		tries++;
	}

	syslog (LOG_ERR, "setvar: gave up after 6 tries\n");
}

void setstring (struct apc_cmdtab_t * cmd_entry, 
		char *data)
{
	char	temp[256];
	int	i;

	upssendchar(cmd_entry->cmd);
	upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	if (debug)
		printf ("Current %s: [%s]\n", CMDTABNAME(cmd_entry), temp);

	upssendchar (NEXT_VAL);
	usleep (50000);

	for (i = 0; i < strlen(data); i++) {
		upssendchar (data[i]);
		usleep (50000);
	}

	/* pad to 8 chars with CRs */
	for (i = strlen(data); i < cmd_entry->info_len; i++) {
		upssendchar (13);
		usleep (50000);
	}
	/* Make sure a CR was definitely sent */
	if (strlen(data) >= cmd_entry->info_len)
		upssendchar (13);

	usleep (50000);
	upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	usleep (50000);
	/* TODO: check for "OK" or "NO" or similar */
}

void setvar (int auxcmd, int dlen, char *data)
{
	struct apc_cmdtab_t * cmd_entry;
	cmd_entry = INFO_LOOKUP(auxcmd);
	if (cmd_entry == NULL) {
		syslog (LOG_ERR, "ERROR: Capability 0x%04x unknown by driver\n", auxcmd);
		return;
	}
	if ((cmd_entry->driver_flags & APC_PRESENT) == 0) {
		syslog (LOG_ERR, "ERROR: %s setting unsupported by UPS\n", CMDTABNAME(cmd_entry));
		return;
	}
	if ((cmd_entry->info_flags & FLAG_RW) == 0) {
		syslog (LOG_ERR, "ERROR: %s cannot be set - read only\n", CMDTABNAME(cmd_entry));
		return;
	}
	if ((cmd_entry->info_flags & FLAG_ENUM)) {
		hw_set (cmd_entry->cmd, data);
	} else if ((cmd_entry->info_flags & FLAG_STRING)) {


	} else {
		syslog (LOG_ERR, "ERROR: %s cannot be set - unknown type\n", CMDTABNAME(cmd_entry));
	}
	query_ups(auxcmd, 0);
}

/* check for calibration status and either start or stop */
void do_cal (int start)
{
	char	temp[256];
	int	tval, ret;

	upssendchar (REQ_STATUS);
	ret = upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (!ret)		/* didn't get status, bail out */
		return;

	tval = strtol (temp, 0, 16);

	if (tval & 1) {		/* calibration currently happening */
		if (start == 0)	{		/* stop requested */
			syslog (LOG_INFO, "Stopping runtime calibration");
			upssendchar (REQ_CAL);
			return;
		}

		/* requested start while calibration still running */
		syslog (LOG_INFO, "Runtime calibration already in progress");
		return;
	}

	/* calibration not happening */

	if (start == 0) {		/* stop requested */
		syslog (LOG_INFO, "Runtime calibration not occurring");
		return;
	}

	syslog (LOG_INFO, "Starting runtime calibration");
	upssendchar (REQ_CAL);
}

/* handle the CMD_OFF with some paranoia */
void do_off (void)
{
	static	time_t lastcmd = 0;
	time_t	now, elapsed;

#ifdef CONFIRM_DANGEROUS_COMMANDS
	time (&now);
	elapsed = now - lastcmd;

	/* reset the timer every call - this means if you call it too      *
	 * early, then you have to wait MINCMDTIME again before sending #2 */
	lastcmd = now;

	if ((elapsed < MINCMDTIME) || (elapsed > MAXCMDTIME)) {

		/* FUTURE: tell the user (via upsd) to try it again */
		/* msgreply (UPSMSG_REPAGAIN); */
		return;
	}
#endif

	syslog (LOG_INFO, "Sending powerdown command to UPS\n");
	upssendchar (REQ_OFF);
	usleep (1500000);
	upssendchar (REQ_OFF);
}

void instcmd (int auxcmd, int dlen, char *data)
{
	char	temp[256];

	/* TODO: reply to upsd? */

	switch (auxcmd) {
		case CMD_FPTEST:	/* front panel test */
			upssendchar (REQ_FPTEST);
			upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
			break;
		case CMD_BTEST1:	/* start battery test */
			upssendchar (REQ_BTEST);
			break;
		case CMD_OFF:		/* power off the load */
			do_off();
			break;
		case CMD_ON:		/* power on the load */
			upssendchar (REQ_ON);
			usleep (500000);
			upssendchar (REQ_ON);
			break;
		case CMD_CAL0:		/* stop runtime calibration */
			do_cal(0);
			break;
		case CMD_CAL1:		/* start runtime calibration */
			do_cal(1);
			break;
		default:
			syslog (LOG_INFO, "instcmd: unknown type 0x%04x\n", 
			        auxcmd);
	}
}

/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	upsh.setvar = setvar;
	upsh.instcmd = instcmd;
}

void usage (char *prog)
{
	printf ("usage: %s [-D] [-h] [-c <cable>] [-d <num>] [-s <num>] [-k] <device>\n", prog);
	printf ("Example: %s /dev/ttyS0\n", prog);
	exit (1);
}

void help (char *prog)
{
	printf ("usage: %s [-D] [-h] [-c <cable>] [-d <num>] [-s <num>] [-k] <device>\n", prog);
	printf ("\n");
	printf ("-D       - Debug.  Another -D gives you more debug.");
	printf ("-c       - specify '" ALT_CABLE_1 "' if using this cable\n");
	printf ("-d <num> - wait <num> seconds after sending shutdown command\n");
	printf ("-h       - display this help\n");
	printf ("-k       - force shutdown\n");
	printf ("-s <num> - use shutdown command set <num> for forced shutdown\n");
	printf ("<device> - /dev entry corresponding to UPS port\n");
	exit (1);
}

/* 940-0095B support: set DTR, lower RTS */
void init_serial()
{
	int	dtr_bit = TIOCM_DTR;
	int	rts_bit = TIOCM_RTS;

	ioctl(upsfd, TIOCMBIS, &dtr_bit);
	ioctl(upsfd, TIOCMBIC, &rts_bit);
}

int main (int argc, char **argv)
{
	char	*portname, temp[256], *prog;
	int	i;
	time_t last_full;

	printf ("Network UPS Tools - APC Smart protocol driver 0.50 (%s)\n", UPS_VERSION);
	openlog ("apcsmart", LOG_PID, LOG_FACILITY);
	intialise_data_tables();

	prog = argv[0];

	if (argc == 1)
		usage (prog);

	while ((i = getopt(argc, argv, "+Dhd:k:s:c:")) != EOF) {
		switch (i) {
			case 'D':
				debug++;
				break;
			case 'd':
				sddelay = atoi(optarg);
				break;
			case 'k':
				forceshutdown(optarg);
				break;
			case 'h':
				help(prog);
				break;
			case 's':
				shutdowncmdset = atoi(optarg);
				break;
			case 'c':
				cable = strdup(optarg);
				break;
			default:
				usage(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;
	if (debug > 1)
		upsc_debug = 1;

	droproot();

	if (argc < 1) {
		printf ("Error: no device specified!\n");
		usage (prog);
	}

	portname = NULL;
	for (i = strlen(argv[0]); i >= 0; i--)
		if (argv[0][i] == '/') {
			portname = &argv[0][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[0]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/apcsmart-%s", STATEPATH,
	          portname);
	open_serial (argv[0], B2400);

	if (cable != 0 && strcmp(cable,ALT_CABLE_1) == 0)
		init_serial();

	upssendchar (GO_SMART);
	upsrecv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (strcmp(temp, "SM") != 0) {
		printf ("Unable to detect an APC Smart protocol UPS on port %s\n", argv[0]);
		printf ("Check the cabling, port name or model name and try again\n");
		exit (1);
	}

	info = create_info (infomax, shmok);

	/* manufacturer ID - hardcoded in this particular module */
	addinfo (INFO_MFR, "APC", 0, 0);

	createmsgq();	/* try to create IPC message queue */

	setuphandlers();

	/* see what's out there */
	getbaseinfo();

	printf ("Detected %s [%s] on %s\n", getdata(INFO_MODEL), 
		getdata(INFO_SERIAL), argv[0]);

	if (!debug)
		background();
	else
		printf("Not going into background in debug mode\n");

	addcleanup();
	time(&last_full);

	for (;;) {
		time_t tval;

		time(&tval);
		if (debug) {
			printf("UPS update loop %s", ctime(&tval));
		}

		if ((tval - last_full) > 3600) {
			updateinfo(1);
			last_full = tval;
		} else
			updateinfo(0);

		/* wait up to 2 seconds for a message from the upsd */

		if (getupsmsg(2) && debug)	/* TODO: remove debug scaffolding */
			syslog (LOG_INFO, "Received a message from upsd\n");
	}
}
