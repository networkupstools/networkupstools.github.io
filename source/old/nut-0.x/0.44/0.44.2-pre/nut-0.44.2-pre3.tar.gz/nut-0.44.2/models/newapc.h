/* apcsmart.h - serial commands for APC smart protocol units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#define GO_SMART	'Y'
/* NB I mean to dispose of nearly all of these
   and use the cmdtab as the definitive source
*/
#define REQ_CMDSET	'a'
#define REQ_MODEL	0x01	/* ^A */
#define REQ_SERIAL	'n'
#define REQ_UTILITY	'L'
#define REQ_BATTPCT	'f'
#define REQ_STATUS	'Q'
#define REQ_UPSTEMP	'C'
#define REQ_ACFREQ	'F'
#define REQ_LOADPCT	'P'
#define REQ_LOWXFER	'l'
#define REQ_HIGHXFER	'u'
#define REQ_AMBHUMID	'h'
#define REQ_CONTACTS    'i'
#define REQ_AMBTEMP	't'
#define REQ_UPSIDENT	'c'
#define REQ_WAKEDELAY   'r'
#define REQ_LINESENS	's'
#define REQ_CAPABILITIES 26
#define NEXT_VAL	'-'
#define REQ_FPTEST	'A'
#define REQ_BTEST	'U'
#define REQ_OFF		'Z'
#define REQ_ON		0x0E	/* ^N */
#define REQ_CAL		'D'
#define ENDCHAR 10		/* APC ends responses with LF */
#define IGNCHARS "\015+$|!"	/* special characters to ignore */

/* dangerous instant commands must be reconfirmed within a 12 second window */
#define CONFIRM_DANGEROUS_COMMANDS 1
#define MINCMDTIME	3
#define MAXCMDTIME	15


/* Driver command table flag values */
#define APC_TYPEMASK	3
#define APC_POLL	0x10	/* Poll this variable */
#define APC_PRESENT	0x100	/* Capability seen on this UPS */
#define APC_FORMATMASK	0xFF0000 /* Mask for apc data formats */
#define APC_F_ST	0x010000 /* Status format */
#define APC_F_PERCENT	0x020000 /* Data in a percent format */
#define APC_F_VOLT	0x030000 /* Data in a percent format */
#define APC_F_CELCIUS	0x040000 /* Data in a percent format */
#define APC_F_SECONDS	0x100000 /* Time in seconds */
#define APC_F_MINUTES	0x110000 /* Time in minutes */
#define APC_F_HOURS	0x120000 /* Time in hours */
#define APC_F_LEAVE	0	/* Just pass this through */

struct apc_cmdtab_t {
	int		info_type;	/* the INFO_ index */
	int		info_len;	/* length of INFO data if writable */
	unsigned int	info_flags;	/* INFO flag values - NB Flag enum/rw set by cap check */
	unsigned int	driver_flags; 	/* driver specific flags */
	struct netvars_t * info;	/* netvars data - really printable info */
	char		cmd;		/* command character */
} apc_cmdtab[] = {
	{INFO_MODEL,	0, 0,   	0,			NULL,	0x01},
	{INFO_SERIAL,	0, 0,   	0,			NULL,	'n'},
	{INFO_UTILITY,	0, 0,		APC_POLL|APC_F_VOLT,	NULL,	'L'},
	{INFO_BATTPCT,	0, 0,		APC_POLL|APC_F_PERCENT,	NULL,	'f'},
	{INFO_STATUS,	0, 0,		APC_POLL|APC_F_ST,	NULL,	'Q'},
	{INFO_UPSTEMP,	0, 0,		APC_POLL|APC_F_CELCIUS,	NULL,	'C'},
	{INFO_ACFREQ,	0, 0,		APC_POLL,		NULL,	'F'},
	{INFO_LOADPCT,	0, 0,		APC_POLL|APC_F_PERCENT,	NULL,	'P'},
	{INFO_LOWXFER,	0, 0,		APC_F_VOLT,		NULL,	'l'},
	{INFO_HIGHXFER,	0, 0,		APC_F_VOLT,		NULL,	'u'},
	{INFO_AMBHUMID,	0, 0,		APC_POLL|APC_F_PERCENT,	NULL,	'h'},
	{INFO_AMBTEMP,	0, 0,		APC_POLL|APC_F_CELCIUS,	NULL,	't'},
	{INFO_CONTACTS,	0, 0,		APC_POLL,		NULL,	'i'},
	{INFO_UPSIDENT,	8, FLAG_RW | FLAG_STRING,
					0,			NULL,	'c'},
	{INFO_WAKEDELAY,0, 0,		APC_F_SECONDS,		NULL,	'r'},
	{INFO_LINESENS,	0, 0,		0,			NULL,	's'},
	{INFO_WAKETHRSH,0, 0,		APC_F_PERCENT,		NULL,	'e'},
	{INFO_REQVOLT,	0, 0,		APC_F_VOLT,		NULL,	'o'},
	{INFO_LOBATTIME,0, 0,		APC_F_MINUTES,		NULL,	'q'},
	{INFO_PDNGRACE,	0, 0,		APC_F_SECONDS,		NULL,	'p'},
	{INFO_ALRMDELAY,0, 0,		0,			NULL,	'k'},
	{INFO_SLFTSTINT,0, 0,		APC_F_HOURS,		NULL,	'E'},
	{INFO_FIRMREV,  0, 0,		0,			NULL,	'b'},
	{INFO_REG1,	0, 0,		APC_POLL,		NULL,	'~'},
	{INFO_REG2,	0, 0,		APC_POLL,		NULL,	0x27},
	{INFO_REG3,	0, 0,		APC_POLL,		NULL,	'8'},
	{INFO_LINEQUAL,	0, 0,		APC_POLL,		NULL,	'9'},
	{INFO_BATTPACKS,0, 0,		0,			NULL,	'>'},
	{INFO_BATTVOLT,	0, 0,		APC_POLL|APC_F_VOLT,	NULL,	'B'},
	{INFO_XFERWHY,	0, 0,		APC_POLL,		NULL,	'G'},
	{INFO_MAXUTIL,	0, 0,		0,			NULL,	'M'},
	{INFO_MINUTIL,	0, 0,		0,			NULL,	'N'},
	{INFO_OUTVOLT,	0, 0,		APC_POLL|APC_F_VOLT,	NULL,	'O'},
	{INFO_SLFTSTRES,0, 0,		0,			NULL,	'X'},
	{INFO_RUNTIME,	0, 0,		APC_POLL|APC_F_MINUTES,	NULL,	'j'},
	{INFO_MFRDATE,	0, 0,		0,			NULL,	'm'},
	{0,		0, 0,		0,			NULL,	0},
};
