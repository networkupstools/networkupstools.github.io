#define UPS_VERSION "0.44.2-pre2"
