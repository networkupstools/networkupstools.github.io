/* upssched.h - supporting structures */

/* ntable[]: map upsmon's notify names into numbers for easier digestion */

#define NOTIFY_COMMOK 1
#define NOTIFY_COMMBAD 2

struct {
	char	*name;	
	int	type;
}	ntable[] =
{
	{ "COMMOK",	NOTIFY_COMMOK	},
	{ "COMMBAD",	NOTIFY_COMMBAD	},
	{ NULL,		0		}
};

/* internal values for the unix domain socket */
#define CMD_START_TIMER 1
#define CMD_CANCEL_TIMER 2

/* what actually goes over the socket */
#define CMDMAGIC 0xf00fc7c8

typedef struct {
	int     magic;
	int     cmd;
	char    data1[256]; 
	char    data2[256];
}	cmdtype;
