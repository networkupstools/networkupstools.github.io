/* apcsmart.c - model specific routines for APC smart protocol units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "apcsmart.h"
#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

	int	shmok = 1;
	char	statefn[256];
	itype	*info;
extern	int	flag_timeoutfailure;
	int	cap_measureupsii = 0;
	int	infomax = 40;
	int	upslevel = 0;
	
	int	sddelay = 60;	/* wait 60 seconds for shutdown */
extern	struct	ups_handler	upsh;

/* try to find AMBTEMP, CONTACTS and AMBHUMID */
void test_measureupsii()
{
	char	temp[256];

	send (REQ_AMBTEMP);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (!strcmp(temp, "NA"))	/* not supported */
		return;

	/* we got something, so it must be supported */

	cap_measureupsii = 1;		/* log this fact */

	addinfo (INFO_AMBTEMP, temp, 0, 0);

	/* Now probe the contacts */

	send (REQ_CONTACTS);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	addinfo (INFO_CONTACTS, temp, 0, 0);

	/* now try for ambient humidity support */

	send (REQ_AMBHUMID);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (!strcmp(temp, "NA"))	/* not supported */
		return;

	addinfo (INFO_AMBHUMID, temp, 0, 0);
}

void addcap (char cmdchar, char *value)
{
	switch (cmdchar) {
		case 'u': addinfo (INFO_ENUM, value, 0, INFO_HIGHXFER);
			  break;
		case 'l': addinfo (INFO_ENUM, value, 0, INFO_LOWXFER);
			  break;
		case 'e': break;	/* TODO: return threshold	*/
		case 'o': break;	/* output voltages, unused now	*/
		case 's': addinfo (INFO_ENUM, value, 0, INFO_LINESENS);
			  break;
		case 'q': break;	/* TODO: low batt warning	*/
		case 'p': break;	/* TODO: shutdown grace delay	*/
		case 'k': break;	/* TODO: alarm delay		*/
		case 'r': addinfo (INFO_ENUM, value, 0, INFO_WAKEDELAY);
			  break;
		case 'E': break;	/* TODO: selftest intervals	*/
		case 0x06: break;	/* TODO: find out what ^F is	*/
		case 0x0c: break;	/* TODO: front panel language	*/
		case 'w': break;	/* TODO: runtime conservation	*/
		default:
			printf ("Unrecognized cmdchar %c, value %s\n", 
			        cmdchar, value);
	}		
}	

void do_capabilities (char *port)
{
	char	upsloc, temp[256], *ptr, cmd, loc, *entptr, etmp[16];
	int	nument, entlen, i, matrix;

	/* just in case ... */
	usleep (50000);

	/* get location byte for later comparisons */
	send ('b');
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	upsloc = temp[strlen(temp) - 1];
	
	/* add base entries for these variables */
	addinfo (INFO_LOWXFER, "", FLAG_RW | FLAG_ENUM, 4);
	addinfo (INFO_HIGHXFER, "", FLAG_RW | FLAG_ENUM, 4);
	addinfo (INFO_WAKEDELAY, "", FLAG_RW | FLAG_ENUM, 4);
	addinfo (INFO_LINESENS, "", FLAG_RW | FLAG_ENUM, 4);
	installinfo (INFO_LOWXFER, REQ_LOWXFER, ENDCHAR, IGNCHARS);
	installinfo (INFO_HIGHXFER, REQ_HIGHXFER, ENDCHAR, IGNCHARS);
	installinfo (INFO_WAKEDELAY, REQ_WAKEDELAY, ENDCHAR, IGNCHARS);
	installinfo (INFO_LINESENS, REQ_LINESENS, ENDCHAR, IGNCHARS);

	/* get capability string */
	send (REQ_CAPABILITIES);	/* ^Z */
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (temp[0] != '#') {
		printf ("Unrecognized capability start char %c\n", temp[0]);
		printf ("Please report this error [%s]\n", temp);
		return;
	}

	if (temp[1] == '#') {		/* Matrix-UPS */
		matrix = 1;
		ptr = &temp[0];
	}
	else {
		ptr = &temp[1];
		matrix = 0;
	}

	/* command char, location, # of entries, entry length */

	while (ptr[0] != '\0') {
		if (matrix)
			ptr += 2;	/* jump over repeating ## */

		cmd = ptr[0];
		loc = ptr[1];
		nument = ptr[2] - 48;
		entlen = ptr[3] - 48;
		entptr = &ptr[4];

		for (i = 0; i < nument; i++) {
			snprintf (etmp, entlen + 1, "%s", entptr);
			if ((loc == upsloc) || (loc == '4'))
				addcap (cmd, etmp);
			entptr += entlen;
		}
		ptr = entptr;
	}
}

void getbaseinfo (char *port)
{
	char	temp[256];
	int	silentfail = 0;
	int	recvret = 0;

	upslevel = 1;

	/* really old models ignore REQ_MODEL, so find them first */
	send (REQ_MODEL);
	strcpy (temp, "NA");

	/* disable timeout complaints temporarily */
	flag_timeoutfailure = -1;
	recvret = recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	flag_timeoutfailure = 0;

	if ((recvret == -1) || (!strcmp(temp, "NA"))) {
		/* force the model name */
		addinfo (INFO_MODEL, "Smart-UPS", 0, 0);
		silentfail = 1;
	}
	else
		addinfo (INFO_MODEL, temp, 0, 0);

	addinfo (INFO_SERIAL, "", 0, 0);
	installinfo (INFO_SERIAL, REQ_SERIAL, ENDCHAR, IGNCHARS);

	addinfo (INFO_STATUS, "", 0, 0);
	installinfo (INFO_STATUS, REQ_STATUS, ENDCHAR, IGNCHARS);

	/* upslevel 1: Smart-UPS v/s, older Back-UPS Pros */
	send (REQ_UTILITY);
	strcpy (temp, "NA");
	recvret = recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	if ((!strcmp(temp, "NA")) || (recvret == -1)) {
		upslevel = 1;
		return;
	}

	/* upslevel 2: at least a modern Smart-UPS / Back-UPS Pro */
	upslevel = 2;	

	/* add other things to monitor and prime them with values */

	addinfo (INFO_UTILITY, "", 0, 0);
	installinfo (INFO_UTILITY, REQ_UTILITY, ENDCHAR, IGNCHARS);

	addinfo (INFO_BATTPCT, "", 0, 0);
	installinfo (INFO_BATTPCT, REQ_UTILITY, ENDCHAR, IGNCHARS);

	addinfo (INFO_ACFREQ, "", 0, 0);
	installinfo (INFO_ACFREQ, REQ_ACFREQ, ENDCHAR, IGNCHARS);

	addinfo (INFO_LOADPCT, "", 0, 0);
	installinfo (INFO_LOADPCT, REQ_LOADPCT, ENDCHAR, IGNCHARS);

	/* upslevel 3: at least a Smart-UPS (beyond the Back-UPS Pro) */

	/* test for UPSTEMP support */
	send (REQ_UPSTEMP);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	if (strcmp(temp, "NA") != 0) {
		upslevel = 3;
		addinfo (INFO_UPSTEMP, temp, 0, 0);
	}

	addinfo (INFO_UPSIDENT, "", FLAG_RW | FLAG_STRING, 8);
	installinfo (INFO_UPSIDENT, REQ_UPSIDENT, ENDCHAR, IGNCHARS);

	/* add a few more things as read-only */
	if (silentfail == 1) {
		addinfo (INFO_LOWXFER, "", 0, 0);
		addinfo (INFO_HIGHXFER, "", 0, 0);
		addinfo (INFO_WAKEDELAY, "", 0, 0);
	 	installinfo (INFO_LOWXFER, REQ_LOWXFER, ENDCHAR, IGNCHARS);
		installinfo (INFO_HIGHXFER, REQ_HIGHXFER, ENDCHAR, IGNCHARS);
		installinfo (INFO_WAKEDELAY, REQ_WAKEDELAY, ENDCHAR, IGNCHARS);
		return;
	}

	/* see if we have a Measure-UPS II connected */
	test_measureupsii();

	do_capabilities(port);

	/* now add the instant commands */
	addinfo (INFO_INSTCMD, "", 0, CMD_FPTEST);
	addinfo (INFO_INSTCMD, "", 0, CMD_BTEST1);
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256], itemp[256];
	int	tval;

	/* try to wake up a dead ups once in awhile */
	if (flag_timeoutfailure == 1) {
		send (GO_SMART);
		recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	}

	/* parse the status */
	send (REQ_STATUS);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	tval = strtol (temp, 0, 16);

	strcpy (itemp, "");
	if (tval & 1)
		strcat (itemp, "CAL ");		/* calibration */
	if (tval & 2)
		strcat (itemp, "TRIM ");	/* SmartTrim */
	if (tval & 4)
		strcat (itemp, "BOOST ");	/* SmartBoost */
	if (tval & 8)
		strcat (itemp, "OL ");		/* on line */
	if (tval & 16)
		strcat (itemp, "OB ");		/* on battery */
	if (tval & 32)
		strcat (itemp, "OVER ");	/* overload */
	if (tval & 64)
		strcat (itemp, "LB ");		/* low battery */
	if (tval & 128)
		strcat (itemp, "RB ");		/* replace batt */	

	if (!strcmp(temp, "00"))
		strcpy (itemp, "OFF");

	/* lose trailing space if present */
	if (itemp[strlen(itemp)-1] == ' ')
		itemp[strlen(itemp)-1] = 0;

	setinfo (INFO_STATUS, itemp);

	/* upslevel 1 only has a status readback */
	if (upslevel < 2) {
		writeinfo(info);
		return;
	}

	installinfo (INFO_UTILITY, REQ_UTILITY, ENDCHAR, IGNCHARS);
	installinfo (INFO_BATTPCT, REQ_BATTPCT, ENDCHAR, IGNCHARS);
	installinfo (INFO_ACFREQ, REQ_ACFREQ, ENDCHAR, IGNCHARS);
	installinfo (INFO_LOADPCT, REQ_LOADPCT, ENDCHAR, IGNCHARS);

	/* need at least 3 for ups temperature and Measure-UPS II */
	if (upslevel < 3) {
		writeinfo (info);
		return;
	}

	installinfo (INFO_UPSTEMP, REQ_UPSTEMP, ENDCHAR, IGNCHARS);

	if (cap_measureupsii) {
		installinfo (INFO_AMBHUMID, REQ_AMBHUMID, ENDCHAR, IGNCHARS);
		installinfo (INFO_AMBTEMP, REQ_AMBTEMP, ENDCHAR, IGNCHARS);
		installinfo (INFO_CONTACTS, REQ_CONTACTS, ENDCHAR, IGNCHARS);
	}

	writeinfo(info);
}

/* power down the attached load immediately */
void forceshutdown(char *port)
{
	char	temp[32];
	int	tval;

	syslog (LOG_INFO, "Initiating UPS shutdown\n");
	printf ("Initiating forced UPS shutdown!\n");

	open_serial (port, B2400);

	send (GO_SMART);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	if (strcmp(temp, "SM") != 0)
		printf ("Detection failed.  Trying a shutdown command anyway.\n");

	/* check the line status */

	send (REQ_STATUS);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	tval = strtol (temp, 0, 16);

	/* @000 - shutdown after 'p' grace period             */
	/*      - returns after 000 minutes (i.e. right away) */

	/* S    - shutdown after 'p' grace period, only on battery */
	/*        returns after 'e' charge % plus 'r' seconds      */	

	if (tval & 8) {			/* on line */
		printf ("On line, sending shutdown+return command...\n");
		send ('@');
		usleep (50000);
		send ('0');
		usleep (50000);
		send ('0');
		usleep (50000);
		send ('0');
	}
	else {
		printf ("On battery, sending normal shutdown command...\n");
		send ('S');
	}

	sleep (sddelay);
	printf ("Hmm, did the shutdown fail?  Oh well...\n");
	exit (1);
}

/* set a value in the hardware using the <cmdchar> '-' (repeat) approach */
void hw_set (char cmdchar, char *newval)
{
	char	temp[256], orig[256];
	int	tries;

	send (cmdchar);
	recv (orig, sizeof(orig), ENDCHAR, IGNCHARS);

	/* don't change it if already set - save wear and tear on the eeprom */
	if (!strcmp(orig, newval))
		return;

	tries = 0;
	while (tries < 6) {
		send (NEXT_VAL);
		recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

		/* TODO: test for "OK", bail out on "NO", etc */
		send (cmdchar);
		recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

		if (!strcmp(temp, newval)) 		/* got it */
			return;

		if (!strcmp(temp, orig)) {		/* wrapped around */
			syslog (LOG_ERR, "setvar: variable %c wrapped!\n", 
			        cmdchar);
			return;
		}

		tries++;
	}

	syslog (LOG_ERR, "setvar: gave up after 6 tries\n");
}

void setident (char *data)
{
	char	temp[256];
	int	i;

	send (REQ_UPSIDENT);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	printf ("Current ident: [%s]\n", temp);

	send (NEXT_VAL);
	usleep (50000);

	for (i = 0; i < strlen(data); i++) {
		send (data[i]);
		usleep (50000);
	}

	/* pad to 8 chars with CRs */
	for (i = strlen(data); i < 8; i++) {
		send (13);
		usleep (50000);
	}

	usleep (50000);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	/* TODO: check for "OK" or "NO" or similar */
}

void setvar (int auxcmd, int dlen, char *data)
{
	/* TODO: look this up from a table? */
	switch (auxcmd) {
		case INFO_WAKEDELAY:
			hw_set (REQ_WAKEDELAY, data);
			installinfo (INFO_WAKEDELAY, REQ_WAKEDELAY, ENDCHAR, IGNCHARS);
			break;
		case INFO_LOWXFER:
			hw_set (REQ_LOWXFER, data);
			installinfo (INFO_LOWXFER, REQ_LOWXFER, ENDCHAR, IGNCHARS);
			break;
		case INFO_HIGHXFER:
			hw_set (REQ_HIGHXFER, data);
			installinfo (INFO_HIGHXFER, REQ_HIGHXFER, ENDCHAR, IGNCHARS);
			break;
		case INFO_LINESENS:
			hw_set (REQ_LINESENS, data);
			installinfo (INFO_LINESENS, REQ_LINESENS, ENDCHAR, IGNCHARS);
			break;
		case INFO_UPSIDENT:
			setident (data);
			installinfo (INFO_UPSIDENT, REQ_UPSIDENT, ENDCHAR, IGNCHARS);
			break;
		default:
			syslog (LOG_ERR, "setvar: unknown type 0x%04x\n", 
			        auxcmd);
	}
}

void instcmd (int auxcmd, int dlen, char *data)
{
	char	temp[256];

	/* TODO: reply to upsd? */

	switch (auxcmd) {
		case CMD_FPTEST:	/* front panel test */
			send (REQ_FPTEST);
			recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
			break;
		case CMD_BTEST1:	/* start battery test */
			send (REQ_BTEST);
			recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
			break;
		default:
			syslog (LOG_INFO, "instcmd: unknown type 0x%04x\n", 
			        auxcmd);
	}
}

/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	upsh.setvar = setvar;
	upsh.instcmd = instcmd;
}

void usage (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("Example: %s /dev/ttyS0\n", prog);
	exit (1);
}

void help (char *prog)
{
	printf ("usage: %s [-h] [-d <num>] [-k] <device>\n", prog);
	printf ("\n");
	printf ("-d <num> - wait <num> seconds after sending shutdown command\n");
	printf ("-h       - display this help\n");
	printf ("-k       - force shutdown\n");
	printf ("<device> - /dev entry corresponding to UPS port\n");
}

int main (int argc, char **argv)
{
	char	*portname, temp[256], *prog;
	int	i;

	printf ("Network UPS Tools - APC Smart protocol driver 0.42 (%s)\n", UPS_VERSION);
	openlog ("apcsmart", LOG_PID, LOG_FACILITY);

	prog = argv[0];

	while ((i = getopt(argc, argv, "+d:hk:")) != EOF) {
		switch (i) {
			case 'd':
				sddelay = atoi(optarg);
				break;
			case 'k':
				forceshutdown(optarg);
				break;
			case 'h':
				help(prog);
				break;
			default:
				usage(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	if (argc != 1) {
		help (prog);
		exit (1);
	}

	droproot();

	portname = NULL;
	for (i = strlen(argv[0]); i >= 0; i--)
		if (argv[0][i] == '/') {
			portname = &argv[0][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[0]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/apcsmart-%s", STATEPATH,
	          portname);
	open_serial (argv[0], B2400);

	send (GO_SMART);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (strcmp(temp, "SM") != 0) {
		printf ("Unable to detect an APC Smart protocol UPS on port %s\n", argv[0]);
		printf ("Check the cabling, port name or model name and try again\n");
		exit (1);
	}

	info = create_info (infomax, shmok);

	/* manufacturer ID - hardcoded in this particular module */
	addinfo (INFO_MFR, "APC", 0, 0);

	createmsgq();	/* try to create IPC message queue */

	setuphandlers();

	/* see what's out there */
	getbaseinfo(argv[0]);

	printf ("Detected %s [%s] on %s (level %i)\n", getdata(INFO_MODEL), 
		getdata(INFO_SERIAL), argv[0], upslevel);

	if (cap_measureupsii)
		printf ("Measure-UPS II detected!\n");

	background();

	for (;;) {
		updateinfo();

		/* wait up to 2 seconds for a message from the upsd */

		if (getupsmsg(2))	/* TODO: remove debug scaffolding */
			syslog (LOG_INFO, "Received a message from upsd\n");
	}
}
