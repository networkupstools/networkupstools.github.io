/* fentonups.h - model capability table

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

struct {
	char	*mtext;
	char	*desc;
	float	lowvolt;
	float	voltrange;
	int	lowxfer;
	int	lownorm;
	int	highnorm;
	int	highxfer;
	int	has_temp;
}	modeltab[] =
{
	/* USA models */
	{ "L280A",  "PowerPal 280",  9.6,  2.4, 84, 98, 126, 142, 0 },
	{ "L425A",  "PowerPal 425",  9.6,  2.4, 84, 98, 126, 142, 0 },	
	{ "L660A",  "PowerPal 660",  19.6, 4.4, 84, 98, 126, 142, 0 },
	{ "L1000A", "PowerPal 1000", 19.6, 4.4, 84, 98, 126, 142, 0 },
	{ "L1400A", "PowerPal 1400", 29.4, 6.6, 84, 98, 126, 142, 0 },

	/* European models */
	{ "L280E",  "PowerPal 280",   9.6, 2.4, 168, 196, 252, 284, 0 },
	{ "L425E",  "PowerPal 425",   9.6, 2.4, 168, 196, 252, 284, 0 },	
	{ "L660E",  "PowerPal 660",  19.6, 4.4, 168, 196, 252, 284, 0 },
	{ "L1000E", "PowerPal 1000", 19.6, 4.4, 168, 196, 252, 284, 0 },
	{ "L1400E", "PowerPal 1400", 29.4, 6.6, 168, 196, 252, 284, 0 },

	{ "M1000", "PowerPure 1000", 25.0,  3.4, 80, 80, 138, 138, 1 },
	{ "M2000", "PowerPure 2000",    0,    0, 80, 80, 138, 138, 1 },
	{ "M3000", "PowerPure 3000",    0,    0, 80, 80, 138, 138, 1 }, 

	{ "H4000", "PowerOn 4000",  154.0, 14.0, 88, 88, 132, 132, 1 },
	{ "H6000", "PowerOn 6000",  154.0, 14.0, 88, 88, 132, 132, 1 },
	{ "H8000", "PowerOn 8000",  154.0, 14.0, 88, 88, 132, 132, 1 },
	{ "H010K", "PowerOn 10000", 154.0, 14.0, 88, 88, 132, 132, 1 },

	/* non-Fenton, yet compatible models */

	{ "UPS-PRO", "PowerGuard PG-600", 0, 0, 170, 200, 250, 270, 1 },

	{ NULL,    NULL,		0,    0,  0,  0,   0,   0 }
};
