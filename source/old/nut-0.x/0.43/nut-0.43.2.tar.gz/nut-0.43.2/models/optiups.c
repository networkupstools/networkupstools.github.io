/* optiups.c - model specific routines for Opti-UPS units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"
#include "common.h"

#define INFOMAX 16
#define UPS_DELAY 150000
#define ENDCHAR 10
#define IGNCHARS ""

	int	shmok = 1, maxbattvolts = 0, cap_upstemp = 0;
	char	statefn[256];
	itype	*info;
extern	int	flag_timeoutfailure;
	float	lowvolt = 0, voltrange;
extern	int	upsfd;
	int	infomax = 16;

void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables - max possible */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", INFOMAX);

	/* now set up room for all future variables that are supported */
	info[1].type = INFO_MFR;
	info[2].type = INFO_MODEL;
	info[3].type = INFO_STATUS;
	info[4].type = INFO_UTILITY;
	info[5].type = INFO_LOADPCT;
	info[6].type = INFO_UPSTEMP;
	info[7].type = INFO_BATTPCT;
	info[8].type = INFO_LOWXFER;
	info[9].type = INFO_HIGHXFER;
	info[10].type = INFO_ACFREQ;
}

char *rtrim (char *in)
{
	int	i;
	char	tmp[256];

	strncpy (tmp, in, sizeof(tmp) - 1);

	for (i = 0; i < strlen(tmp); i++)
		if (tmp [i] == ' ')
			tmp[i] = 0;

	return (strdup(tmp));
}

void openser()
{
	struct	termios	tio;
	int	fd, flags;
 
	fd = open("/dev/ttyS0", O_RDWR | O_NONBLOCK);

	if (fd < 0) {
		printf ("Port not available.\n");
		exit (-1);
	}

	tio.c_cflag = 0 | CREAD | CS8 | HUPCL | CLOCAL;
	tio.c_iflag = 0 | IXANY | IMAXBEL | IXOFF;
	tio.c_oflag = 0 | ONLCR;
	tio.c_lflag = 0 | ECHOE | ECHOKE | ECHOCTL | PENDIN;
	tio.c_cc[VMIN] = 1;
	tio.c_cc[VTIME] = 0;

#ifdef HAVE_CFSETISPEED
	cfsetispeed (&tio, B2400);
	cfsetospeed (&tio, B2400);
#endif

	tcsetattr (fd, TCSANOW, &tio);

	flags = 0;
	ioctl (fd, TIOCMSET, &flags);

	upsfd = fd;
}

void getbaseinfo (char *port)
{
	char	temp[256], mch[8], mtemp[8];
	int	flags, sl;

	/* kill DTR and RTS */

	flags = 0;
	ioctl (upsfd, TIOCMSET, &flags);

	/* manufacturer */

	send ('I');
	send ('M');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	snprintf (info[1].value, sizeof(info[1].value), temp);

	/* model parsing */

	send ('I');
	send ('O');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	sl = strlen (temp);
	snprintf (mch, sizeof(mch), "%c%c", temp[sl-2], temp[sl-1]);
	strcpy (mtemp, temp);
	mtemp [sl-2] = 0;

	switch (mch[0]) {
		case 'E': snprintf (info[2].value, sizeof(info[2].value), 
		          "PowerES %ses", mtemp);
			  break;

		case 'P': snprintf (info[2].value, sizeof(info[2].value), 
		          "PowerPS %sps", mtemp);
			  break;

		case 'V': snprintf (info[2].value, sizeof(info[2].value), 
		          "PowerVS %svs", mtemp);
			  break;

		default: snprintf (info[2].value, sizeof(info[2].value), 
		          "Unknown (%s)", temp);
			  break;
	}

	printf ("Detected %s on %s\n", getdata(INFO_MODEL), port);

	/* low transfer */
	send ('F');
	send ('L');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	snprintf (info[8].value, sizeof(info[8].value), "%s", temp);

	/* high transfer */
	send ('F');
	send ('H');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	snprintf (info[9].value, sizeof(info[8].value), "%s", temp);

	return;
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256];
	int	tval, battv;
	float	battf;

	send ('A');
	send ('G');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	tval = strtol (temp, 0, 16);
	strcpy (info[3].value, "");

	if (tval & 8)
		strcat (info[3].value, "OVER ");	/* overload */
	if (tval & 16)
		strcat (info[3].value, "RB ");		/* replace batt */
	if (tval & 32)
		strcat (info[3].value, "OB ");		/* on battery */
	else
		strcat (info[3].value, "OL ");		/* on line */
	if (tval & 64)
		strcat (info[3].value, "LB ");		/* low battery */

	if (info[3].value[strlen(info[3].value)-1] == ' ')
		info[3].value[strlen(info[3].value)-1] = 0;

	/* input voltage */
	send ('N');
	send ('V');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	snprintf (info[4].value, sizeof(info[4].value), "%s", temp);

	/* ups load percent */
	send ('O');
	send ('L');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	snprintf (info[5].value, sizeof(info[5].value), "%s", temp);

	/* ups temp */
	send ('B');
	send ('T');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	snprintf (info[6].value, sizeof(info[6].value), "%s", temp);

	/* battery charge */
	send ('B');
	send ('V');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	/* battery voltage range: 10.4 - 13.0 VDC */
	battv = atoi(temp);
	battf = (((battv / 10.0) - 10.4) / 2.6) * 100.0;
	if (battf > 100.0)
		battf = 100.0;
	snprintf (info[7].value, sizeof(info[7].value), "%2.1f", battf);

	/* input freq */
	send ('F');
	send ('F');
	usleep (UPS_DELAY);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	snprintf (info[10].value, sizeof(info[10].value), "%2.1f", 
	          atof(temp) / 10.0);	

	writeinfo(info);
}

int main (int argc, char **argv)
{
	char	*portname;
	int	i;

	printf ("Network UPS Tools - Opti-UPS driver 0.10 (%s)\n", UPS_VERSION);
	openlog ("optiups", LOG_PID, LOG_FACILITY);

	printf ("\n*** EXPERIMENTAL VERSION ***\n");
	printf ("Please send strangeness/success/bug reports so this can become\n");
	printf ("a stable version soon.\n\n");

	/* TODO: getopt */
	if (argc != 2) {
		printf ("usage: %s <portname>       Example: %s /dev/ttyS0\n", 
			argv[0], argv[0]);
		exit (1);
	}

	droproot();

	portname = NULL;
	for (i = strlen(argv[1]); i >= 0; i--)
		if (argv[1][i] == '/') {
			portname = &argv[1][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[1]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/optiups-%s", STATEPATH,
	          portname);

	/* FIXME: why is open_serial so stupid in this module? */
/*	open_serial (argv[1], B2400);  */
	openser(); 

	initinfo();

	createmsgq();		/* try to create IPC message queue */

	getbaseinfo(argv[1]);

 	background();

	for (;;) {
		updateinfo();

		/* wait up to 2 seconds for a message from the upsd */
		if (getupsmsg(2))
			syslog (LOG_INFO, "Received a message from upsd\n");
	}
}
