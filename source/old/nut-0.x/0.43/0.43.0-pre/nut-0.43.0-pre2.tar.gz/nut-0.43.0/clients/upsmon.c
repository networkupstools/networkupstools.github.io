/* upsmon - monitor power status over the 'net (talks to upsd via UDP)

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <errno.h>
#include <fcntl.h>                            
#include <stdio.h>
#include <signal.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>

#include "upsfetch.h"
#include "config.h"
#include "version.h"

	char	*shutdowncmd = NULL, *notifycmd = NULL, *password = NULL;
	char	*powerdownflag = NULL;

	int	online = 1, onbatt = 0, lowbatt = 0, upsresp = -1, fd = -1; 
	int	login = 0, master = 1;

	/* default polling interval = 5 sec */
	int	pollfreq = 5, pollfreqalert = 5;

	/* default alert time = 30 sec */
	int	alerttime = 30;

	/* slave hosts are given 15 sec by default to logout from upsd */
	int	hostsync = 15;

#define SDMAGIC "upsmon-shutdown-file"	/* required contents of flag file */

void wall(char *text)
{
	char	exec[512];

	snprintf (exec, sizeof(exec), "echo \"%s\" | wall", text);
	system (exec);
} 

void notify (char *notice)
{
	char	exec[512];

	syslog (LOG_NOTICE, notice);
	wall (notice);

	if (notifycmd != NULL) {
		snprintf (exec, sizeof(exec), "%s %s", notifycmd, notice);
		system (exec);
	}
}

void heardups(char *upsname)
{
	char	logbuf[256];

	if (upsresp == 1)	/* nothing new ... */
		return;

	if (upsresp == -1) {	/* ups is there, first time */
		upsresp = 1;
		syslog (LOG_INFO, "Communication with UPS established");
	}

	if (upsresp == 0) {	/* ups is back */
		upsresp = 1;
		syslog (LOG_INFO, "Communication with UPS re-established");
	}

	/* LOGIN to the desired UPS if necessary */
	if (login == 0) {
		if (upslogin (fd, upsname, password) == 0)
			login = 1;
		else {
			snprintf (logbuf, sizeof(logbuf), "Unable to login: %s\n",
			          upsstrerror(upserror));
			syslog (LOG_INFO, logbuf);
			return;
		}
	}
}

void upsgone()
{
	if (upsresp == 1) {  /* ups isn't there, first time */
		syslog (LOG_INFO, "Communication with UPS lost");
		upsresp = 0;
	}
}

void upsonbatt()
{
	if (onbatt == 0) {
		notify ("UPS is on battery");
		onbatt = 1;
		online = 0;
	}

	/* TODO: implement alerttime */
}

void upsonline()
{
	if (online == 0) {
		notify ("UPS back on line power");
		online = 1;
		onbatt = 0;
	}
}

/* the actual shutdown procedure */
void doshutdown()
{
	syslog (LOG_CRIT, "Low battery - Executing automatic power-fail shutdown");
	wall ("Low battery - executing automatic power-fail shutdown\n");

	if (getuid() != 0) {
		syslog (LOG_ALERT, "Not root, unable to shutdown system");
		exit (1);
	}

	/* TODO: more user configurability and less hardcoded mess */

	notify ("Auto logout and shutdown in 15 seconds!");
	sleep (15);

	system (shutdowncmd);
	exit (1);
}

/* create the flag file if necessary */
void setpdflag()
{
	FILE	*pdf;

	if (powerdownflag != NULL) {
		pdf = fopen (powerdownflag, "w");
		fprintf (pdf, SDMAGIC);
		fclose (pdf);
	}
}

void upslowbatt(char *upsname)
{
	char	temp[16];
	time_t	start, now;

	/* critical only if on battery + low battery */
	if (onbatt == 0)
		return;

	if (master == 0)
		doshutdown();

	/* master mode: wait up to <wait> seconds for other hosts to logout */

	time (&start);

	for (;;) {	/* see who's still logged in */
		if (getupsvarfd(fd, upsname, "numlogins", temp, sizeof(temp)) >= 0) {
			if (atoi(temp) < 2) {
				syslog (LOG_INFO, "Other clients logged out - shutting down...\n");
				setpdflag();
				doshutdown();
			}
		}

		/* check time, bail out if hostsync interval exceeded */
		time (&now);
		if ((now - start) > hostsync) {
			syslog (LOG_INFO, "Host sync timer expired, forcing shutdown...\n");
			setpdflag();
			doshutdown();
		}

		/* poll every 250ms - try not to flood the network */
		usleep (250000);
	}
}

void background()
{
	int	pid, tempfd;

	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) {
		close (fd);
		exit (0);		/* parent */
	}

	/* child */

	/* leave some valid fds hanging around that go nowhere */

	/* this is done so that certain programs (sendmail...) work */
	tempfd = open ("/dev/null", O_RDWR);
	if (tempfd != STDIN_FILENO) {
		dup2 (tempfd, STDIN_FILENO);
		close (tempfd);
	}
	dup2 (STDIN_FILENO, STDOUT_FILENO);
	dup2 (STDIN_FILENO, STDERR_FILENO);

	syslog (LOG_INFO, "Startup successful");
}

void loadconfig (void)
{
	char	cfn[256], buf[256];
	FILE	*conf;

	snprintf (cfn, sizeof(cfn), "%s/upsmon.conf", CONFPATH);

	conf = fopen(cfn, "r");
	if (conf == NULL) {
		printf ("Can't open %s/upsmon.conf: %s\n", CONFPATH, 
		        strerror(errno));
		exit (1);
	}

	/* TODO: allow overriding stock messages from config file */

	while (fgets(buf, sizeof(buf), conf)) {
		buf[strlen(buf) - 1] = '\0';
		if (!strncmp(buf, "SHUTDOWNCMD", 11))
			shutdowncmd = strdup (&buf[12]);

		if (!strncmp(buf, "NOTIFYCMD", 9)) {
			notifycmd = strdup (&buf[10]);
			syslog (LOG_INFO, "External notify command enabled\n");
		}

		if (!strncmp(buf, "POWERDOWNFLAG", 13)) {
			powerdownflag = strdup (&buf[14]);
			printf ("Using power down flag file %s\n", powerdownflag);
		}

		if (!strncmp(buf, "PASSWORD", 8))
			password = strdup (&buf[9]);

		if (!strncmp(buf, "POLLFREQ", 8))
			pollfreq = atoi(&buf[9]);

		if (!strncmp(buf, "POLLFREQALERT", 13))
			pollfreqalert = atoi(&buf[14]);

		if (!strncmp(buf, "ALERTTIME", 9))
			alerttime = atoi(&buf[10]);

		if (!strncmp(buf, "HOSTSYNC", 8))
			hostsync = atoi(&buf[9]);
	}
	
	fclose (conf);
}

/* SIGPIPE handler */
void sigpipe (int sig)
{
	upsgone();		/* mark ups gone */

	closeupsfd (fd);	/* close connection */

	login = 0;

	fd = -1;		/* start search for new connection */
}

/* basic signal setup to handle SIGPIPE */
void setupsignals()
{
	struct sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = sigpipe;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGPIPE, &sa, NULL);
}

/* handler for alarm when getupsvarfd times out */
void timeout (int sig)
{
	if (upsresp == 1)
		syslog (LOG_INFO, "Communications with UPS timed out\n");

	upsgone();
}

/* see what the status of the UPS is and handle any changes */
void pollups(char *upsname)
{
	char	status[256], *stat;
	struct	sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (10);

	if (getupsvarfd(fd, upsname, "status", status, sizeof(status)) >= 0) {
		signal (SIGALRM, SIG_IGN);
		alarm (0);
		heardups(upsname);

		stat = strtok (status, " ");
		while (stat != NULL) {
			if (!strcasecmp(stat, "OL"))
				upsonline();
			if (!strcasecmp(stat, "OB"))
				upsonbatt();
			if (!strcasecmp(stat, "LB"))
				upslowbatt(upsname);
			stat = strtok(NULL, " ");
		} 
	}
	else {	/* fetch failed */
		signal (SIGALRM, SIG_IGN);
		alarm (0);
		upsgone();
	}
}

/* remove the power down flag if it exists and is the proper form */
void clearpdf ()
{
	FILE	*pdf;
	char	buf[256];

	pdf = fopen (powerdownflag, "r");

	if (pdf == NULL)	/* no such file, nothing to do */
		return;

	/* if it exists, see if it has the right text in it */

	fgets (buf, sizeof(buf), pdf);
	fclose (pdf);

	/* reasoning: say upsmon.conf is world-writable (!) and some nasty
	 * user puts something "important" as the power flag file.  This 
	 * keeps upsmon from utterly trashing it when starting up or powering
	 * down at the expense of not shutting down the UPS.
	 *
	 * solution: don't let mere mortals edit that configuration file.
	 */

	if (!strncmp (buf, SDMAGIC, strlen(SDMAGIC)))	/* ok, it's from us */
		unlink (powerdownflag);
	else {
		printf ("%s doesn't seem to be a proper flag file.  Disabling.\n",
		        powerdownflag);
		powerdownflag = NULL;
	}
}

int main(int argc, char *argv[])  
{
	char	*ptr, *host, *upsname;

	printf ("Network UPS Tools upsmon %s\n", UPS_VERSION);

	if (argc < 2) {
		printf ("Usage: %s <host to monitor> [slave|master]\n", argv[0]);
		printf ("Example: %s 10.2.254.1 master\n", argv[0]);
		exit (1);
	}

	if (argv[2] != NULL) {
		if (!strcasecmp(argv[2], "master"))
			master = 1;

		if (!strcasecmp(argv[2], "slave"))
			master = 0;
	}

	if (master == 0)
		printf ("Slave mode - shutdown at low battery is immediate.\n");
	else
		printf ("Master mode - coordinated shutdown enabled.\n");

	openlog ("upsmon", LOG_PID, LOG_FACILITY);
	loadconfig();

	if (shutdowncmd == NULL)
		printf ("Warning: no shutdown command defined!\n");

	/* we may need to get rid of a flag from a previous shutdown */
	if (powerdownflag != NULL)
		clearpdf ();

	/* split upsname@host into separate parts */
	ptr = strstr (argv[1], "@");
	if (ptr != NULL) {
		ptr[0] = 0;
		upsname = argv[1];
		host = ptr + 1;
	}
	else {
		upsname = NULL;
		host = argv[1];
	}

	/* ignore sigpipes before the connection opens */
	setupsignals();

	/* try a connect - if it fails, we'll try again later */
	fd = upsconnect (host);

	if (upsname != NULL)
		syslog (LOG_INFO, "Monitoring UPS [%s] on %s", upsname, host);
	else
		syslog (LOG_INFO, "Monitoring UPS on %s", host);

	printf ("Monitoring UPS on %s\n", host);

	background();

	for (;;) {
		/* if the connection has been broken, try to re-establish it */
		if (fd == -1)
			fd = upsconnect (host);
		else
			pollups(upsname);

		if ( upsonbatt == 0 )
			sleep (pollfreq);
		else
			sleep (pollfreqalert);
	}

	return (1);
}
