/* upsset - CGI program to manage read/write variables

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include "upsfetch.h"
#include "version.h"
#include "cgilib.h"
#include "config.h"

	int	fd;
	char	*ups, *host, *username, *password, *function;

typedef struct {
	char	*var;
	char	*value;
	void	*next;
}	uvtype;

	uvtype	*firstuv = NULL;

void parsearg (char *var, char *value)
{
	char	*ptr;
	uvtype	*last, *tmp = NULL;

	if (!strncmp(var, "UPSVAR_", 7)) {
		ptr = strchr (var, '_');

		if (!ptr)		/* sanity check */
			return;

		ptr++;

		tmp = last = firstuv;
		while (tmp) {
			last = tmp;
			tmp = tmp->next;
		}

		tmp = malloc (sizeof(uvtype));
		tmp->var = strdup(ptr);
		tmp->value = strdup(value);
		tmp->next = NULL;

		if (last)
			last->next = tmp;
		else
			firstuv = tmp;

		fflush (stdout);

		return;
	}

	if (!strcmp(var, "username"))
		username = strdup (value);

	if (!strcmp(var, "password"))
		password = strdup (value);

	if (!strcmp(var, "function"))
		function = strdup (value);

	if (!strcmp(var, "ups"))
		ups = strdup (value);
}

void do_enum (char *varname)
{
	char	out[256], temp[256], *val, *sel, *ptr;

	snprintf (out, sizeof(out), "ENUM %s\n", varname);	
	upssendraw (fd, out);

	upsreadraw (fd, temp, sizeof(temp));
	if (strncmp(temp, "ENUM", 4) != 0) {
		printf ("Bogus reply from server for %s\n", varname);
		return;
	}

	printf ("<SELECT NAME=\"UPSVAR_%s\">\n", varname);

	upsreadraw (fd, temp, sizeof(temp));
	temp [strlen(temp) - 1] = 0;

	while (strcmp(temp, "END") != 0) {

		/* split into value and selected */
		val = strchr (temp, '"');
		val++;
		sel = strchr (val, ' ');
		if (sel)
			sel++;
		ptr = strchr (val, '"');
		val [ptr - val] = '\0';
			
		printf ("<OPTION VALUE=\"%s\" ", val);
			
		if ((sel != NULL) && (!strcmp(sel, "SELECTED")))
			printf ("SELECTED");

		printf (">%s</OPTION>\n", val);	
		upsreadraw (fd, temp, sizeof(temp));
		temp [strlen(temp) - 1] = 0;
	}
	printf ("</SELECT>\n");
}

void do_string (char *upsname, char *varname, int typelen)
{
	char	temp[256];

	getupsvarfd (fd, upsname, varname, temp, sizeof(temp));
	printf ("<INPUT TYPE=\"TEXT\" NAME=\"UPSVAR_%s\" VALUE=\"%s\" SIZE=\"%i\">\n",
	        varname, temp, typelen);
}

void do_header(char *title)
{
	printf ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"\n");
	printf ("	\"http://www.w3.org/TR/REC-html40/loose.dtd\">\n");
	printf ("<HTML>\n");
	printf ("<HEAD><TITLE>upsset: %s</TITLE></HEAD>\n", title);

	printf ("<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\" LINK=\"#0000EE\" VLINK=\"#551A8B\">\n"); 

	printf ("<TABLE BGCOLOR=\"#50A0A0\" ALIGN=\"CENTER\">\n");
	printf ("<TR><TD>\n");

}

void start_table()
{
	printf ("<TABLE CELLPADDING=\"5\" CELLSPACING=\"0\">\n");
	printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
	printf ("<FONT SIZE=\"+2\">Network UPS Tools upsset %s</FONT>\n", 
	         UPS_VERSION);
	printf ("</TH></TR>\n");
}

void do_hidden(char *next)
{
	printf ("<INPUT TYPE=\"HIDDEN\" NAME=\"username\" VALUE=\"%s\">\n",
	        username);
	printf ("<INPUT TYPE=\"HIDDEN\" NAME=\"password\" VALUE=\"%s\">\n",
	        password);
	printf ("<INPUT TYPE=\"HIDDEN\" NAME=\"function\" VALUE=\"%s\">\n", 
	        next);
}

void do_pickups(char *current)
{
	FILE	*hosts;
	char	buf[256], hostfn[256], addr[64], *rest, *ptr;
	int	ofs;

	snprintf (hostfn, sizeof(hostfn), "%s/hosts.conf", CONFPATH);
	hosts = fopen (hostfn, "r");
	if (!hosts) {
		printf ("Can't open hosts file\n");
		exit (1);
	}

	printf ("<FORM METHOD=\"POST\" ACTION=\"upsset.cgi\">\n");

	printf ("Select a UPS:\n");
	printf ("<SELECT NAME=\"ups\">\n");

	while (fgets(buf, sizeof(buf), hosts)) {
		if (!strncmp(buf, "MONITOR", 7)) {
			sscanf (buf, "%*s %s %n", addr, &ofs);
			rest = buf + ofs + 1;
			ptr = strchr (rest, '"');
			if (ptr)
				*ptr = '\0';

			printf ("<OPTION VALUE=\"%s\"", addr);

			if (current)
				if (!strcmp(current, rest))
					printf (" SELECTED");

			printf (">%s</OPTION>\n", rest);
		}
	}

	fclose (hosts);

	printf ("</SELECT>\n");
	do_hidden("showsettings");
	printf ("<INPUT TYPE=\"SUBMIT\" VALUE=\"View\">\n");
	printf ("</FORM>\n");
}

void loginscreen()	/* HTML 4.0 transitional checked */
{
	do_header("Login");
	printf ("<FORM METHOD=\"POST\" ACTION=\"upsset.cgi\">\n");
	start_table();

	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TH>Username</TH>\n");
	printf ("<TD><INPUT TYPE=\"TEXT\" NAME=\"username\" VALUE=\"\"></TD>\n");
	printf ("</TR>\n");

	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TH>Password</TH>\n");
	printf ("<TD><INPUT TYPE=\"PASSWORD\" NAME=\"password\" VALUE=\"\"></TD>\n");
	printf ("</TR>\n");

	printf ("<TR><TD COLSPAN=2 ALIGN=\"CENTER\">\n");
	printf ("<INPUT TYPE=\"HIDDEN\" NAME=\"function\" VALUE=\"pickups\">\n");
	printf ("<INPUT TYPE=\"SUBMIT\" VALUE=\"Login\">\n");
	printf ("<INPUT TYPE=\"RESET\" VALUE=\"Reset fields\">\n");
	printf ("</TD></TR></TABLE>\n");
	printf ("</FORM>\n");
	printf ("</TD></TR></TABLE>\n");
	printf ("</BODY></HTML>\n");
	exit (0);
}

void checkauth ()
{
	FILE	*pwf;
	char	pwfn[256], buf[256], tusr[32], tpw[32];

	if ((!username) || (!password))
		loginscreen();

	snprintf (pwfn, sizeof(pwfn), "%s/upsset.passwd", CONFPATH);
	pwf = fopen (pwfn, "r");

	if (!pwf) {
		printf ("Error - can't open the upsset passwd file!\n");
		exit (1);
	}

	/* SYSTEM <system> <password> */
	/* USER <username> <password> */

	while (fgets(buf, sizeof(buf), pwf)) {
		buf [strlen(buf) - 1] = '\0';

		if (buf[0] == '#')	/* ignore comments */
			continue;

		if (!strncmp(buf, "USER", 4)) {
			sscanf (buf, "%*s %s %s", tusr, tpw);
			if (!strcmp(tusr, username)) {
				fclose (pwf);
				if (!strcmp(tpw, password))
					return;		/* login OK */
				else
					loginscreen();	/* pw mismatch */
			}
		}
	}

	fclose (pwf);
	loginscreen();		/* user not found */
}

void showsettings()	/* HTML 4.0/transitional checked (main path) */
{
	char	*host, vars[256], temp[256], out[256], *v, *upsname, *upstmp;
	char	type[16], *ptr, *desc;
	int	typelen;

	if (!checkhost (ups, &desc)) {
		do_header("Access denied");
		start_table();
		printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
		printf ("Access to that host is not authorized\n");
		printf ("</TH></TR>\n");
	
		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE>\n");
		printf ("</TD></TR></TABLE>\n");
		printf ("</BODY></HTML>\n");
		exit (0);
	}

	upstmp = strdup (ups);
	ptr = strchr (upstmp, '@');
	if (ptr != NULL) {
		ptr[0] = 0;
		upsname = upstmp;
		host = ptr + 1;
	}
	else {
		upsname = NULL;
		host = upstmp;
	}

	fd = upsconnect (host);
	if (fd < 0) {
		do_header("Connect failure");
		start_table();
		printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
		printf ("Unable to connect to %s - %s\n", host,
		        upsstrerror(upserror));
		printf ("</TH></TR>\n");

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE></TD></TR></TABLE>\n");
		printf ("</BODY></HTML>\n");
		exit (0);
	}

	if (upsname != NULL) {
		snprintf (temp, sizeof(temp), "LISTRW %s\n", upsname);
		upssendraw (fd, temp);
	}
	else
		upssendraw (fd, "LISTRW\n");
	
	if (upsreadraw (fd, vars, sizeof(vars)) < 0) {
		printf ("Unable to get variable list - %s\n",
		        upsstrerror(upserror));
		exit (1);
	}

	do_header("Current settings");
	printf ("<FORM ACTION=\"upsset.cgi\" METHOD=\"POST\">\n");
	start_table();

	/* include the description from checkhost() if present */
	if (desc)
		printf ("<TR><TH BGCOLOR=\"#60B0B0\"COLSPAN=2>%s</TH></TR>\n",
		        desc);

	vars [strlen(vars) - 1] = 0;

	v = strtok (vars, " ");

	/* skip over "@upsname" if using that mode */
	if (upsname != NULL)
		v = strtok (NULL, " ");

	v = strtok (NULL, " ");

	/* do a sanity check before starting into the columns */
	if (v == NULL) {
		printf ("<TR BGCOLOR=\"#60B0B0\">\n");
		printf ("<TD COLSPAN=2 ALIGN=\"CENTER\">No r/w variables supported on this UPS.</TD></TR>\n");

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(desc);
		printf ("</TD></TR>\n");

		printf ("</TABLE></TD></TR></TABLE>\n");
		exit (0);
	}

	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TH>Setting</TH>\n");
	printf ("<TH>Value</TH></TR>\n");

	while (v != NULL) {
		/* get description */
		snprintf (out, sizeof(out), "VARDESC %s\n", v);
		upssendraw (fd, out);
		upsreadraw (fd, temp, sizeof(temp));
		temp [strlen(temp) - 1] = 0;
		printf ("<TR BGCOLOR=\"#60B0B0\" ALIGN=\"CENTER\">\n");

		/* strip off leading/trailing quotes */
		ptr = strchr (temp, '"');
		if (ptr != NULL) {
			ptr++;
			*strchr(ptr, '"') = '\0';
		}

		printf ("<TD>%s</TD>\n", ptr);

		/* now get variable type */
		snprintf (out, sizeof(out), "VARTYPE %s\n", v);
		upssendraw (fd, out);
		upsreadraw (fd, temp, sizeof(temp));
		temp [strlen(temp) - 1] = 0;
		sscanf (temp, "%*s %s %i", type, &typelen); 

		printf ("<TD>\n");

		if (!strcmp(type, "ENUM"))
			do_enum (v);

		if (!strcmp(type, "STRING"))
			do_string (upsname, v, typelen);

		printf ("</TD></TR>\n");
		
		v = strtok (NULL, " ");
	}

	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TD COLSPAN=\"2\" ALIGN=\"CENTER\">\n");
	do_hidden("savesettings");
	printf ("<INPUT TYPE=\"HIDDEN\" NAME=\"ups\" VALUE=\"%s\">\n", ups);
	printf ("<INPUT TYPE=\"SUBMIT\" VALUE=\"Save changes\">\n");
	printf ("<INPUT TYPE=\"RESET\" VALUE=\"Reset\">\n");
	printf ("</TD></TR>\n");
	printf ("</TABLE>\n");
	printf ("</FORM>\n");

	printf ("<TR><TD ALIGN=\"CENTER\">\n");
	do_pickups(desc);
	printf ("</TD></TR>\n");

	printf ("</TABLE>\n");
	printf ("</BODY></HTML>\n");

	exit (0);
}

void savesettings()	/* HTML 4.0/transitional checked (main loop) */
{
	char	*desc, *upstmp, *ptr, *upsname, buf[256], upsn[64], tmppw[64],
		*upspw, pwfn[256];
	uvtype	*upsvar;
	FILE	*pwf;

	if (!checkhost (ups, &desc)) {
		do_header("Access denied");
		start_table();
		printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
		printf ("Access to that host is not authorized\n");
		printf ("</TH></TR>\n");

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE></TD></TR></TABLE>\n");
		exit (0);
	}

	upstmp = strdup (ups);
	ptr = strchr (upstmp, '@');
	if (ptr != NULL) {
		ptr[0] = 0;
		upsname = upstmp;
		host = ptr + 1;
	}
	else {
		upsname = NULL;
		host = upstmp;
	}

	fd = upsconnect (host);
	if (fd < 0) {
		do_header("Connect failure");
		start_table();
		printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
		printf ("Unable to connect to %s - %s\n", host,
		        upsstrerror(upserror));
		printf ("</TH></TR>\n");

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE></TD></TR></TABLE>\n");
		exit (0);
	}

	/* get the right SYSTEM line from the .passwd file */

	snprintf (pwfn, sizeof(pwfn), "%s/upsset.passwd", CONFPATH);
	pwf = fopen (pwfn, "r");

	if (!pwf) {
		do_header("Password file missing");
		start_table();
		printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
		printf ("Error - can't open the upsset passwd file!\n");
		printf ("</TH></TR>\n");

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE></TD></TR></TABLE>\n");
		exit (0);
	}

	upspw = NULL;
	while (fgets(buf, sizeof(buf), pwf)) {
		buf [strlen(buf) - 1] = '\0';

		if (buf[0] == '#')	/* ignore comments */
			continue;

		if (!strncmp(buf, "SYSTEM", 6)) {
			sscanf (buf, "%*s %s %s", upsn, tmppw);
			if (!strcmp(upsn, ups)) {
				upspw = strdup (tmppw);
				break;
			}
		}
	}

	fclose (pwf);

	if (!upspw) {
		do_header("SYSTEM entry missing");
		start_table();
		printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
		printf ("Error - can't find %s in the upsset passwd file!\n",
		        ups);
		printf ("</TH></TR>\n");

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE></TD></TR></TABLE>\n");
		exit (0);
	}

	fclose (pwf);

	do_header("Saving settings");
	start_table();
	upsvar = firstuv;

	snprintf (buf, sizeof(buf), "PASSWORD %s\n", upspw);
	upssendraw (fd, buf);

	/* eat the response */
	upsreadraw (fd, buf, sizeof(buf));

	printf ("<TR><TD><PRE>\n");

	while (upsvar) {
		getupsvarfd(fd, upsname, upsvar->var, buf, sizeof(buf));

		if (strcmp(upsvar->value, buf)) {
			printf ("set %s to %s (now %s)\n", upsvar->var, 
			         upsvar->value, buf);

			if (upsname)
				snprintf (buf, sizeof(buf), "SET %s@%s %s\n", 
				          upsvar->var, upsname, upsvar->value);
			else
				snprintf (buf, sizeof(buf), "SET %s %s\n", 
				          upsvar->var, upsvar->value);

			upssendraw (fd, buf);
			upsreadraw (fd, buf, sizeof(buf));

			/* TODO: clean this up */
			printf ("response: %s\n", buf);
		}

		upsvar = upsvar->next;
	}

	printf ("</PRE></TD></TR>\n");

	printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
	do_pickups(desc);
	printf ("</TD></TR>\n");

	printf ("</TABLE>\n");
	printf ("</TD></TR></TABLE>\n");
	printf ("</BODY></HTML>\n");

	exit (0);
}

int main (int argc, char **argv)
{
	username = password = function = ups = NULL;

	printf ("Content-type: text/html\n\n");

	extractpostargs();

	checkauth();

	if (!strcmp(function, "pickups")) {	/* HTML 4.0/trans checked */
		do_header("Select a UPS");
		start_table();

		printf ("<TR><TD ALIGN=\"CENTER\" COLSPAN=2>\n");
		do_pickups(NULL);
		printf ("</TD></TR>\n");

		printf ("</TABLE>\n");
		printf ("</TD></TR></TABLE>\n");
		printf ("</BODY></HTML>\n");
		exit (0);
	}

	if (!strcmp(function, "showsettings"))
		showsettings();

	if (!strcmp(function, "savesettings"))
		savesettings();

	printf ("Error: Unhandled function name [%s]\n", function);
	
	return (0);
}

