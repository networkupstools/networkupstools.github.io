#define UPS_VERSION "0.43.0-pre1"
