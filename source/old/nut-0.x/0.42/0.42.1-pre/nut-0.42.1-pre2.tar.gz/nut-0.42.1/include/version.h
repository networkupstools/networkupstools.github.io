#define UPS_VERSION "0.42.1-pre2"
