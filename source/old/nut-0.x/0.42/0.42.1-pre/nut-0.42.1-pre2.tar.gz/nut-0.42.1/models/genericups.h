/* genericups.h - contact closure UPS line status definitions

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

struct {
	char	*mfr;
	char	*model;
	char	*desc;
	int	line_norm;
	int	line_ol, val_ol;
	int	line_bl, val_bl;
	int	line_sd;
}	upstab[] =
{
	{ "UPSONIC",
	  "LAN Saver 600",
	  "UPSONIC LAN Saver 600",
	  TIOCM_DTR | TIOCM_RTS,	/* cable power: DTR + RTS	*/
	  TIOCM_CTS, 0,			/* online: CTS off		*/
	  TIOCM_CD, TIOCM_CD,		/* low battery: CD on		*/
	  TIOCM_RTS			/* shutdown: lower DTR		*/
	},

	{ "APC",
	  "Back-UPS",
	  "APC Back-UPS (940-0095A/B/C cable)",
	  TIOCM_DTR,			/* cable power: DTR		*/
	  TIOCM_RNG, 0,			/* online: RNG off		*/
	  TIOCM_CD, 0,			/* low battery: CD off		*/
	  TIOCM_RTS 			/* shutdown: RTS		*/
	},

	{ "APC",
	  "Back-UPS",
	  "APC Back-UPS (940-0020B cable)",
	  0,				/* cable power: none		*/
	  TIOCM_CTS, 0,			/* online: CTS off		*/
	  TIOCM_CD, TIOCM_CD,		/* low battery: CD on		*/
	  TIOCM_DTR|TIOCM_RTS		/* shutdown: DTR + RTS		*/
	},

	{ "PowerTech",
	  "Comp1000",
	  "PowerTech Comp1000 with DTR as cable power",
	  TIOCM_DTR,			/* cable power: DTR		*/
	  TIOCM_CTS, 0,			/* online: CTS off		*/
	  TIOCM_CD, TIOCM_CD,		/* low battery: CD on		*/
	  TIOCM_DTR | TIOCM_RTS		/* shutdown: DTR + RTS		*/
	},

	{ "Centralion",
	  "CL Series",
	  "Centralion CL Series (RUPS cable)",
	  TIOCM_RTS,			/* cable power: RTS		*/
	  TIOCM_CTS, TIOCM_CTS,		/* online: CTS on		*/
	  TIOCM_CD, 0,			/* low battery: CD off		*/
	  0				/* shutdown: drop RTS		*/
	},

	{ "TrippLite",
	  "Internet Office Series",
	  "Tripp Lite UPS with Lan2.2 interface (black 73-0844 cable)",
	  TIOCM_DTR,			/* cable power: DTR		*/
	  TIOCM_CTS, TIOCM_CTS,		/* online: CTS on		*/
	  TIOCM_CD, 0,			/* low battery: CAR off		*/
	  TIOCM_DTR | TIOCM_RTS		/* shutdown: DTR + RTS		*/
	},

	{ "Best",
	  "Patriot",
	  "Best Patriot (INT51 cable)",
	  TIOCM_DTR,			/* cable power: DTR		*/
	  TIOCM_CTS, TIOCM_CTS,		/* online: CTS on		*/
	  TIOCM_CD, 0,			/* low battery: CD off		*/
	  TIOCM_RTS			/* shutdown: set RTS		*/
	},

	{ "CyberPower",
	  "Power99",
	  "CyberPower Power99", 
	  TIOCM_DTR,			/* cable power: DTR		*/
	  TIOCM_DSR, TIOCM_DSR,		/* online: DSR on		*/
	  TIOCM_CTS, 0,			/* low battery: CTS off		*/
	  TIOCM_RTS			/* shutdown: set RTS		*/
	},

	{ NULL,
	  NULL,
	  NULL,
	  0,
	  0, 0,
	  0, 0,
	  0
	}
};
