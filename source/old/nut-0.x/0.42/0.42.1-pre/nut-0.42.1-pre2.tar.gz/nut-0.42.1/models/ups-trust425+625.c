/* ups-trust425+625.c - model specific routines for Trust UPS 425/625
      also known as PowerCom King Pro 425/625 Smart-UPS units

   Copyright (C) 1999  Peter Bieringer <pb@bieringer.de>
     
   based on 
    smartups.c - model specific routines for APC Smart-UPS units
    Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   some hints also taken from
    backups.c - model specific routines for APC Back-UPS units
    Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>


   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

/* Here you can define extended syslog debugging and "do not go in background" mode */
/* #define DEBUG_UPSTRUST425625 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <time.h>
#include <limits.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"
#include "ups-trust425+625.h"

	int	shmok = 1;
	char	statefn[256];
	itype	*info;
	int	infomax = 16;
	int dtr_bit = TIOCM_DTR;
	int rts_bit = TIOCM_RTS;

unsigned char binaryinfo[NUMRECEIVEDBYTES];
time_t timelastvalid;

static int signal_terminate = 0;

/* some conversion functions for the binary field */

/* Binary to AC frequency (input and output) */
float ups_bin2freq(int binary) {
    // constants of cycle time
    static const float m = 0.00020997;
    static const float d = 0.00020928;
    float result;
    
    result = 1.0 / (binary * m + d);
    return(result);
};

/* Binary to LoadLevel in OnLine state */
float ups_bin2load(int binary) {
    static const float m = 4.311;
    static const float d = 0.1811;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to LoadLevel in OnBatt state */
float ups_bin2load_ob(int binary) {
    static const float m = 6.13426854;
    static const float d = -0.38076152;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to BatteryLevel in OnLine state */
float ups_bin2battlvl(int binary) {
    static const float m = 4.5639;
    static const float d = -835.82;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to BatteryLevel in OnBatt state */
float ups_bin2battlvl_ob(int binary_battlevel, int binary_loadlevel) {
    static const float m1 = 5;
    static const float m2 = 0.3268;
    static const float d2 = -825;
    float result;
    
    result = binary_battlevel * m1 + (ups_bin2load_ob(binary_loadlevel) * m2 + d2);
    return(result);
};

/* Binary to Voltage (input and output) in OnLine state */
float ups_bin2volt(int binary) {
    static const float m = 1.9216;
    static const float d = -0.0977;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to Output Voltage in OnBatt state */
/* KNOWN PROBLEM: This value depends on 4 binary values:
    Battery Level, LoadLevel, FreqOut and VoltOut
     -> don't know how to calculate in a right way 
     The given formular isn't ok for all cases! */
float ups_bin2voltout_ob(int binary) {
    static const float m = -4.00349;
    static const float d = 296.7242;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* signals */
void signalTERM()
{
    syslog(LOG_WARNING, "Got signal TERM, so terminating");
    signal_terminate = 1;
    return;
};

void signalINT()
{
    syslog(LOG_WARNING, "Got signal INT, so terminating");
    signal_terminate = 1;
    return;
};

/* init information structure */
void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables (put in 10 for 0-9, etc) */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", 12);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;
	snprintf (info[1].value, sizeof(info[1].value), "Trust/PowerCom");

	info[2].type = INFO_MODEL;
	snprintf (info[2].value, sizeof(info[2].value), "425/625 (KingPro)");

	/* now set up room for all future variables that are supported */
	info[4].type = INFO_UTILITY;
	info[5].type = INFO_BATTPCT;
	info[6].type = INFO_STATUS;
	info[8].type = INFO_ACFREQ;
	info[9].type = INFO_LOADPCT;
}

/* get binary data from the UPSs */
/*  return value:  0x00: ok
		   0x10: primitive check failed	    
*/
int getbinarydata(void)
{
    int status, i;
    unsigned char temp[NUMRECEIVEDBYTES];
    
    syslog (LOG_DEBUG, "Send info request to ups");
    
    send (REQ_BINARYDATA);

    syslog (LOG_DEBUG, "Read info from ups: start");
    
    status = recvbinary (temp, NUMRECEIVEDBYTES);

    if (status == 0) {
        syslog (LOG_DEBUG, "Read info from ups: successful");
	/* some primitive checks */
	if ((temp[5] != 0) || (temp[7] != 0) || (temp[8] != 0)) {
	    /* looks like a transfer error in serial data communication */
	    syslog (LOG_WARNING, "Serial data from ups was invalid!");
	    return (0x10);
	}
	/* copy array */
	for (i = 0; i < NUMRECEIVEDBYTES; i++) {
	    binaryinfo[i] = temp[i];
	}
    }
    else
    {
#ifdef DEBUG_UPSTRUST425625
	syslog (LOG_WARNING, "Read info from ups: not successful");
#endif
    }
    return(status);
}



/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256];
	float	volt_in, acfreq_in, batt_lev, load_lev;
	int 	status;
	
	status = getbinarydata();
	
	if (status == 0) {
	    timelastvalid = time(NULL);
	
	    volt_in = ups_bin2volt(binaryinfo[2]);
	    acfreq_in = ups_bin2freq(binaryinfo[4]);
	    
	    if ((binaryinfo[9] & 0x01) == 0) {
		/* OnLine state */
		load_lev = ups_bin2load(binaryinfo[0]);
	    	batt_lev = ups_bin2battlvl(binaryinfo[1]);
	    }
	    else {
		/* OnBatt state */
		load_lev = ups_bin2load_ob(binaryinfo[0]);
	    	batt_lev = ups_bin2battlvl_ob(binaryinfo[1], binaryinfo[0]);
	    }

	    if (volt_in < ACFREQ_ZEROTH) {
		acfreq_in = 0;
	    }
	
    	    sprintf(temp, "%03.1f", volt_in);
	    installinfodirect (INFO_UTILITY, temp);

    	    sprintf(temp, "%03.1f", batt_lev);
	    installinfodirect (INFO_BATTPCT, temp);
	
    	    sprintf(temp, "%02.2f", acfreq_in);
	    installinfodirect (INFO_ACFREQ, temp);

    	    sprintf(temp, "%03.1f", load_lev);
	    installinfodirect (INFO_LOADPCT, temp);
	
	    strcpy (info[6].value, "");
	    if (((binaryinfo[9] & 0x01) == 0) && ((binaryinfo[9] & 0x80) == 0))
		strcat (info[6].value, "OL ");		/* on line */
	    if (((binaryinfo[9] & 0x01) == 0) && ((binaryinfo[9] & 0x80) != 0))
		strcat (info[6].value, "OFF ");		/* on line */
	    if ((binaryinfo[9] & 0x01) != 0)
		strcat (info[6].value, "OB ");		/* on battery */
	    if ((binaryinfo[9] & 0x02) != 0)
		strcat (info[6].value, "LB ");		/* low battery */
	    if (((binaryinfo[9] & 0x08) != 0) && (volt_in < ACLINEVOLTAGE))
		strcat (info[6].value, "BOOST ");	/* boost voltage */	
	    if (((binaryinfo[9] & 0x08)  != 0) && (volt_in > ACLINEVOLTAGE))
		strcat (info[6].value, "TRIM ");	/* trim voltage */	
	    if ((binaryinfo[9] & 0x20) != 0)
		strcat (info[6].value, "OVER ");	/* overload */
	    if ((binaryinfo[10] & 0x02) != 0)
		strcat (info[6].value, "RB ");		/* replace batt */	

	    /* lose trailing space if present */
	    if (info[6].value[strlen(info[6].value)-1] == ' ')
		info[6].value[strlen(info[6].value)-1] = 0;
		
	    writeinfo(info);
	};
};

/* formerly in upscommon-addon.c */

/* set DTR and RTS lines on a serial port to supply a passive serial interface */
/*  here: DTR to 0 (-V), RTS to 1 (+V) */
void set_serialDTR0RTS1(void)
{
    // set DTR to low and RTS to high
    ioctl(upsfd, TIOCMBIC, &dtr_bit);
    ioctl(upsfd, TIOCMBIS, &rts_bit);
}

/* wait for an binary answer and get buflen bytes */
int recvbinary (char *buf, int buflen)
{
	unsigned char in;
	int ret, counter = 0, retval = 0;
	struct sigaction sa;
	sigset_t sigmask;

#ifdef DEBUG_UPSCOMMONADDON
        syslog (LOG_DEBUG, "start reading %d binary data bytes from ups", buflen);
#endif	

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (3);

        while (counter < buflen) {
#ifdef DEBUG_UPSCOMMONADDON
            syslog (LOG_DEBUG, "want to read [%2d] of %2d", counter +1 , buflen); 
#endif	
    	    ret = read (upsfd, &in, 1);
#ifdef DEBUG_UPSCOMMONADDON
	    if (ret == -1) {
		perror("read from serial");
	    };
#endif	
	    
	    if (ret > 0) {
		buf[counter] = in;
		counter ++;
#ifdef DEBUG_UPSCOMMONADDON
                syslog (LOG_DEBUG, "read [%2d]: 0x%02x", counter,  buflen, in); 
#endif	
		nolongertimeout();	   
	    }
	    else {
	        syslog (LOG_DEBUG, "error reading from serial device!");
		retval = -1;
		break;
	    }
	}
	
	alarm (0);
	signal (SIGALRM, SIG_IGN);
	
	if (retval == 0) {
	    syslog (LOG_DEBUG, "got all bytes from ups");
	}
	
        return (retval);
}

/* install given data directly in the data array */
void installinfodirect (int infotype, char *datastring)
{
	int	i, pos = 0;

	for (i = 0; i < INFOMAX; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0) {	/* not found, probably debugging? */
		syslog (LOG_ERR, "installinfodirect: can't find type %i\n", infotype);
		return;
	}

	strncpy(info[pos].value, datastring, sizeof(info[pos].value) - 1);
}

int main (int argc, char **argv)
{
	char	*portname;
	int	i;

	printf ("Network UPS Tools - UPS driver 0.04 for Trust or PowerCom-KingPro 425/625\n");

	if (argc != 2) {
		printf ("usage: %s <portname>       Example: %s /dev/ttyS0\n", 
			argv[0], argv[0]);
		exit (1);
	};

	droproot();

	openlog ("ups-trust425+625", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[1]); i >= 0; i--)
		if (argv[1][i] == '/') {
			portname = &argv[1][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[1]);
		exit (1);
	};

	snprintf (statefn, sizeof(statefn), "%s/ups-trust425+625-%s", STATEPATH,
	          portname);
		  
	open_serial (argv[1], B1200);
	
	set_serialDTR0RTS1();

	initinfo();

#ifndef DEBUG_UPSTRUST425625
	background();
#endif
	
	signal(SIGTERM, signalTERM);
	signal(SIGINT, signalINT);
	
        syslog(LOG_INFO, "Start reading information");

	while (signal_terminate == 0) {
	    updateinfo();
	    sleep (2);
	};
	
        syslog(LOG_INFO, "Terminated");
	return (0);
};
