/* upsset - CGI program to manage read/write variables

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include "upsfetch.h"
#include "version.h"
#include "cgilib.h"

	int	fd;
	char	monhost[256], *upsname, *host;

void parsearg (char *var, char *value)
{
	if (!strcmp(var, "host"))
		snprintf (monhost, sizeof(monhost), "%s", value);
}

void do_enum (char *varname)
{
	char	out[256], temp[256], *val, *sel, *ptr;

	snprintf (out, sizeof(out), "ENUM %s\n", varname);
	upssendraw (fd, out);

	upsreadraw (fd, temp, sizeof(temp));
	if (strncmp(temp, "ENUM", 4) != 0) {
		printf ("Bogus reply from server for %s\n", varname);
		return;
	}

	printf ("<SELECT NAME=\"%s\">\n", varname);

	upsreadraw (fd, temp, sizeof(temp));
	temp [strlen(temp) - 1] = 0;

	while (strcmp(temp, "END") != 0) {

		/* split into value and selected */
		val = strchr (temp, '"');
		val++;
		sel = strchr (val, ' ');
		if (sel)
			sel++;
		ptr = strchr (val, '"');
		val [ptr - val] = '\0';
			
		printf ("<OPTION VALUE=\"%s\" ", val);
			
		if ((sel != NULL) && (!strcmp(sel, "SELECTED")))
			printf ("SELECTED");

		printf (">%s</OPTION>\n", val);	
		upsreadraw (fd, temp, sizeof(temp));
		temp [strlen(temp) - 1] = 0;
	}
	printf ("</SELECT>\n");
}

void do_string (char *varname, int typelen)
{
	char	temp[256];

	getupsvarfd (fd, upsname, varname, temp, sizeof(temp));
	printf ("<INPUT TYPE=\"TEXT\" NAME=\"%s\" VALUE=\"%s\" SIZE=\"%i\">\n",
	        varname, temp, typelen);
}

int main (int argc, char **argv)
{
	char	*host, vars[256], temp[256], out[256], *v;
	char	type[16], *ptr;
	int	typelen;

	printf ("Content-type: text/html\n\n");

	extractcgiargs();

	if (!checkhost (monhost)) {
		printf ("Access to that host is not authorized\n");
		exit (1);
	}

	ptr = strstr (monhost, "@");
	if (ptr != NULL) {
		ptr[0] = 0;
		upsname = monhost;
		host = ptr + 1;
	}
	else {
		upsname = NULL;
		host = monhost;
	}

	/* TODO: user authentication before setting is allowed */

	fd = upsconnect (host);
	if (fd < 0) {
		printf ("Unable to connect to %s - %s\n", host,
		        upsstrerror(upserror));
		exit (1);
	}

	if (upsname != NULL) {
		snprintf (temp, sizeof(temp), "LISTRW %s\n", upsname);
		upssendraw (fd, temp);
	}
	else
		upssendraw (fd, "LISTRW\n");
	
	if (upsreadraw (fd, vars, sizeof(vars)) < 0) {
		printf ("Unable to get variable list - %s\n",
		        upsstrerror(upserror));
		exit (1);
	}

	printf ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"\n");
	printf ("	\"http://www.w3.org/TR/REC-html40/loose.dtd\">\n");
	printf ("<HTML>\n");
	printf ("<HEAD><TITLE>upsset: Settings on %s</TITLE></HEAD>\n", monhost);

	printf ("<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\">\n"); 
	printf ("<FORM ACTION=\"upsset.cgi\" METHOD=\"POST\">\n");

	printf ("<TABLE BGCOLOR=\"#50A0A0\" ALIGN=\"CENTER\">\n");
	printf ("<TR><TD><TABLE CELLPADDING=\"5\">\n");

	printf ("<TR><TH COLSPAN=2 BGCOLOR=\"#60B0B0\">\n");
	printf ("<FONT SIZE=\"+2\">Network UPS Tools upsset %s</FONT>\n", 
	         UPS_VERSION);
	printf ("</TH></TR>\n");

	vars [strlen(vars) - 1] = 0;

	v = strtok (vars, " ");

	/* skip over "@upsname" if using that mode */
	if (upsname != NULL)
		v = strtok (NULL, " ");

	v = strtok (NULL, " ");

	/* do a sanity check before starting into the columns */
	if (v == NULL) {
		printf ("<TR BGCOLOR=\"#60B0B0\">\n");
		printf ("<TD COLSPAN=2 ALIGN=\"CENTER\">No r/w variables supported on this UPS.</TD></TR>\n");
		printf ("</TABLE></TD></TR></TABLE></FORM>\n");
		exit (0);
	}

	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TH>Setting</TH>\n");
	printf ("<TH>Value</TH></TR>\n");

	while (v != NULL) {
		/* get description */
		snprintf (out, sizeof(out), "VARDESC %s\n", v);
		upssendraw (fd, out);
		upsreadraw (fd, temp, sizeof(temp));
		temp [strlen(temp) - 1] = 0;
		printf ("<TR BGCOLOR=\"#60B0B0\" ALIGN=\"CENTER\">\n");

		/* strip off leading/trailing quotes */
		ptr = strchr (temp, '"');
		if (ptr != NULL) {
			ptr++;
			*strchr(ptr, '"') = '\0';
		}

		printf ("<TD>%s</TD>\n", ptr);

		/* now get variable type */
		snprintf (out, sizeof(out), "VARTYPE %s\n", v);
		upssendraw (fd, out);
		upsreadraw (fd, temp, sizeof(temp));
		temp [strlen(temp) - 1] = 0;
		sscanf (temp, "%*s %s %i", type, &typelen); 

		printf ("<TD>\n");

		if (!strcmp(type, "ENUM"))
			do_enum (v);

		if (!strcmp(type, "STRING"))
			do_string (v, typelen);

		printf ("</TD></TR>\n");
		
		v = strtok (NULL, " ");
	}

	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TD COLSPAN=\"2\" ALIGN=\"CENTER\">\n");
	printf ("<INPUT TYPE=\"SUBMIT\" VALUE=\"Save changes\">\n");
	printf ("<INPUT TYPE=\"RESET\" VALUE=\"Reset\">\n");
	printf ("</TD></TR>\n");

	printf ("</TABLE></TD></TR></TABLE></FORM>\n");
	
	return (0);
}
