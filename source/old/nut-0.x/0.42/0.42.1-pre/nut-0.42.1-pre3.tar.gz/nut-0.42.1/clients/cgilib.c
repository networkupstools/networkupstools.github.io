/* cgilib - common routines for CGI programs

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cgilib.h"
#include "config.h"

void extractcgiargs()
{
	char	*query, *ptr, *eq, *varname, *value, *amp;

	query = getenv ("QUERY_STRING");
	if (query == NULL)
		return;		/* not run as a cgi script! */
	if (strlen(query) == 0)
		return;		/* no query string to parse! */

	/* varname=value&varname=value&varname=value ... */

	ptr = query;

	while (ptr) {
		varname = ptr;
		eq = strchr (varname, '=');
		if (!eq) {
			printf ("Broken string\n");
			exit (1);
		}
		
		*eq = '\0';
		value = eq + 1;
		amp = strchr (value, '&');
		if (amp) {
			ptr = amp + 1;
			*amp = '\0';
		}
		else
			ptr = NULL;
	
		parsearg (varname, value);
	}

	return;
}

int checkhost(char *check)
{
	FILE	*hostlist;
	char	fn[256], buf[256], addr[256];

	snprintf(fn, sizeof(fn), "%s/hosts.conf", CONFPATH);
	hostlist = fopen(fn, "r");

	if (hostlist == NULL)
		return 1;		/* default to allow */

	while (fgets (buf, sizeof(buf), hostlist)) 
		if (strncmp("MONITOR", buf, 7) == 0) {
			sscanf (buf, "%*s %s", addr);
			if (!strcmp (addr, check)) {
				fclose (hostlist);
				return 1;	/* allowed */
			}
		}

	fclose (hostlist);
	return 0;		/* denied */
}	
