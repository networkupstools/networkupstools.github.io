/* bestups.c - model specific routines for Best-UPS Fortress models

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

#define INFOMAX 16
#define ENDCHAR 13	/* replies end with CR */
#define UPSDELAY 5

	int	upsfd;
	int	shmok = 1;
	char	statefn[256], *modelname, *va;
	itype	*info;
extern	int	flag_timeoutfailure;
	float	lowvolt = 0, highvolt = 0, voltrange = 0;
	int	infomax = 16;

void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables - max possible */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", INFOMAX);

	/* now set up room for all future variables that are supported */
	info[1].type = INFO_MFR;
	info[2].type = INFO_MODEL;
	info[3].type = INFO_UTILITY;
	info[4].type = INFO_BATTPCT;
	info[5].type = INFO_STATUS;
	info[6].type = INFO_ACFREQ;
	info[7].type = INFO_LOADPCT;
	info[8].type = INFO_UPSTEMP;
}

	/* TODO: adapt to the standard upscommon open/send/recv calls */

void setup_serial()
{	
	struct	termio	tio;

	tio.c_iflag = IXON | IXOFF;
	tio.c_oflag = 0;
	tio.c_cflag = (B2400 | CS8 | CREAD | HUPCL | CLOCAL);
	tio.c_lflag = 0;
	tio.c_cc[VMIN] = 1;
	tio.c_cc[VTIME] = 0;

	if (ioctl(upsfd, TCSETA, &tio) == -1) {
		perror ("ioctl");
		exit (1);
	}
}

char readchar ()
{
	char	c;
	int	ret;

	ret = read (upsfd, &c, 1);

	if (ret > 0)
		return (c & 0x7f);
	else
		return 0;
}

int xsend (char *str)
{
	int	ret;

	while (*str) {
		ret = write (upsfd, str++, 1);
		if (ret == -1)
			return (-1);
	}

	return 0;
}

int xrecv (char *buf)
{
	char	ch, *p;

	p = buf;
	*p = '\0';

	while ((ch = readchar ())) {
		if (ch == 13) {
			*p = '\0';
			return 0;
		}
	
		*p++ = ch;
	}

	*p = '\0';
	return 0;
}

void ups_sync()
{
	char	buf[256];

	/* TODO: maxtries */

	printf ("Syncing with UPS: ");
	fflush (stdout);

	for (;;) {
		xsend ("\rQ1\r");
		printf (".");
		fflush (stdout);
		sleep (UPSDELAY);
		printf (".");
		fflush (stdout);
		xrecv (buf);
		printf (".");
		fflush (stdout);
		if (buf[0] == '(')
			break;			
	}

	printf (" done\n");
}

/* power down the attached load immediately */
void forceshutdown(char *port)
{
	char	temp[256], stat[32];

	syslog (LOG_INFO, "Initiating UPS shutdown\n");
	printf ("Initiating forced UPS shutdown!\n");

	upsfd = open(port, O_RDWR | O_NDELAY);
	if (upsfd == -1) {
		perror ("open");
		exit (1);
	}

	setup_serial();

	/* basic idea: find out line status and send appropriate command */

	printf ("Checking status: ");
	fflush (stdout);

	/* TODO: maxtries */
	for (;;) {
		xsend ("\rQ1\r");
		printf (".");
		fflush (stdout);
		sleep (UPSDELAY);
		printf (".");
		fflush (stdout);
		xrecv (temp);
		printf (".");
		fflush (stdout);
		if ((temp[0] == '(') && (strlen(temp) == 46))
			break;
	}

	printf (" done\n");

	sscanf (temp, "%*s %*s %*s %*s %*s %*s %*s %s", stat);

	/* on battery: send S01<cr>, ups will return by itself on utility */
	/* on line: send S01R0001<cr>, ups will cycle and return soon */

	xsend ("S01");

	if (stat[0] == '0') {			/* on line */
		printf ("On line, sending shutdown+return command...\n");
		xsend ("R0001");
	}
	else
		printf ("On battery, sending normal shutdown command...\n");

	xsend ("\r");	/* end sequence */

	printf ("Waiting for poweroff...\n");
	sleep (90);
	printf ("Hmm, did the shutdown fail?  Oh well...\n");
	exit (1);                               
}

void usage (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("Example: %s /dev/ttyS0\n", prog);
	exit (1);
}

void help (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("\n");
	printf ("-h       - display this help\n");
	printf ("-k       - force shutdown\n");
	printf ("<device> - /dev entry corresponding to UPS port\n");
}

void setmodel (char *abbr, char *va)
{
	if (!strcmp(abbr, "FOR")) {
		snprintf (info[1].value, sizeof(info[1].value), "Best Power");
		snprintf (info[2].value, sizeof(info[1].value), "Fortress %s", va);
		return;
	}

	snprintf (info[1].value, sizeof(info[1].value), "Unknown");
	snprintf (info[2].value, sizeof(info[1].value), "Unknown (%s) %s", 
	          abbr, va);

	return;
}

void ups_ident()
{
	char	buf[256], *ptr, *com;

	int	i;

	printf ("Identifying UPS: ");
	fflush (stdout);

	/* TODO: maxtries */
	for (;;) {
		xsend ("\r\rID\r");
		printf (".");
		fflush (stdout);
		sleep (UPSDELAY);
		printf (".");
		fflush (stdout);
		xrecv (buf);
		printf (".");
		fflush (stdout);
		if ((buf[0] != '\0') && (buf[0] != '(') &&
		    (strlen(buf) == 25))
			break;
	}

	printf (" done\n");

	modelname = va = NULL;

	/* FOR,750,120,120,20.0,27.6 */
	ptr = strdup(buf);

	for (i = 0; i < 6; i++) {
		com = strchr (ptr, ',');

		if (com)
			*com = '\0';

		switch (i) {
			case 0: modelname = strdup (ptr);
				break;
			case 1: va = strdup (ptr);
				break;
			case 4: lowvolt = atof (ptr);
				break;
			case 5: highvolt = atof (ptr);
				voltrange = highvolt - lowvolt;
				break;
			default:
				break;
		}
		ptr = com + 1;
	}
}

void ups_update ()
{
	char	utility[16], loadpct[16], acfreq[16], battvolt[16],
		upstemp[16], stat[16], buf[256];
	float	bvoltp;

	xsend ("\rQ1\r");     
	sleep (UPSDELAY); 
	xrecv (buf);

	if ((strlen(buf) < 46) || (buf[0] != '('))
		return;

	sscanf (buf, "%*c%s %*s %*s %s %s %s %s %s", utility, loadpct, 
	        acfreq, battvolt, upstemp, stat);
	
	snprintf (info[3].value, sizeof(info[3].value), "%s", utility);

	bvoltp = ((atof (battvolt) - lowvolt) / voltrange) * 100.0;

	if (bvoltp > 100.0)
		bvoltp = 100.0;

	snprintf (info[4].value, sizeof(info[4].value), "%02.1f", bvoltp);

	strcpy (info[5].value, "");

	if (stat[0] == '0')
		strcat (info[5].value, "OL ");		/* on line */
	else
		strcat (info[5].value, "OB ");		/* on battery */

	if (stat[1] == '1')
		strcat (info[5].value, "LB ");		/* low battery */

	/* lose trailing space if present */
	if (info[5].value[strlen(info[5].value)-1] == ' ')
		info[5].value[strlen(info[5].value)-1] = 0;

	snprintf (info[6].value, sizeof(info[6].value), "%s", acfreq);
	snprintf (info[7].value, sizeof(info[7].value), "%s", loadpct);
	snprintf (info[8].value, sizeof(info[8].value), "%s", upstemp);

	writeinfo(info);
}

int main (int argc, char **argv)
{
	char	*prog, *portname;
	int	i;

	printf ("Network UPS Tools - Best UPS driver 0.15 (%s)\n", UPS_VERSION);
	openlog ("bestups", LOG_PID, LOG_FACILITY);
	prog = argv[0];

	while ((i = getopt(argc, argv, "+hk:")) != EOF) {
		switch (i) {
			case 'k':
				forceshutdown(optarg);
				break;
			case 'h':
				help(prog);
				break;
			default:
				usage(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	if (argc != 1) {
		help (prog);
		exit (1);
	}

	droproot();

	portname = NULL;
	for (i = strlen(argv[0]); i >= 0; i--)
		if (argv[0][i] == '/') {
			portname = &argv[0][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[0]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/bestups-%s", STATEPATH,
	          portname);

	upsfd = open(argv[0], O_RDWR | O_NDELAY);
	if (upsfd == -1) {
		perror ("open");
		exit (1);
	}

	setup_serial();
	ups_sync();
	ups_ident();

	initinfo();
	createmsgq();	/* try to create IPC message queue */
	setmodel (modelname, va);

	printf ("Detected %s %s on %s\n", info[1].value, info[2].value, argv[0]);

	background();

	for (;;)
		ups_update();

	return 0;
}
