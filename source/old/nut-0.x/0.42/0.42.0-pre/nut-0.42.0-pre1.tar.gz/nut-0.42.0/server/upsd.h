/* upsd.h - support structures and other minor details

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

/* netvars[] - map text strings from the network to internal identifiers */

struct {
	char	*name;
	int	type;
	char	*desc;
}	netvars[] =
{
	{ "MFR",	INFO_MFR,	"Manufacturer"		},
	{ "MODEL",	INFO_MODEL,	"Model"			},
	{ "SERIAL",	INFO_SERIAL,	"Serial number"		},
	{ "UTILITY",	INFO_UTILITY,	"Utility voltage"	},
	{ "BATTPCT",	INFO_BATTPCT,	"Battery percentage"	},
	{ "STATUS",	INFO_STATUS,	"Status"		},
	{ "UPSTEMP",	INFO_UPSTEMP,	"UPS temperature"	},
	{ "ACFREQ",	INFO_ACFREQ,	"AC frequency"		},
	{ "LOADPCT",	INFO_LOADPCT,	"Load percentage"	},
	{ "LOWXFER", 	INFO_LOWXFER,	"Low transfer voltage"	},
	{ "HIGHXFER",	INFO_HIGHXFER,	"High transfer voltage"	},
	{ "AMBHUMID",	INFO_AMBHUMID,	"Ambient humidity"	},
	{ "AMBTEMP",	INFO_AMBTEMP,	"Ambient temperature"	},
	{ "CONTACTS",   INFO_CONTACTS,  "Dry contacts"		},
	{ "UPSIDENT",	INFO_UPSIDENT,	"UPS identification"	},
	{ NULL,		INFO_UNUSED, 	NULL			}
};

void do_sendver (struct sockaddr_in *dest, char *arg);
void do_sendans (struct sockaddr_in *dest, char *arg);
void do_sendhelp (struct sockaddr_in *dest, char *arg);
void do_listvars (struct sockaddr_in *dest, char *arg);
void do_logout (struct sockaddr_in *dest, char *arg);
void do_login (struct sockaddr_in *dest, char *arg);
void do_password (struct sockaddr_in *dest, char *arg);
void do_listrw (struct sockaddr_in *dest, char *arg);
void do_vartype (struct sockaddr_in *dest, char *arg);
void do_vardesc (struct sockaddr_in *dest, char *arg);
void do_enum (struct sockaddr_in *dest, char *arg);

/* netcmds[] - map net commands to functions */

struct {
	char	*name;
	void	(*func)(struct sockaddr_in *dest, char *arg);
}	netcmds[] =
{
	{ "VER",	do_sendver		},
	{ "REQ",	do_sendans		},
	{ "HELP",	do_sendhelp		},
	{ "LISTVARS",	do_listvars		},
	{ "LOGOUT", 	do_logout		},
	{ "LOGIN",	do_login		},
	{ "PASSWORD",	do_password		},
	{ "LISTRW",	do_listrw		},
	{ "VARTYPE",	do_vartype		},
	{ "VARDESC",	do_vardesc		},
	{ "ENUM",	do_enum			},
	{ NULL,		(void(*)())(NULL)	}
};
