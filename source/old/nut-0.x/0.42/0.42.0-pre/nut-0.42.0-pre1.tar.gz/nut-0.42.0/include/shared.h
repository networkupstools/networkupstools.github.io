/* shared.h - shared data structures for upsd and model-specific modules */

/* itype - holds info (variable name, variable value) */

/* size of the values stored within the array */
#define VALSIZE 32

/* used in an array and stored in shared memory or to state file */
typedef struct {
	int	type;
	char	value[VALSIZE];
	int	flags;			/* see FLAGS_* below 		*/
	int	auxdata;		/* length, # entries, enumtype	*/
}	itype;

/* these values are only used between processes on the same host... */

#define INFO_MEMBERS	0x0000		/* number of info entries 	*/
#define INFO_MFR	0x0001		/* manufacturer string		*/
#define INFO_MODEL	0x0002		/* model string			*/
#define INFO_SERIAL	0x0003		/* serial number		*/
#define INFO_UTILITY	0x0004		/* incoming utility voltage	*/
#define INFO_BATTPCT	0x0005		/* battery charge (percent)	*/
#define INFO_STATUS	0x0006		/* status (OL, OB, LB, etc.)	*/
#define INFO_UPSTEMP	0x0007		/* temperature (degrees C)	*/
#define INFO_ACFREQ	0x0008		/* AC frequency (Hz)		*/
#define INFO_LOADPCT	0x0009		/* load on UPS (percent)	*/
#define INFO_LOWXFER	0x000A		/* low transfer voltage		*/
#define INFO_HIGHXFER	0x000B		/* high transfer voltage	*/
#define INFO_AMBHUMID	0x000C		/* ambient humidity (percent)	*/
#define INFO_AMBTEMP	0x000D		/* ambient temperature (deg C)	*/
#define INFO_CONTACTS   0x000F		/* dry contacts                 */
#define INFO_UPSIDENT	0x0010		/* ups identification (string)  */

#define	INFO_SYSMASK	0xF000		/* mask for system level INFOs  */
#define INFO_ENUM	0xFFFC		/* holder for an ENUM value	*/
#define	INFO_MSGID	0xFFFD		/* message queue ID             */
#define INFO_SHMID	0xFFFE		/* shared memory struct ID      */
#define INFO_UNUSED	0xFFFF		/* this entry is not being used */

/* message queue identifiers */

#define UPSMSG_TOUPSD	0x1000		/* message to upsd from model   */
#define UPSMSG_TOMODEL	0x1001		/* message from upsd to model   */
#define UPSMSG_MAXLEN	128		/* maximum length permitted	*/

/* message queue struct commands */

#define UPSMSG_CMDMASK	0xA100		/* command mask			*/
#define UPSMSG_CMDSDD	0xA101		/* shut down load with delay    */
#define UPSMSG_CMDSET	0xA102		/* set variable to value	*/

#define UPSMSG_REPMASK	0xAE00		/* reply mask			*/
#define UPSMSG_REPOK	0xAE01		/* command completed OK		*/

#define UPSMSG_ERRMASK	0xAF00		/* error mask			*/
#define UPSMSG_ERRNI	0xAF01		/* error: cmd not implemented	*/
#define UPSMSG_ERRRO	0xAF02		/* error: read-only variable	*/
#define UPSMSG_ERRCF	0xAF03		/* error: command failed	*/

typedef struct {
	int	cmdtype;
	int	auxcmd;
	int	dlen;
	char	data;		/* up to dlen bytes long */
}	msgtype;

/* flags from the info array */
#define FLAG_RW		0x0001		/* variable is read/write	  */
#define FLAG_ENUM	0x0002		/* variable is an enumerated type */
#define FLAG_STRING	0x0004		/* variable is a string           */
