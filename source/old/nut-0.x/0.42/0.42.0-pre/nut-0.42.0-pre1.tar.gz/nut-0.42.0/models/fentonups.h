/* fentonups.h - model capability table

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

struct {
	char	*mtext;
	char	*desc;
	int	lowvolt;
	int	voltrange;
}	modeltab[] =
{
	{ "L280",	"PowerPal 280",		9.6,	2.4	},
	{ "L425",	"PowerPal 425",		9.6,	2.4	},	
	{ "L660",	"PowerPal 660",		19.6,	4.4	},
	{ "L1000",	"PowerPal 1000",	19.6,	4.4	},
	{ "L1400",	"PowerPal 1400",	29.4,	6.6	},
	{ NULL,		NULL,			0,	0	}
};
