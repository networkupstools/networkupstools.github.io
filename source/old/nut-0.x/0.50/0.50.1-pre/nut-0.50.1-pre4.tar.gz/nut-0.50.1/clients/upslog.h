/* upslog.h - table of functions for handling various logging functions */

void do_host(const char *arg);
void do_upshost(const char *arg);
void do_pid(const char *arg);
void do_time(const char *arg);
void do_var(const char *arg);
void do_etime(const char *arg);

struct {
	char	*name;
	void	(*func)(const char *arg);
}	logcmds[] =
{
	{ "HOST",	do_host			},
	{ "UPSHOST",	do_upshost		},
	{ "PID",	do_pid			},
	{ "TIME",	do_time			},
	{ "VAR",	do_var			},
	{ "ETIME",	do_etime		},
	{ NULL,		(void(*)())(NULL)	}
};
