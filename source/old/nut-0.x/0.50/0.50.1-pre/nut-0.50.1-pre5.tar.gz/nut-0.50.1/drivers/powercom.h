/*
 * powercom.h - defines for the newpowercom.c driver
 *
 * Read docs/powercom.txt for other models and manufactures
 *
 * $Id: - will be filled in on next CVS add/update $
 *
 * Copyrights:
 * (C) 2002 Simon Rozman <simon@rozman.net>
 *  Added support for Egys
 *
 * (C) 2001 Peter Bieringer <pb@bieringer.de>
 *  Porting old style "powercom" to new style "newpowercom", cleanup header file
 *
 * (C) 2000  Shaul Karl <shaulk@israsrv.net.il>
 *  Creating old style "powercom"
 *   Heavily based on
 *    ups-trust425+625.c - model specific routines for Trust UPS 425/625
 *    Copyright (C) 1999  Peter Bieringer <pb@bieringer.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Changes
 * 20011208/PB: add support for subtypes
 * 20020629/SR: add support for calc. parameters
 */

/* C-libary includes */
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <limits.h>

/* nut includes */
#include "timehead.h"
#include "shared-tables.h"

/* powercom defines */
enum subtype {
    POWERCOM_TRUST = 0U,
    POWERCOM_KP625AP,
    POWERCOM_EGYS,
    NUM_OF_SUBTYPES
};

enum general {
       	SEC_FOR_POWERKILL         = 10U,
	NUM_OF_BYTES_FROM_UPS_MAX = 16U,
};

/* flow control type */
enum flow_control {
	FLOW_CONTROL_NONE     = 0,
	FLOW_CONTROL_DTR0RTS1 = 1,
};

/* values for sending to UPS */
enum commands {
	SEND_DATA    = '\x01',
	BATTERY_TEST = '\x03',
	SHUTDOWN     = '\xbc',
};

/* location of data in received string */
enum data {
	LOAD_LEVEL  = 0U,
       	BAT_LEVEL   = 1U,
       	IN_AC_VOLT  = 2U,
       	OUT_AC_VOLT = 3U,
	IN_AC_FREQ  = 4U,
        OUT_AC_FREQ = 6U,
};

/* status bits */
enum status {
	SUMMARY       = 0U,
       	MAINS_FAILURE = 1U,
       	LOW_BAT       = 2U, 
	BAD_BAT       = 2U,
       	TEST          = 4U,
	AVR_ON        = 8U,
       	OVERLOAD      = 32U,
       	OFF           = 128U,
	STATUS_A      = 9U,
	STATUS_B      = 10U,
};

/* supported subtypes */
char* subtypes_name[NUM_OF_SUBTYPES] = {
	"Trust",
	"KP625AP",
	"Egys"
};

/* information array about subtypes */
unsigned int subtypes_num_of_bytes[NUM_OF_SUBTYPES] = {
	11U,   /* Trust */
	16U,   /* KP625AP */
	16U,   /* Egys */
};

unsigned int subtypes_flow_control[NUM_OF_SUBTYPES] = {
	FLOW_CONTROL_DTR0RTS1,           /* Trust */
	FLOW_CONTROL_DTR0RTS1,           /* KP625AP */
	FLOW_CONTROL_NONE,               /* Egys */
};

/* parameters to calculate input and output freq., one pair for each
 * subtype:
 *  Each pair defines parameters for 1/(A*x+B) to calculate freq.
 *  from raw data
 */
float subtypes_freq[NUM_OF_SUBTYPES][2] = {
	{  0.00020997, 0.00020928 },	/* Trust */
	{  0.00020997, 0.00020928 },	/* KP625AP */
	{  0.00020997, 0.00020928 },	/* Egys */
};

/* parameters to calculate load %, two pairs for each subtype:
 *  First pair defines the parameters for A*x+B to calculate load
 *  from raw data when offline and the second pair is used when
 *  online
 */
float subtypes_loadpct[NUM_OF_SUBTYPES][4] = {
	{  6.1343, -0.3808,  4.3110,  0.1811 },	/* Trust */
	{  6.1343, -0.3808,  4.3110,  0.1811 },	/* KP625AP */
	{  6.1343, -0.3808,  1.3333,  0.6667 },	/* Egys */
};

/* parameters to calculate battery %, five parameters for each subtype:
 *  First three params defines the parameters for A*x+B*y+C to calculate
 *  battery % (x is raw data, y is load %) when offline.
 *  Fourth and fifth parameters are used to calculate D*y+E when online.
 */
float subtypes_battpct[NUM_OF_SUBTYPES][5] = {
	{  5.0000,  0.3268,  -825.00,  4.5639, -835.82 },	/* Trust */
	{  5.0000,  0.3268,  -825.00,  4.5639, -835.82 },	/* KP625AP */
	{  5.0000,  0.3268,  -825.00,  2.2105, -355.37 },	/* Egys */
};

/* parameters to calculate utility and output voltage, two pairs for
 * each subtype:
 *  First pair defines the parameters for A*x+B to calculate utility
 *  from raw data when line voltage is >=220 and the second pair
 *  is used otherwise.
 */
float subtypes_voltage[NUM_OF_SUBTYPES][4] = {
	{  1.9216, -0.0977,  0.9545,  0.0000 },	/* Trust */
	{  1.9216, -0.0977,  0.9545,  0.0000 },	/* KP625AP */
	{  1.9216, -0.0977,  0.9545,  0.0000 },	/* Egys */
};

