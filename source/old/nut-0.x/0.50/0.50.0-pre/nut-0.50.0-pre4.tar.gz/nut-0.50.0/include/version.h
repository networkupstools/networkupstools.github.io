#define UPS_VERSION "0.50.0-pre4"
