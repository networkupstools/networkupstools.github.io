/* upsd.c - watches ups state files and answers queries 

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "shared.h"
#include "upsd.h"
#include "config.h"

char	*monitorfn[10];
itype	*iptr[10];			
int	upsnum = 0;		/* number of UPS files being monitored */
int	udpfd, udpport = UDPPORT;

/* load data from state file for ups # <unum> */
void updateups (int unum)
{
	int	stfd, ret;

	if (monitorfn[unum] == NULL)	/* sanity check */
		return;

	stfd = open (monitorfn[unum], O_RDONLY);
	if (stfd < 0) {
		printf ("open %s: %s\n", monitorfn[unum], strerror(errno));
		return;
	}

	ret = read (stfd, iptr[unum], sizeof(itype) * atoi(iptr[unum][0].value));
	close (stfd);
}

/* start monitoring a new UPS with a given state file */ 
void addups (char *statfn)
{
	int	ufd, ret;
	itype	info;

	upsnum++;

	ufd = open (statfn, O_RDONLY);
	if (ufd < 0) {
		printf ("open %s: %s\n", statfn, strerror(errno));
		upsnum--;
		return;
	}

	ret = read (ufd, &info, sizeof(itype));
	close (ufd);

	monitorfn[upsnum] = strdup(statfn);
	iptr[upsnum] = calloc (atoi(info.value), sizeof(itype));

	printf ("Adding new UPS as #%i from %s with %s variables\n",
		upsnum, monitorfn[upsnum], info.value);

	if (info.type == INFO_SHMID) {
		printf ("Sorry, shared memory mode not supported yet!\n");
		upsnum--;
		return;
	}

	if (info.type != INFO_MEMBERS) {
		printf ("This state file doesn't start with INFO_MEMBERS!\n");
		upsnum--;
		return;
	}

	/* store length info for subsequent reads */
	strcpy (iptr[upsnum][0].value, info.value);

	/* get initial info for this unit */
	updateups (upsnum);
}	

void setupudp()
{
	struct	sockaddr_in	recv;

	if ((udpfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror ("Can't create socket");
		exit (1);
	}

	bzero ((char *) &recv, sizeof(recv));
	recv.sin_family = AF_INET;
	recv.sin_port = htons(udpport);

	if (bind(udpfd, (struct sockaddr *) &recv, sizeof(recv)) < 0) {
		perror ("Can't bind to socket");
		exit (1);
	}

	return;
}

void sendback (struct sockaddr_in *dest, char *sendbuf, int sendlen)
{
	int	res;

	res = sendto (udpfd, sendbuf, sendlen, 0, (struct sockaddr *) dest,
	      sizeof (struct sockaddr));

	return;
}

char *cmdname (int cmdnum)
{
	int	i;
	char	logbuf[256];

	for (i = 0; netvars[i].name != NULL; i++)
		if (netvars[i].type == cmdnum)
			return (netvars[i].name);

	snprintf (logbuf, sizeof(logbuf), "Unknown variable type 0x%04x", cmdnum);
	syslog (LOG_INFO, logbuf);

	return (strdup("UNKNOWN"));
}

void sendans (struct sockaddr_in *dest, char *varname)
{
	int	i, type = 0;
	char	ans[256];

/*	printf ("Sending value of %s to %s\n", varname, inet_ntoa(dest->sin_addr)); */

	for (i = 0; netvars[i].name != NULL; i++)
		if (!strcasecmp(netvars[i].name, varname))
			type = netvars[i].type;
	
	/* type wasn't resolved in the netvars[] array */
	if (type == 0) {
		snprintf (ans, sizeof(ans), "ANS %s UNKNOWN\n", varname);
		sendback (dest, ans, strlen(ans));
		return;
	}

	/* stock reply - overwritten if an answer is found */
	snprintf (ans, sizeof(ans), "ANS %s NOT-SUPPORTED\n", varname);

	/* TODO: support more than one UPS (iptr[1] -> iptr[unum]) */
	for (i = 1; i < atoi(iptr[1][0].value); i++) 
		if (iptr[1][i].type == type) {
			snprintf (ans, sizeof(ans), "ANS %s %s\n", varname,
			          iptr[1][i].value);
			break;
		}

	sendback (dest, ans, strlen(ans));
}

void listvars (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];
	int	i;

	/* TODO: multiple ups support (iptr[1] -> iptr[upsnum]) */
	snprintf (ans, sizeof(ans), "VARS");
	for (i = 1; i < atoi(iptr[1][0].value); i++)
		snprintf (ans, sizeof(ans), "%s %s", ans,
		          cmdname(iptr[1][i].type));

	snprintf (ans, sizeof(ans), "%s\n", ans);
	sendback (dest, ans, strlen(ans));
}

void sendver (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];

	snprintf (ans, sizeof(ans),
	          "Smart UPS Tools upsd %s - rkroll@exploits.org\n", VERSION);
	sendback (dest, ans, strlen(ans));
}

void sendhelp (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];

	snprintf (ans, sizeof(ans), "Commands: LISTVARS, REQ <var>, VER, HELP\n");
	sendback (dest, ans, strlen(ans));
}

void parse (int len, char *buf, struct sockaddr_in *from)
{
	int	res, i;
	char	cmd[256], arg2[256], ans[256];

	bzero (cmd, sizeof(cmd));
	bzero (arg2, sizeof(arg2));
	res = sscanf (buf, "%s %s", cmd, arg2);

	for (i = 0; netcmds[i].name != NULL; i++) {
		if (!strcasecmp(netcmds[i].name, cmd)) {
			netcmds[i].func(from, arg2); 
			return;
		}
	}

	snprintf (ans, sizeof(ans), "Unknown command\n");
	sendback (from, ans, strlen(ans));
}

void mainloop (void)
{
	fd_set	rfds;
	struct	timeval	tv;
	struct	sockaddr_in from;
	int	res, fromlen, i;
	char	buf[256];

	FD_ZERO (&rfds);
	FD_SET (udpfd, &rfds);
	
	tv.tv_sec = 2;
	tv.tv_usec = 0;
	
	res = select (udpfd+1, (void *) &rfds, (void *) NULL,
		     (void *) NULL, &tv);

	if ((res) && (FD_ISSET (udpfd, &rfds))) {
		fromlen = sizeof(from);
		bzero (buf, sizeof(buf));
		res = recvfrom (udpfd, buf, sizeof(buf), 0, 
		               (struct sockaddr *) &from, &fromlen);
		parse (res, buf, &from);
	}

	for (i = 1; i <= upsnum; i++)
		updateups (i);
}

void background()
{
	int	pid;
	
	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */

	syslog (LOG_INFO, "Startup successful");
}

void droproot ()
{
	setgid(RUN_AS_GID);

	if (getuid() == 0)
		if (setuid(RUN_AS_UID) == -1) {
			perror ("setuid");
			exit (1);
		}
}

int main (int argc, char **argv)
{
	setupudp();

	/* TODO: config file */
	droproot();		

	if (argc != 2) {
		printf ("usage: %s <path to state file>\n", argv[0]);
		exit (1);
	}

 	addups (argv[1]);

	openlog ("upsd", LOG_PID, LOG_INFO);
 	background();

	for (;;)
		mainloop();

	return (0);	
}
