/* upscommon.h - prototypes for upscommon.c

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

/* called by alarm signal when the port open fails */
void openfail();

/* try to open the port at a given speed */
void open_serial(char *port, speed_t speed);

/* put a notice in the syslog */
void notice (char *msg);

/* put a fatal in the syslog and quit */
void fatal (char *msg);

/* alarm signal handler for when serial reads time out */
void timeout();

/* receive up to buflen bytes from the ups into buf */
int recv (char *buf, int buflen);

/* send a byte to the ups */
int send (char data);

/* install the data that the ups returns for 'reqchar' in the info
   array position that has type infotype */
void installinfo (int infotype, char reqchar);

/* return the data in the info array with type infotype */
char *getdata (int infotype);

/* write data to state file - effectively a no-op for shared memory mode */
void writeinfo (int initial);

/* put the program into the background - become a daemon */
void background();

/* give up root privs if necessary */
void droproot();
