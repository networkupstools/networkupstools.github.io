/* config.h - shared configuration details */

/* defaults are usually good, but compatibility is the name of the game.. */

/* state files created by the model-specific programs go here */
#define STATEPATH "/var/state/ups"

/* port number used for network communications */
#define UDPPORT 3305

/* the UID/GID values may need to be changed for other systems */

/* userid to run as instead of root - nobody is usually good */
#define RUN_AS_UID 65534

/* groupid to run as instead of root - nogroup is usually good */
#define RUN_AS_GID -2

/* logging facility for syslog */
#define LOG_FACILITY LOG_LOCAL7 

/* serial locking defines - configure will figure this out some day */

#ifdef __FreeBSD__
#define LOCK_WITH_UULOCK
#else
#define LOCK_WITH_FLOCK
#endif

/* not a config item really, but this is a convenient place */
#define VERSION "0.40.0-pre3"
