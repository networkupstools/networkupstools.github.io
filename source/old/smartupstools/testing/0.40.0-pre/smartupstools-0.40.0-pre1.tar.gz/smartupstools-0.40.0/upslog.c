/* upslog - log ups values to a file for later collection and analysis

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "upsfetch.h"
#include "config.h"

/* TODO: configurable list of variables to log */

int main(int argc, char *argv[])
{
	char	monhost[128], logfile[128], timestr[256];
	int	interval, res;
	time_t	tod;
	FILE	*log;
	char	battpct[16], utility[16], loadpct[16], status[16], upstemp[16],
		acfreq[16];

	if (argc != 4) {
		printf ("usage: %s <host> <logfile> <interval>\n", argv[0]);
		exit (0);
	}	

	strncpy (monhost, argv[1], sizeof (monhost));
	strncpy (logfile, argv[2], sizeof(logfile));
	interval = atoi (argv[3]);

	printf ("Smart UPS Tools upslog %s\n", VERSION);
	printf ("logging status of %s to %s (%is intervals)\n", 
		monhost, logfile, interval);

	log = fopen (logfile, "a");
	
	if (log == NULL) {
		perror ("unable to fopen log file");
		exit (0);
	}

	while (1) {
		time (&tod);
		strftime (timestr, sizeof(timestr), "%Y%m%d %H%M%S",
		          localtime(&tod));

		res = 0;
		res += getupsvar (monhost, "battpct", battpct, sizeof(battpct));
		res += getupsvar (monhost, "utility", utility, sizeof(utility));
		res += getupsvar (monhost, "loadpct", loadpct, sizeof(loadpct));
		res += getupsvar (monhost, "status", status, sizeof(status));
		res += getupsvar (monhost, "upstemp", upstemp, sizeof(upstemp));
		res += getupsvar (monhost, "acfreq", acfreq, sizeof(acfreq));

		if (res == 6) {		/* only log if all values OK */
			fprintf (log, "%s %s %s %s [%s] %s %s\n", timestr, 
				 battpct, utility, loadpct, status, upstemp, 
			         acfreq);

			fflush (log);
		}

		sleep (interval);
	}

	/* notreached */

	return (1);
}
