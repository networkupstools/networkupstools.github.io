/* upsmon - monitor power status over the 'net (talks to upsd via UDP)

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "upsfetch.h"
#include "config.h"

#define SLEEPDELAY	5		/* poll the ups every n seconds */
#define ALERTTIME	30		/* after this many seconds on battery,
					   do something about it */

	char	*shutdowncmd = NULL;
	int	online = 1, onbatt = 0, lowbatt = 0, upsresp = -1; 

void wall(char *text, int fromshutdown);

void notify(char *notice)
{
	syslog (LOG_NOTICE, notice);
	wall (notice, 1);
}

void heardups()
{
	if (upsresp == -1) {	/* ups is there, first time */
		upsresp = 0;
		syslog (LOG_INFO, "Communication with UPS established");
	}

	if (upsresp == 1) {	/* ups is back */
		upsresp = 0;
		syslog (LOG_INFO, "Communication with UPS re-established");
	}
}

void upsgone()
{
	if (upsresp == 0) {  /* ups isn't there, first time */
		syslog (LOG_INFO, "Communication with UPS lost");
		upsresp = 1;
	}
}

void upsonbatt()
{
	if (onbatt == 0) {
		notify ("UPS is on battery\n");
		onbatt = 1;
		online = 0;
	}

	/* TODO: track on-batt time and act on extended outages */
}

void upsonline()
{
	if (online == 0) {
		notify ("UPS back on line power\n");
		online = 1;
		onbatt = 0;
	}
}

void upslowbatt()
{
	/* critical only if on battery + low battery */
	if (onbatt == 0)
		return;

	syslog (LOG_CRIT, "Low battery - Executing automatic power-fail shutdown");
	wall ("Low battery - executing automatic power-fail shutdown\n", 1);

	if (getuid() != 0) {
		syslog (LOG_ALERT, "Not root, unable to shutdown system");
		exit (1);
	}

	notify ("Auto logout and shutdown in 15 seconds!\n");
	sleep (15);

	/* TODO: put real logic here ...

	1. send <notify message>
	2. wait <num> seconds
	3. log out from upsd
	4. execute <shutdowncmd> 

	*/
	
	system (shutdowncmd);
	exit (1);
}

void background()
{
	int	pid;
	
	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */

	syslog (LOG_INFO, "Startup successful");
}

/* return everything to the end of the line in a new buffer */
char *dynchar (char *data)
{
	char	*temp;

	temp = calloc (strlen(data), 1);
	strncpy (temp, data, strlen(data) - 1);
	return (temp);
}

void loadconfig (void)
{
	char	cfn[256], buf[256];
	FILE	*conf;

	snprintf (cfn, sizeof(cfn), "%s/etc/upsmon.conf", BASEPATH);

	conf = fopen(cfn, "r");
	if (conf == NULL) {
		printf ("Can't open %s/etc/upsmon.conf: %s\n", BASEPATH, 
		        strerror(errno));
		exit (1);
	}

	while (fgets(buf, sizeof(buf), conf)) {
		if (!strncmp(buf, "SHUTDOWNCMD", 11)) 
			shutdowncmd = dynchar (&buf[13]);
	}	

	fclose (conf);
}

int main(int argc, char *argv[])  
{
	char	monhost[256];
	char	status[256];
	char	*stat;

	printf ("Smart UPS Tools upsmon %s\n", VERSION);

	if (argc != 2) {
		printf ("Usage: %s <host to monitor>     Example: %s 10.2.254.1\n", argv[0], argv[0]);
		exit (1);
	}

	loadconfig();

	if (shutdowncmd == NULL)
		printf ("Warning: no shutdown command defined!\n");

	/* TODO: config file - override stock messages */

	strncpy (monhost, argv[1], sizeof(monhost) - 1);

	openlog ("upsmon", LOG_PID, LOG_INFO);
	syslog (LOG_INFO, "Monitoring UPS on %s", monhost);
	printf ("Monitoring UPS on %s\n", monhost);

	background();
	
	while (1) {
		if (getupsvar(monhost, "status", status, sizeof(status)) >= 0) {
			heardups();

			stat = strtok (status, " ");
			while (stat != NULL) {
				if (!strcasecmp(stat, "OL"))
					upsonline();
				if (!strcasecmp(stat, "OB"))
					upsonbatt();
				if (!strcasecmp(stat, "LB"))
					upslowbatt();
				stat = strtok(NULL, " ");
			} 
		}
		else {	/* fetch failed */
			upsgone();
		}
		sleep (SLEEPDELAY);
	}

	return (1);
}
