/* ups-trust425+625.c - model specific routines for Trust UPS 425/625
      also known as PowerCom King Pro 425/625 Smart-UPS units

   Copyright (C) 1999  Peter Bieringer <pb@bieringer.de>
     
   based on 
    smartups.c - model specific routines for APC Smart-UPS units
    Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   some hints also taken from
    backups.c - model specific routines for APC Back-UPS units
    Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>


   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

/* Here you can define extended syslog debugging and "do not go in background" mode */
/* #define DEBUG_UPSTRUST425625 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <time.h>
#include <limits.h>

#include "ups-trust425+625.h"
#include "shared.h"
#include "config.h"
#include "upscommon.h"

	int	upsfd;
	char	statefn[256];
	itype	info[INFOMAX];

#include "upscommon-addon.h"

unsigned char binaryinfo[NUMRECEIVEDBYTES];
time_t timelastvalid;

static int signal_terminate = 0;

static int counter_fail = 0;
static int counter_valid = 0;
static int flag_reconnect = 0;
static int flag_startup = 1;

/* some conversion functions for the binary field */

/* Binary to AC frequency (input and output) */
float ups_bin2freq(int binary) {
    // constants of cycle time
    static const float m = 0.00020997;
    static const float d = 0.00020928;
    float result;
    
    result = 1.0 / (binary * m + d);
    return(result);
};

/* Binary to LoadLevel */
float ups_bin2load(int binary) {
    static const float m = 4.311;
    static const float d = 0.1811;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to BatteryLevel */
float ups_bin2battlvl(int binary) {
    static const float m = 4.5639;
    static const float d = -835.82;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to Voltage (input and output) in OnLine state */
float ups_bin2volt(int binary) {
    static const float m = 1.9216;
    static const float d = -0.0977;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* Binary to Voltage (output only) in OnLine state */
float ups_bin2voltbatt(int binary) {
    static const float m = -4.00349;
    static const float d = 296.7242;
    float result;
    
    result = binary * m + d;
    return(result);
};

/* signals */
void signalTERM()
{
    syslog(LOG_WARNING, "Got signal TERM, so terminating");
    signal_terminate = 1;
    return;
};

void signalINT()
{
    syslog(LOG_WARNING, "Got signal INT, so terminating");
    signal_terminate = 1;
    return;
};


void signalHUP()
{
    syslog(LOG_WARNING, "Got signal HUP, so reset read failure counter");
    counter_fail = 0;
    return;
};


/* init information structure */
void initinfo (void)
{
	int	i;

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables (put in 10 for 0-9, etc) */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", 12);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;
	snprintf (info[1].value, sizeof(info[1].value), "Trust/PowerCom");

	info[2].type = INFO_MODEL;
	snprintf (info[2].value, sizeof(info[2].value), "425/625 (KingPro)");

	/* now set up room for all future variables that are supported */
	info[4].type = INFO_UTILITY;
	info[5].type = INFO_BATTPCT;
	info[6].type = INFO_STATUS;
	info[8].type = INFO_ACFREQ;
	info[9].type = INFO_LOADPCT;
}

/* get binary data from the UPSs */
/*  return value:  0x00: ok
		   0x10: primitive check failed	    
*/
int getbinarydata(void)
{
    int status, i;
    unsigned char temp[NUMRECEIVEDBYTES];
    
    syslog (LOG_DEBUG, "Send info request to ups");
    
    send (REQ_BINARYDATA);

    syslog (LOG_DEBUG, "Read info from ups: start");
    
    status = recvbinary (temp, NUMRECEIVEDBYTES);

    if (status == 0) {
        syslog (LOG_DEBUG, "Read info from ups: successful");
	/* some primitive checks */
	if ((temp[5] != 0) || (temp[7] != 0) || (temp[8] != 0)) {
	    /* looks like a transfer error in serial data communication */
	    syslog (LOG_WARNING, "Serial data from ups was invalid!");
	    return (0x10);
	}
	/* copy array */
	for (i = 0; i < NUMRECEIVEDBYTES; i++) {
	    binaryinfo[i] = temp[i];
	}
    }
    else
    {
#ifdef DEBUG_UPSTRUST425625
	syslog (LOG_WARNING, "Read info from ups: not successful");
#endif
    }
    return(status);
}



/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256];
	float	volt_in, acfreq_in, batt_lev, load_lev;
	int 	status;
	
	status = getbinarydata();
	
	if (status == 0) {
	    if ((counter_valid == 1) && (flag_startup == 1)) {
		syslog (LOG_NOTICE, "Got a successful read, connection established");
		flag_startup = 0;
	    }
	
	    if (counter_fail > 0) {
		syslog (LOG_NOTICE, "After %d unsuccessfull reads now a successful one", counter_fail);
		flag_reconnect = 1;
	    }
	    /* reset counter_fail */	    
	    counter_fail = 0;
	    
	    if ((counter_valid == 2) && (flag_reconnect == 1)) {
		syslog (LOG_NOTICE, "Next successful read, reconnection established");
		flag_reconnect = 0;
	    }
	    
	    if (counter_valid < INT_MAX) {
		counter_valid++;
	    }
	
	    timelastvalid = time(NULL);
	
	    volt_in = ups_bin2volt(binaryinfo[2]);
	    batt_lev = ups_bin2battlvl(binaryinfo[1]);
	    acfreq_in = ups_bin2freq(binaryinfo[4]);
	    load_lev = ups_bin2load(binaryinfo[0]);

	    if (volt_in < ACFREQ_ZEROTH) {
		acfreq_in = 0;
	    }
	
    	    sprintf(temp, "%03.1f", volt_in);
	    installinfodirect (INFO_UTILITY, temp);

    	    sprintf(temp, "%03.1f", batt_lev);
	    installinfodirect (INFO_BATTPCT, temp);
	
    	    sprintf(temp, "%02.2f", acfreq_in);
	    installinfodirect (INFO_ACFREQ, temp);

    	    sprintf(temp, "%03.1f", load_lev);
	    installinfodirect (INFO_LOADPCT, temp);
	
	    strcpy (info[6].value, "");
	    if ((binaryinfo[9] & 0x03) == 0)
		strcat (info[6].value, "OL ");		/* on line */
	    if (binaryinfo[9] & 1)
		strcat (info[6].value, "OB ");		/* on battery */
	    if (binaryinfo[9] & 20)
		strcat (info[6].value, "OVER ");	/* overload */
	    if ((binaryinfo[9] & 3) == 3)
		strcat (info[6].value, "LB ");		/* low battery */
	    if (binaryinfo[10] & 4)
		strcat (info[6].value, "RB ");		/* replace batt */	
	    if ((binaryinfo[10] & 8) && (volt_in < ACLINEVOLTAGE))
		strcat (info[6].value, "BOOST ");	/* boost voltage */	
	    if ((binaryinfo[10] & 8) && (volt_in > ACLINEVOLTAGE))
		strcat (info[6].value, "TRIM ");	/* trim voltage */	

	    /* lose trailing space if present */
	    if (info[6].value[strlen(info[6].value)-1] == ' ')
		info[6].value[strlen(info[6].value)-1] = 0;
		
	    writeinfo(0);
	}
	else
	{
	    counter_valid = 0;
	    
	    if (counter_fail < INT_MAX) {
		counter_fail++;
	    }
	    else {
		syslog (LOG_WARNING, "counter for unsuccessfull reads at its limit, stop counting!");
	    }
	    
	    /* after 10 tries, approximatly 10 * 3 = 30 seconds */
	    if (counter_fail == 10) {
		syslog (LOG_WARNING, "10 unsuccessfull reads, wait additional 10 sec each time");
	    }
	    if (counter_fail > 10) {
		sleep(10); /* sleep additional 10 s */
	    }
	    
	    /* after 22 tries, approximatly 10 * 3 + 12 * (10 + 3) = 180 sec = 3 min */
	    if (counter_fail == 22) {
		syslog (LOG_WARNING, "22 unsuccessfull reads, wait additional 60 sec each time");
	    }
	    if (counter_fail > 22) {
		sleep(60); /* sleep additional 60 s */
	    }
	    
	    /* after 28 tries, approximatly 10 * 3 + 12 * (10 + 3) + 6 * (10 + 3 + 60) = 600 sec = 10 min */
	    if (counter_fail == 28) {
		syslog (LOG_WARNING, "28 unsuccessfull reads, wait additional 10 min each time");
	    }
	    if (counter_fail > 28) {
		sleep(600); /* sleep additional 10 min */
	    }
	
	};
};


int main (int argc, char **argv)
{
	char	*portname;
	int	i;

	printf ("Smart UPS Tools - UPS driver 0.04 for Trust or PowerCom-KingPro 425/625\n");

	if (argc != 2) {
		printf ("usage: %s <portname>       Example: %s /dev/ttyS0\n", 
			argv[0], argv[0]);
		exit (1);
	};

	droproot();

	openlog ("ups-trust425+625", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[1]); i >= 0; i--)
		if (argv[1][i] == '/') {
			portname = &argv[1][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[1]);
		exit (1);
	};

	snprintf (statefn, sizeof(statefn), "%s/ups-trust425+625-%s", STATEPATH,
	          portname);
		  
	open_serial (argv[1], B1200);
	
	set_serialDTR0RTS1();

	initinfo();

#ifndef DEBUG_UPSTRUST425625
	background();
#endif
	
	signal(SIGTERM, signalTERM);
	signal(SIGINT, signalINT);
	signal(SIGHUP, signalHUP);
	
        syslog(LOG_INFO, "Starting...");

	while (signal_terminate == 0) {
	    updateinfo();
	    sleep (2);
	};
	
        syslog(LOG_INFO, "Terminated");
	return (0);
};
