/* upsfetch - library for UPS communications from client programs

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/socket.h>
#include "config.h"

	int	upserror, syserrno;

#define UNKNOWN		0x1000
#define NOSUCHVAR 	0x1001
#define NOSUCHHOST	0x1002
#define SENDFAILURE	0x1003
#define RECVFAILURE	0x1004
#define SOCKFAILURE	0x1005
#define BINDFAILURE	0x1006
#define RECVTIMEOUT	0x1007
#define	NOCOMM1		0x1008

char *upsstrerror (int errnum)
{
	char	buf[256];

	switch (errnum) {
		case NOSUCHVAR: 
			return (strdup("No such variable"));
			break;
		case NOSUCHHOST:
			return (strdup("No such host"));
			break;
		case SENDFAILURE:
			snprintf (buf, sizeof(buf), "Send failure: %s",
			         strerror(syserrno));
			return (strdup(buf));
			break;
		case RECVFAILURE:
			snprintf (buf, sizeof(buf), "Receive failure: %s",
			         strerror(syserrno));
			return (strdup(buf));
			break;
		case SOCKFAILURE:
			snprintf (buf, sizeof(buf), "Socket failure: %s",
			         strerror(syserrno));
			return (strdup(buf));
			break;
		case BINDFAILURE:
			snprintf (buf, sizeof(buf), "bind failure: %s",
			         strerror(syserrno));
			return (strdup(buf));
			break;
		case RECVTIMEOUT:
			return (strdup("Receive timeout"));
			break;
		case NOCOMM1:
			return (strdup("Data source is stale"));
			break;
		default:
			return (strdup("Unknown error"));
			break;
	}

	/* notreached */
	return (NULL);
}

/* send <req> to <host> and put the answer in <buf> */

int fetch (char *host, char *req, char *buf, int buflen)
{
	int	res, udpport = UDPPORT, fd, fromlen;
	struct	sockaddr_in xmit, dest, from;
	struct	hostent *serv;
	char	sbuf[512];
	fd_set	rfd;
	struct	timeval tv;

	upserror = UNKNOWN;

	if ((serv = gethostbyname(host)) == (struct hostent *) NULL) {
		upserror = NOSUCHHOST;
		return (-1);
	}

	fd = socket (AF_INET, SOCK_DGRAM, 0);
	if (fd < 0) {
		upserror = SOCKFAILURE;
		syserrno = errno;
		return (-1);
	}

	bzero ((char *) &xmit, sizeof(xmit));
	xmit.sin_family = AF_INET;

	res = bind (fd, (struct sockaddr *) &xmit, sizeof(xmit));
	if (res < 0) {
		upserror = BINDFAILURE;
		syserrno = errno;
		close (fd);
		return (-1);
	}

	bzero ((char *) &dest, sizeof(dest));
	(void) bcopy ((char *) serv->h_addr, (char *) &dest.sin_addr,
	              serv->h_length);
	dest.sin_family = AF_INET;
	dest.sin_port = htons(udpport);

	snprintf (sbuf, sizeof(sbuf), "%s", req);
	res = sendto (fd, sbuf, strlen(sbuf), 0, 
	             (struct sockaddr *) &dest, sizeof(dest));

	if (res < 0) {
		close (fd);
		syserrno = errno;
		upserror = SENDFAILURE;
		return (-1);	/* failure */
	}

	FD_ZERO (&rfd);
	FD_SET (fd, &rfd);
	tv.tv_sec = 2;	/* 2.0 seconds allowed for reply */
	tv.tv_usec = 0;

	res = select (fd + 1, &rfd, NULL, NULL, &tv);

	if (res > 0) {
		bzero (buf, buflen);
		fromlen = sizeof(from);
		res = recvfrom (fd, buf, buflen, 0, (struct sockaddr *) &from,
		                &fromlen);
	}
	else {
		close (fd);
		syserrno = errno;
		upserror = RECVTIMEOUT;
		return (-1);	/* failure */
	}

	if (res < 0) {
		close (fd);
		syserrno = errno;
		upserror = RECVFAILURE;
		return (-1);	/* failure */
	}

	close (fd);
	upserror = 0;
	return (1);	/* success */
}

int getupsvar (char *host, char *varname, char *buf, int buflen)
{
	char	cmd[256], tmp[512], *ptr;
	int	ret;

	snprintf (cmd, sizeof(cmd), "REQ %s", varname);
	ret = fetch (host, cmd, tmp, sizeof(tmp));

	if (ret != 1) {
		return (ret);
	}

	tmp[strlen(tmp) - 1] = 0;
	/* ANS <varname> <answer> */
	ptr = tmp + strlen(varname) + 5;
	if (!strcmp(ptr, "NOT-SUPPORTED")) {
		upserror = NOSUCHVAR;
		return (-1);	/* failure */
	}

	if (!strcmp(ptr, "DATA-STALE")) {
		upserror = NOCOMM1;
		return (-1);	/* failure */
	}

	bzero (buf, buflen);
	strncpy (buf, ptr, buflen);

	return (ret);
}

int getupsvarlist (char *host, char *buf, int buflen)
{
	char	tmp[512], *ptr;
	int	ret;

	ret = fetch (host, "LISTVARS", tmp, sizeof(tmp));

	if (ret != 1)
		return (ret);

	/* VARS <varlist> */
	tmp[strlen(tmp) - 1] = 0;
	ptr = tmp + 5;
	bzero (buf, buflen);
	strncpy (buf, ptr, buflen);

	return (ret);
}
