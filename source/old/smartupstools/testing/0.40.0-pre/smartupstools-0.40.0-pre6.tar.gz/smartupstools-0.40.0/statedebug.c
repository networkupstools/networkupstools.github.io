/* statedebug.c - debugging tool for writing support programs

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "shared.h"
#include <netinet/in.h>
#include "upsd.h"

/* dummy funcs to keep upsd.h stuff happy */
void sendver (struct sockaddr_in *dest, char *arg) {}
void sendans (struct sockaddr_in *dest, char *arg) {}
void sendhelp (struct sockaddr_in *dest, char *arg) {}
void listvars (struct sockaddr_in *dest, char *arg) {}

char *fname (int cmdnum)
{
	int	i;

	for (i = 0; netvars[i].name != NULL; i++)
		if (netvars[i].type == cmdnum)
			return (netvars[i].name);

	return (strdup ("UNKNOWN"));
}

void display (char *fn)
{
	itype	info;
	int	ifd, ret, i, count;

	ifd = open (fn, O_RDONLY);
	if (ifd < 0) {
		perror ("open");
		exit (1);
	}

	ret = read (ifd, &info, sizeof(itype));
	if (ret < 1) {
		perror ("read");
		exit (1);
	}

	count = atoi(info.value);
	for (i = 0; i < count - 1; i++) {
		ret = read (ifd, &info, sizeof(itype));
		printf ("%2i: %15s = %s\n", i, fname(info.type), info.value);
	}

	close (ifd);

	return;
}

int main (int argc, char **argv)
{
	struct	stat fs;
	int 	lastmtime = 0;

	if (argc != 2) {
		printf ("usage: %s <state file>\n", argv[0]);
		exit (1);
	}

	for (;;) {
		if (stat (argv[1], &fs)) {
			perror ("stat");
			exit (1);
		}

		if (fs.st_mtime != lastmtime) {
			lastmtime = fs.st_mtime;
			printf ("\n");
			display (argv[1]);
		}
	}

	return 0;
}
