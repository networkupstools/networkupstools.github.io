/* upsd.c - watches ups state files and answers queries 

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "shared.h"
#include "upsd.h"
#include "config.h"
#include "version.h"

#ifdef HAVE_SHMAT
#include <sys/shm.h>
#endif

#define MAXAGE	15	/* over 15 seconds old = data is stale */

#define UPSNAME "default"	/* TODO: multiple UPS support */

/* structure for the linked list of each UPS that we track */
typedef struct {
	char	*fn;
	int	shmid;
	char	*name;
	itype	*info;
	int	stale;
#ifdef HAVE_SHMAT
	struct	shmid_ds shmbuf;
#endif
	int	numinfo;
	void	*next;
}	upstype;

	upstype	*firstups = NULL;	/* pointer to linked list */
	int	udpfd, udpport = UDPPORT;

/* search for a ups given the name */
upstype *findups (char *upsname)
{
	upstype	*temp;

	temp = firstups;

	while (temp != NULL) {
		if (!strcasecmp(temp->name, upsname))
			return (temp);
		temp = temp->next;
	}

	return (NULL);
}

/* mark the data stale if this is new, otherwise do nothing */
void datastale (upstype *ups)
{
	/* don't do anything if it's been stale or if we're just starting */
	if ((ups->stale == 1) || (ups->stale == -1))
		return;

	ups->stale = 1;

	syslog (LOG_NOTICE, "Data for UPS [%s] is stale - check support module\n",
	        ups->name);

	ups->numinfo = 0;

	/* if we just dropped a state file, free the buffer */
	if ((ups->info != NULL) && (ups->shmid < 0)) {
		free(ups->info);
		ups->info = NULL;
	}

	return;
}

/* mark the data ok if this is new, otherwise do nothing */
void dataok (upstype *ups)
{
	if (ups->stale == 0)
		return;

	if (ups->stale == -1)		/* first time */
		syslog (LOG_NOTICE, "Read data for UPS [%s] successfully\n",
		        ups->name);
	else				/* subsequent time */
		syslog (LOG_NOTICE, "Data for UPS [%s] is now OK\n", ups->name);

	if (ups->shmid >= 0)
		syslog (LOG_NOTICE, "Data source for UPS [%s]: SHM (%i)\n", 
		        ups->name, ups->shmid);
	else
		syslog (LOG_NOTICE, "Data source for UPS [%s]: %s\n", 
		        ups->name, ups->fn);

	ups->stale = 0;
}

/* load data for a ups called <upsname> */
void updateups (char *upsname)
{
	int	stfd, ret;
	long	tdiff;
	struct	stat fs;
	time_t	tod;
	upstype	*ups;
	itype	tempinfo;
static	int	brokencompile = 0;

	ups = findups (upsname);

	if (ups == NULL)		/* sanity check */
		return;

	if (ups->fn == NULL)		/* sanity check */
		return;

	time (&tod);

#ifdef HAVE_SHMAT
	if (ups->shmid >= 0) {

		/* update information on shared memory segment */
		if (shmctl(ups->shmid, IPC_STAT, &ups->shmbuf) != 0) {
			datastale(ups);
			ups->shmid = -1;
			ups->info = NULL;
			return;
		}

		/* check attaches - should be at least 2 - model + upsd */
		if (ups->shmbuf.shm_nattch < 2) {
			datastale(ups);

			/* mark for deletion */
			shmctl (ups->shmid, IPC_RMID, NULL); 

			shmdt ((char *)ups->info);	/* detach */
			ups->info = NULL;
			ups->shmid = -1;
			return;
		}

		tdiff = tod - ups->shmbuf.shm_ctime;
		if (tdiff > MAXAGE) {
			datastale(ups);
			return;
		}

		dataok(ups);

		/* make sure we track how big the array is */
		ups->numinfo = atoi(ups->info[0].value);

		/* in shm mode, we're done at this point */
		return;
	}
#endif	/* HAVE_SHMAT */

	stfd = open (ups->fn, O_RDONLY);
	if (stfd < 0) {
		datastale (ups);
		return;
	}

	/* bring in first record to see what's up */
	ret = read (stfd, &tempinfo, sizeof(itype));
	if (ret < 1) {
		close (stfd);
		return;
	}

	/* if it's a shm pointer file, dereference it and switch modes */
	if (tempinfo.type == INFO_SHMID) {
		close (stfd);
#ifdef HAVE_SHMAT
		ups->shmid = atoi(tempinfo.value);
		ups->info = (itype *) shmat (ups->shmid, 0, 0);

		/* see if the shmat actually worked */
		if (ups->info == (itype *)(-1)) {
			ups->info = NULL;
			datastale(ups);
		}

		brokencompile = 0;	/* keep gcc quiet */
#else
		if (brokencompile == 0) {	/* only complain once */
			brokencompile = 1;
			syslog (LOG_NOTICE, "Need shared memory mode but HAVE_SHMAT wasn't defined during compile!\n");
		}
#endif
		return;
	}

	/* otherwise it must be a normal file, so do a sanity check */
	if (tempinfo.type != INFO_MEMBERS) {
		syslog (LOG_NOTICE, "Broken state file - doesn't start with INFO_MEMBERS!\n");
		close (stfd);
		datastale(ups);
	}

	/* if the struct changes sizes, realloc it */
	if (atoi(tempinfo.value) != ups->numinfo) {
		ups->numinfo = atoi(tempinfo.value);
		ups->info = realloc (ups->info, ups->numinfo * sizeof(itype));
	}		

	ret = read (stfd, ups->info, sizeof(itype) * atoi(tempinfo.value) - 1);
	if (ret == -1) {
		perror ("read");
		close (stfd);
		return;
	}
	close (stfd);

	/* now see if the state file is stale or not */
	if (stat (ups->fn, &fs)) { /* failed */
		datastale(ups);
		return;
	}

	time (&tod);
	tdiff = tod - fs.st_mtime;
	if (tdiff > MAXAGE) {
		datastale(ups);
		return;
	}

	dataok(ups);
}

/* start monitoring a ups called <name> from a file called <fn> */
void addups (char *fn, char *name)
{
	upstype	*temp, *last;

	temp = last = firstups;

	/* TODO: should see if "name" already exists */

	/* find end of linked list */
	while (temp != NULL) {
		last = temp;
		temp = temp->next;
	}

	/* grab some memory and add the info */
	temp = malloc (sizeof(upstype));
	temp->fn = strdup(fn);
	temp->shmid = -1;
	temp->name = strdup(name);
	temp->info = NULL;
	temp->stale = -1;
	temp->numinfo = 0;
	temp->next = NULL;

	if (last == NULL)	/* first one */
		firstups = temp;
	else			/* not the first */
		last->next = temp;

	updateups (name);
}

/* setup a socket for incoming udp requests */
void setupudp()
{
	struct	sockaddr_in	recv;

	if ((udpfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror ("Can't create socket");
		exit (1);
	}

	bzero ((char *) &recv, sizeof(recv));
	recv.sin_family = AF_INET;
	recv.sin_port = htons(udpport);

	if (bind(udpfd, (struct sockaddr *) &recv, sizeof(recv)) < 0) {
		perror ("Can't bind to socket");
		exit (1);
	}

	return;
}

/* send the buffer <sendbuf> of length <sendlen> to host <dest> */
void sendback (struct sockaddr_in *dest, char *sendbuf, int sendlen)
{
	int	res;

	res = sendto (udpfd, sendbuf, sendlen, 0, (struct sockaddr *) dest,
	      sizeof (struct sockaddr));

	return;
}

/* return a name for a command given its identifier (from shared.h) */
char *cmdname (int cmdnum)
{
	int	i;
	char	logbuf[256];

	for (i = 0; netvars[i].name != NULL; i++)
		if (netvars[i].type == cmdnum)
			return (netvars[i].name);

	if (cmdnum != INFO_UNUSED) {
	    snprintf (logbuf, sizeof(logbuf), "Unknown variable type 0x%04x", cmdnum);
	    syslog (LOG_INFO, logbuf);
	}
	
	return (strdup("UNKNOWN"));
}

/* handler for "REQ" - send a reply */
void sendans (struct sockaddr_in *dest, char *varname)
{
	int	i, type = 0;
	char	ans[256];
	upstype	*ups;

	ups = findups (UPSNAME);

	for (i = 0; netvars[i].name != NULL; i++)
		if (!strcasecmp(netvars[i].name, varname))
			type = netvars[i].type;
	
	/* type wasn't resolved in the netvars[] array */
	if (type == 0) {
		snprintf (ans, sizeof(ans), "ANS %s UNKNOWN\n", varname);
		sendback (dest, ans, strlen(ans));
		return;
	}

	/* stock reply - overwritten if an answer is found */
	snprintf (ans, sizeof(ans), "ANS %s NOT-SUPPORTED\n", varname);

	if (ups->stale == 1)
		snprintf (ans, sizeof(ans), "ANS %s DATA-STALE\n", varname);
	else
		for (i = 1; i < ups->numinfo; i++) 
			if (ups->info[i].type == type) {
				snprintf (ans, sizeof(ans), "ANS %s %s\n", varname,
				          ups->info[i].value);
				break;
			}

	sendback (dest, ans, strlen(ans));
}

/* handler for "LISTVARS" */
void listvars (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];
	int	i;
	upstype *ups;

	ups = findups (UPSNAME);

	snprintf (ans, sizeof(ans), "VARS");
	for (i = 1; i < ups->numinfo; i++) {
	    if (ups->info[i].type != INFO_UNUSED)
		snprintf (ans, sizeof(ans), "%s %s", ans,
		          cmdname(ups->info[i].type));
	}

	snprintf (ans, sizeof(ans), "%s\n", ans);
	sendback (dest, ans, strlen(ans));
}

/* handler for "VER" */
void sendver (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];

	snprintf (ans, sizeof(ans),
	          "Smart UPS Tools upsd %s - rkroll@exploits.org\n", UPS_VERSION);
	sendback (dest, ans, strlen(ans));
}

/* handler for "HELP" */
void sendhelp (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];

	snprintf (ans, sizeof(ans), "Commands: LISTVARS, REQ <var>, VER, HELP\n");
	sendback (dest, ans, strlen(ans));
}

/* parse requests from the network */
void parse (int len, char *buf, struct sockaddr_in *from)
{
	int	res, i;
	char	cmd[256], arg2[256], ans[256];

	bzero (cmd, sizeof(cmd));
	bzero (arg2, sizeof(arg2));
	res = sscanf (buf, "%s %s", cmd, arg2);

	for (i = 0; netcmds[i].name != NULL; i++) {
		if (!strcasecmp(netcmds[i].name, cmd)) {
			netcmds[i].func(from, arg2); 
			return;
		}
	}

	snprintf (ans, sizeof(ans), "Unknown command\n");
	sendback (from, ans, strlen(ans));
}

/* service requests and check on new data */
void mainloop (void)
{
	fd_set	rfds;
	struct	timeval	tv;
	struct	sockaddr_in from;
	int	res, fromlen;
	char	buf[256];

	FD_ZERO (&rfds);
	FD_SET (udpfd, &rfds);
	
	tv.tv_sec = 2;
	tv.tv_usec = 0;
	
	res = select (udpfd+1, (void *) &rfds, (void *) NULL,
		     (void *) NULL, &tv);

	if ((res) && (FD_ISSET (udpfd, &rfds))) {
		fromlen = sizeof(from);
		bzero (buf, sizeof(buf));
		res = recvfrom (udpfd, buf, sizeof(buf), 0, 
		               (struct sockaddr *) &from, &fromlen);
		parse (res, buf, &from);
	}

	/* TODO: multiple UPS support, update ALL units */
	updateups (UPSNAME);
}

/* close ttys and become a daemon */
void background()
{
	int	pid;

	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */

	syslog (LOG_INFO, "Startup successful");
}

/* change uid/gid if running as root */
void droproot ()
{
	setgid(RUN_AS_GID);

	if (getuid() == 0)
		if (setuid(RUN_AS_UID) == -1) {
			perror ("setuid");
			exit (1);
		}
}

#ifdef HAVE_SHMAT
/* detach from shared memory if necessary */
void detach_shm()
{
	upstype	*temp = firstups;

	while (temp != NULL) {
		if (temp->shmid >= 0) {
			/* mark for deletion */
			shmctl (temp->shmid, IPC_RMID, NULL); 
			shmdt ((char *)temp->info);	/* detach */
		}
		temp = temp->next;
	}	
}
#endif HAVE_SHMAT

int main (int argc, char **argv)
{
	printf ("Smart UPS Tools upsd %s\n", UPS_VERSION);

	setupudp();

	/* TODO: config file */
	droproot();		

	if (argc != 2) {
		printf ("usage: %s <path to state file>\n", argv[0]);
		exit (1);
	}

	openlog ("upsd", LOG_PID, LOG_FACILITY);

	/* TODO: multiple ups support */
	addups (argv[1], UPSNAME);

 	background();

	for (;;)
		mainloop();

	return (0);	
}
