/* upsstats - cgi program to generate the main ups info page

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

/* default host - only used if you don't specify one in the URL */
#define MONHOST "127.0.0.1"

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>
#include <fcntl.h>
#include "upsfetch.h"
#include "config.h"
#include "version.h"

	char	monhost[256];

void parsearg(char var[255], char value[255]) 
{
	if (!strcmp(var, "host")) {
		strncpy (monhost, value, sizeof(monhost));
	}
}

void extractcgiargs() 
{
	char	ch;
	int	invar, invalue, handled, i;
	char	var[255], value[255];
	char	*query;

	invar = 1;
	invalue = 0;

	strcpy (value, "");
	strcpy (var, "");

	query = getenv ("QUERY_STRING");
	if (query == NULL)
		return;		/* not run as a cgi script! */

	for (i = 0; i < strlen(query); i++) {
		ch = query[i];
		handled = 0;
		if (ch == '=') {
			invar = 0;
			invalue = 1;
			strcpy (value, "");
			handled = 1;
		}

		if (ch == '&') {
			invar = 1;
			invalue = 0;
			parsearg(var, value);
			strcpy (var, "");
			handled = 1;
		}

		if ((invar == 1) && (!handled)) {
			sprintf (var, "%s%c", var, ch);
		}

		if ((invalue == 1)  && (!handled)) {
			sprintf (value, "%s%c", value, ch);
		}
	}

	if (invalue) {
		value[strlen(value)] = 0;
		parsearg (var, value);
	}
}

int checkhost(char *check)
{
	FILE	*hostlist;
	char	fn[256], buf[256], addr[256], desc[256];

	sprintf(fn, "%s/etc/hosts.conf", BASEPATH);
	hostlist = fopen(fn, "r");

	if (hostlist == NULL)
		return 1;		/* default to allow */

	while (fgets (buf, sizeof(buf), hostlist)) 
		if (strncmp("MONITOR", buf, 7) == 0) {
			sscanf (buf, "%*s %s %s", addr, desc);
			if (!strcmp (addr, check)) {
				fclose (hostlist);
				return 1;	/* allowed */
			}
		}

	fclose (hostlist);
	return 0;		/* denied */
}	

char *getdate()
{
	char	*timestr;
	time_t	tod;

	timestr = calloc (255, sizeof(char));
	time (&tod);
	strftime (timestr, 100, "%a %b %d %X %Z %Y", localtime(&tod));

	return (timestr);
}

void nocomm()
{
	printf ("Error: %s\n", upsstrerror(upserror));
	exit (1);
}

int main() 
{
	double	tempf;
	char	model[64], status[64], battpct[64], utility[64], loadpct[64],
	        upstemp[64], acfreq[64], *stat;

	strcpy (monhost, MONHOST);	/* default host */

	extractcgiargs();

	printf ("Content-type: text/html\n"); 
	printf ("Pragma: no-cache\n");
	printf ("\n");

	if (!checkhost (monhost)) {
		printf ("Access to that host is not authorized.\n");
		exit (0);
	}

	if (getupsvar(monhost, "model", model, sizeof(model)) < 0)
		snprintf (model, sizeof(model), "Unknown - %s", upsstrerror(upserror));
	
	printf ("<HTML><HEAD><TITLE>%s on %s</TITLE></HEAD>\n", model, monhost);
	printf ("<BODY TEXTCOLOR=\"#000000\">\n");
	printf ("<CENTER><TABLE BORDER CELLSPACING=10 CELLPADDING=5>\n");
	printf ("<TR><TH>%s</TH>\n", getdate());
	printf ("<TH>Batt Chg</TH><TH>Utility</TH><TH>UPS Load</TH></TR>\n");
	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	printf ("Monitoring: %s\n", monhost);
	printf (" UPS Model: %s\n", model);

	getupsvar (monhost, "status", status, sizeof(status));
	printf ("    Status: ");

	stat = strtok (status, " ");
	while (stat != NULL) {
		if (!strcasecmp(stat, "OFF"))
			printf ("OFF ");
		if (!strcasecmp(stat, "OL"))
			printf ("ONLINE ");
		if (!strcasecmp(stat, "OB"))
			printf ("ON BATTERY");
		if (!strcasecmp(stat, "LB"))
			printf ("LOW BATTERY");
		stat = strtok (NULL, " ");
	} 
	printf ("\n"); 

	printf ("</PRE></TD>\n");

	if (getupsvar (monhost, "battpct", battpct, sizeof(battpct)) > 0)
		printf ("<TD ROWSPAN=3><IMG SRC=\"upsimage.cgi?host=%s&display=battpct\" WIDTH=130 HEIGHT=350 ALT=\"Battery charge: %s %%\"></TD>\n", monhost, battpct);
	else
		printf ("<TD ROWSPAN=3 VALIGN=TOP>Not supported\n");
	printf ("</TD>\n");

	if (getupsvar (monhost, "utility", utility, sizeof(utility)) > 0)
		printf ("<TD ROWSPAN=3><IMG SRC=\"upsimage.cgi?host=%s&display=utility\" WIDTH=130 HEIGHT=350 ALT=\"Utility: %s %%\"></TD>\n", monhost, utility);
	else {
		printf ("<TD ROWSPAN=3 VALIGN=TOP>Not supported\n");
		strcpy (utility, "");
	}
	printf ("</TD>\n");

	if (getupsvar (monhost, "loadpct", loadpct, sizeof(loadpct)) > 0)
		printf ("<TD ROWSPAN=3><IMG SRC=\"upsimage.cgi?host=%s&display=loadpct\" WIDTH=130 HEIGHT=350 ALT=\"UPS Load: %s %%\"></TD>\n", monhost, loadpct);
	else
		printf ("<TD ROWSPAN=3 VALIGN=TOP>Not supported\n");
	printf ("</TD>\n");

	printf ("</TR>\n");

	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	/* TODO: handle self tests */
	printf ("&nbsp;");
/*	printf ("Last UPS Self Test: Not Available\n"); */
/*	printf ("    Last Test Date: Not Available\n"); */
	printf ("</PRE></TD></TR>\n");

	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");

	if (strlen(utility) != 0)
		printf ("  UPS Output: %s VAC\n", utility);

	if (getupsvar (monhost, "upstemp", upstemp, sizeof(upstemp)) > 0) {
		tempf = (strtod (upstemp, 0) * 1.8) + 32;
#ifdef USE_CELSIUS
		printf ("    UPS Temp: %s �C\n", upstemp);
#else
		printf ("    UPS Temp: %.1f �F\n", tempf); 
#endif
	}

	if (getupsvar (monhost, "acfreq", acfreq, sizeof(acfreq)) > 0)
		printf (" Output Freq: %s Hz\n", acfreq);

	printf ("</PRE><P>\n");
	printf ("<CENTER>Smart UPS Tools upsstats %s</CENTER>\n", UPS_VERSION);

	printf ("</TD></TR>\n");
	printf ("</TABLE></CENTER>\n");

	return (1);
}
