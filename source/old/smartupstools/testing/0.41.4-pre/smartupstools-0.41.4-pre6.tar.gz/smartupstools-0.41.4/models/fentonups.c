/* fenton.c - model specific routines for Fenton Technologies units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

#define INFOMAX 16
#define ENDCHAR 13	/* replies end with CR */

	int	shmok = 1, maxbattvolts = 0, cap_upstemp = 0;
	char	statefn[256];
	itype	*info;
extern	int	flag_timeoutfailure;
	float	lowvolt = 0, voltrange;

void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables - max possible */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", INFOMAX);

	/* now set up room for all future variables that are supported */
	info[1].type = INFO_MFR;
	info[2].type = INFO_MODEL;
	info[3].type = INFO_UTILITY;
	info[4].type = INFO_BATTPCT;
	info[5].type = INFO_STATUS;
	info[7].type = INFO_ACFREQ;
	info[8].type = INFO_LOADPCT;
	info[9].type = INFO_LOWXFER;
	info[10].type = INFO_HIGHXFER;
}

char *rtrim (char *in)
{
	int	i;
	char	tmp[256];

	strncpy (tmp, in, sizeof(tmp) - 1);

	for (i = 0; i < strlen(tmp); i++)
		if (tmp [i] == ' ')
			tmp[i] = 0;

	return (strdup(tmp));
}

void getbaseinfo (char *port)
{
	char	temp[256], bvtemp[16], locale, model[32];

	/* dummy read attempt to sync - throw it out */
	send ('I');
	send (13);
	recv (temp, sizeof(temp), ENDCHAR, "");

	/* now retrieve information and parse */
	send ('I');
	send (13);
	recv (temp, sizeof(temp), ENDCHAR, "");

	if (temp[0] != '#') {
		printf ("Bad UPS info start character\n");
		printf ("Got: [%s]\n", temp);
		exit (1);
	}

	temp[11] = 0;
	temp[27] = 0;

	snprintf (info[1].value, sizeof(info[1].value), "%s", rtrim(&temp[1]));

	/* L660A = PowerPal (L) @ 660 VA, American (A) version (115V) */

	snprintf (model, sizeof(model), "%s", rtrim(&temp[18]));

	/* figure out voltage ranges based on model */

	if (!strncmp(model, "L280", 4) || !strncmp(model, "L425", 4)) {
		lowvolt = 9.6;
		voltrange = 2.4;	/* 9.6 - 12 VDC */
	}

	if (!strncmp(model, "L660", 4) || !strncmp(model, "L1000", 5)) {
		lowvolt = 19.6;
		voltrange = 4.4;	/* 19.6 - 24 VDC */
	}

	if (!strncmp(model, "L1400", 5)) {
		lowvolt = 29.4;
		voltrange = 6.6;	/* 29.4 - 36 VDC */
	}

	switch (temp[17]) {
		case 'L': snprintf (info[2].value, sizeof(info[2].value), 
		                    "PowerPal %s", model);
			  cap_upstemp = 0;
			  break;
		case 'H': snprintf (info[2].value, sizeof(info[2].value), 
		                    "PowerOn %s", model);
			  cap_upstemp = 1;
			  break;
		case 'M': snprintf (info[2].value, sizeof(info[2].value), 
		                    "PowerPure %s", model);
			  cap_upstemp = 1;
			  break;
		default: snprintf (info[2].value, sizeof(info[2].value), 
		                   "Unknown (%s)", rtrim(&temp[17]));
		         break;
	}

	/* strip off last char as locale info */
	locale = info[2].value[strlen(info[2].value) - 1];
	info[2].value[strlen(info[2].value) - 1] = 0;

	if (cap_upstemp == 1)
		addinfo (INFO_UPSTEMP, "");

	printf ("Detected %s on %s\n", getdata(INFO_MODEL), port);

	send ('F');
	send (13);
	recv (temp, sizeof(temp), ENDCHAR, "");

	if (temp[0] != '#') {
		printf ("Bad rating info start character\n");
		printf ("Got: [%s]\n", temp);
		exit (1);
	}

	/* volts current battvolts freq */
	sscanf (temp, "%*s %*s %s", bvtemp);
	maxbattvolts = atoi (bvtemp);

	/* hardcode appropriate low and high transfer points */

	switch (locale) {
		case 'A':		/* American voltages */
			snprintf (info[9].value, sizeof(info[9].value), "%s", 
			          "98.0");
			snprintf (info[10].value, sizeof(info[10].value), "%s", 
			          "126.0");
			break;
		case 'E':		/* European voltages */
			snprintf (info[9].value, sizeof(info[9].value), "%s", 
			          "196.0");
			snprintf (info[10].value, sizeof(info[10].value), "%s", 
			          "252.0");
			break;
		default:
			printf ("Unknown country code %c, reverting to USA voltage range\n",
			        locale);
			snprintf (info[9].value, sizeof(info[9].value), "%s", 
			          "98.0");
			snprintf (info[10].value, sizeof(info[10].value), "%s", 
			          "126.0");
			break;
	}	/* switch locale */

}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256], utility[16], loadpct[16], acfreq[16], battvolt[16],
		upstemp[16], stat[16];
	int	util;
	double	bvoltp;

	send ('Q');
	send ('1');
	send (13);

	recv (temp, sizeof(temp), ENDCHAR, "");

	sscanf (temp, "%*c%s %*s %*s %s %s %s %s %s", utility, loadpct, 
	        acfreq, battvolt, upstemp, stat);

	snprintf (info[3].value, sizeof(info[3].value), "%s", utility);

	bvoltp = ((atof(battvolt) - lowvolt) / voltrange) * 100.0;

	if (bvoltp > 100.0)
		bvoltp = 100.0;

	snprintf (info[4].value, sizeof(info[4].value), "%02.1f", bvoltp);

	strcpy (info[5].value, "");

	if (stat[0] == '0')
		strcat (info[5].value, "OL ");		/* on line */
	else
		strcat (info[5].value, "OB ");		/* on battery */

	if (stat[1] == '1')
		strcat (info[5].value, "LB ");		/* low battery */

	util = atoi (utility);

	/* TODO: this is obviously hardcoded for USA voltages */

	if (stat[2] == '1') {		/* boost or trim in effect */
		if ((util >= 84) && (util <= 98))
			strcat (info[5].value, "BOOST ");

		if ((util >= 126) && (util <= 142))
			strcat (info[5].value, "TRIM ");
	}

	/* lose trailing space if present */
	if (info[5].value[strlen(info[5].value)-1] == ' ')
		info[5].value[strlen(info[5].value)-1] = 0;

	if (cap_upstemp == 1)
		setinfo (INFO_UPSTEMP, upstemp);

	snprintf (info[7].value, sizeof(info[7].value), "%s", acfreq);
	snprintf (info[8].value, sizeof(info[8].value), "%s", loadpct);

	writeinfo(info);
}

/* power down the attached load immediately */
void forceshutdown(char *port)
{
	char	temp[256], stat[32];

	syslog (LOG_INFO, "Initiating UPS shutdown\n");
	printf ("Initiating forced UPS shutdown!\n");

	open_serial (port, B2400);

	/* basic idea: find out line status and send appropriate command */

	send ('Q');
	send ('1');
	send (13);
	recv (temp, sizeof(temp), ENDCHAR, "");
	sscanf (temp, "%*s %*s %*s %*s %*s %*s %*s %s", stat);

	/* on battery: send S01<cr>, ups will return by itself on utility */
	/* on line: send S01R0003<cr>, ups will cycle and return soon */

	send ('S');
	send ('0');
	send ('1');

	if (stat[0] == '0') {			/* on line */
		printf ("On line, sending shutdown+return command...\n");
		send ('R');
		send ('0');
		send ('0');
		send ('0');
		send ('3');
	}
	else
		printf ("On battery, sending normal shutdown command...\n");

	send (13);	/* end sequence */

	printf ("Waiting for poweroff...\n");
	sleep (90);
	printf ("Hmm, did the shutdown fail?  Oh well...\n");
	exit (1);                               
}

/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	/* TODO: future */
}

void usage (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("Example: %s /dev/ttyS0\n", prog);
	exit (1);
}

void help (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("\n");
	printf ("-h       - display this help\n");
	printf ("-k       - force shutdown\n");
	printf ("<device> - /dev entry corresponding to UPS port\n");
}

int main (int argc, char **argv)
{
	char	*portname, *prog;
	int	i;

	printf ("Smart UPS Tools - Fenton UPS driver 0.40 (%s)\n", UPS_VERSION);

	prog = argv[0];

	while ((i = getopt(argc, argv, "+hk:")) != EOF) {
		switch (i) {
			case 'k':
				forceshutdown(optarg);
				break;
			case 'h':
				help(prog);
				break;
			default:
				usage(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	if (argc != 1) {
		help (prog);
		exit (1);
	}

	droproot();

	openlog ("fentonups", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[0]); i >= 0; i--)
		if (argv[0][i] == '/') {
			portname = &argv[0][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[0]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/fentonups-%s", STATEPATH,
	          portname);

	open_serial (argv[0], B2400);

	initinfo();

	createmsgq();	/* try to create IPC message queue */

	getbaseinfo(argv[0]);

	setuphandlers();

 	background();

	for (;;) {
		char msgbuf[256];

		updateinfo();

		/* wait up to 2 seconds for a message from the upsd */

		/* TODO: parse this properly - this is for testing */
		if (getupsmsg(msgbuf, 256, 2) == 1)
			syslog (LOG_INFO, "Received a message from upsd\n");
	}
}
