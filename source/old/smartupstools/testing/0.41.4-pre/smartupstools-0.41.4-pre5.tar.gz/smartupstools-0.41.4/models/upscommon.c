/* upscommon.c - functions used in more than one model support module

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <sys/shm.h>

#include "smartups.h"
#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

#ifdef HAVE_UU_LOCK
#include <libutil.h>
#endif

#ifdef HAVE_MSGGET
#include <sys/ipc.h>
#include <sys/msg.h>
#endif

	int	upsfd, shmid = -1, msgid = -1;
	char	statefn[256], *upsport;
extern	itype	*info;
struct	ups_handler	upsh;
	
	int	flag_timeoutfailure = 0;

/* signal handler for SIGALRM when opening a serial port */
void openfail()
{
	printf ("Fatal error: serial port open timed out\n");
	exit (1);
}

/* try whatever method(s) are available to lock the port for our use */
void lockport (int upsfd, char *port)
{
	int	res;
	char	*portname;

	/* keep gcc quiet */
	res = 0;
	portname = NULL;

#ifdef HAVE_UU_LOCK
	if (upsport == NULL) {
		for (i = strlen (port); i >= 0; i--)
			if (port[i] == '/') {
				portname = &port[i+1];
				break;
			}
		
		/* save for later in case we need it at shutdown */
		upsport = strdup (portname);
	}

	res = uu_lock(portname);

	if (res != 0) {
		printf ("Can't lock %s: %s\n", port, uu_lockerr(res));
		exit (1);
	}
#else			/* no uu_lock */
#ifdef HAVE_FLOCK
	if (flock(upsfd, LOCK_EX | LOCK_NB) != 0) {
		printf ("%s is locked by another process\n", port);
		exit (1);
	}
#endif /* HAVE_FLOCK */
#endif /* HAVE_UU_LOCK */
}

/* open a serial port and setup the flags properly at a given speed */
void open_serial(char *port, speed_t speed)
{
	struct	termios	oldtio, newtio;

	signal (SIGALRM, openfail);
	alarm (3);

	upsfd = open (port, O_RDWR | O_NOCTTY | O_NONBLOCK);
	alarm (0);

	if (upsfd < 1) {
		printf ("Unable to open (1) %s: %s\n", port, strerror(errno));
		exit (1);
	}

	upsport = NULL;

	lockport (upsfd, port);

	tcgetattr (upsfd, &oldtio);
	newtio.c_lflag = 0 | ECHOE | ECHOKE | ECHOCTL | PENDIN;
	newtio.c_iflag = 0 | IXANY | IMAXBEL | IXOFF;
	newtio.c_oflag = 0 | ONLCR;
	newtio.c_cflag = 0 | CREAD | CS8 | HUPCL | CLOCAL;
	cfsetospeed (&newtio, speed);
	cfsetispeed (&newtio, speed);

	newtio.c_cc[VMIN] = 1;
	newtio.c_cc[VTIME] = 0;
	tcflush (upsfd, TCIFLUSH);
	tcsetattr(upsfd, TCSANOW, &newtio);
	close (upsfd);

	/* reopen for normal use */

	signal (SIGALRM, openfail);
	alarm (3);

	upsfd = open (port, O_RDWR | O_NOCTTY);
	alarm (0);

	if (upsfd < 1) {
		printf ("Unable to open (2) %s: %s\n", port, strerror(errno));
		exit (1);
	}

	lockport (upsfd, port);

	signal (SIGALRM, SIG_IGN);

	tcgetattr (upsfd, &oldtio);
	newtio.c_cflag = speed | CS8 | CLOCAL | CREAD;
	newtio.c_iflag = IGNPAR;
	newtio.c_oflag = 0;
	newtio.c_lflag = 0;
	newtio.c_cc[VMIN] = 1;
	newtio.c_cc[VTIME] = 0;

	tcflush (upsfd, TCIFLUSH);
	tcsetattr (upsfd, TCSANOW, &newtio);
}

/* put a notice in the syslog */
void notice (char *msg)
{
	char	logbuf[256];

	snprintf (logbuf, sizeof(logbuf), "Notice: %s", msg);
	syslog (LOG_NOTICE, msg);
}

/* put a fatal error in the syslog and exit */
void fatal (char *msg)
{
	char	logbuf[256];

	snprintf (logbuf, sizeof(logbuf), "Fatal error: %s", msg);
	syslog (LOG_ERR, msg);
	exit (1);
}

/* function for erasing "timeout"-conditions */
void nolongertimeout()
{
	static int flag_firstcall = 0;

	if (flag_firstcall == 0) {
	    notice ("Serial port read ok");
	    flag_firstcall = 1;
	}
	
	if (flag_timeoutfailure == 1) {
	    notice ("Serial port read ok again");
	}
	
	flag_timeoutfailure = 0;
	return;
}


/* signal handler for SIGALRM when trying to read */
void timeout()
{
	struct sigaction sa;
	sigset_t sigmask;

	if (flag_timeoutfailure == 0) {
	    notice ("Serial port read timed out");
	}
	
	flag_timeoutfailure = 1;
	
	sa.sa_handler = SIG_DFL;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);
	return;
}

/* wait for an answer in the form <data><CR><LF> and store in buf */
int recv (char *buf, int buflen, char endchar, char *ignchars)
{
	char	recvbuf[512], tmpbuf[512], in;
	int	ret, i, found;
	struct 	sigaction sa;
	sigset_t sigmask;

	strcpy (recvbuf, "");

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (3);

	for (;;) {
		ret = read (upsfd, &in, 1);
		if (ret > 0) {
			if (in == endchar) {
				alarm (0);
				signal (SIGALRM, SIG_IGN);
				strncpy (buf, recvbuf, buflen);
				buf[buflen - 1] = 0;
				return (buflen);
			}

			found = 0;
			for (i = 0; i < strlen (ignchars); i++)
				if (in == ignchars[i])
					found = 1;

			if (!found) {
				snprintf (tmpbuf, sizeof(tmpbuf), "%s", recvbuf);
				snprintf (recvbuf, sizeof(recvbuf), "%s%c", tmpbuf, in);
			}
			
			nolongertimeout();
		}
		else {
			return (-1);
		}

		/* keep from overrunning the buffer - lame hack */
		if (strlen (recvbuf) > 256) {
			notice ("UPS is spewing wildly");
			strcpy (recvbuf, "");
		}
	}

	return (-1);
}

/* send a single byte to the UPS */
int send (char data)
{
	tcflush (upsfd, TCIFLUSH);
	return (write (upsfd, &data, 1));
}

/* get data from the UPS and install it in the data array */
void installinfo (int infotype, char reqchar, char endchar, char *ignchars)
{
	int	i, pos = 0;

	for (i = 0; i < INFOMAX; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0) {	/* not found, probably debugging? */
		syslog (LOG_ERR, "installinfo: can't find type %i\n", infotype);
		return;
	}

	send (reqchar);
	recv (info[pos].value, sizeof(info[pos].value), endchar, ignchars);
}

/* store data into the array */
void setinfo (int infotype, char *data)
{
	int	i, pos = 0;

	for (i = 0; i < INFOMAX; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0) {	/* not found, probably debugging? */
		syslog (LOG_ERR, "installinfo: can't find type %i\n", infotype);
		return;
	}

	snprintf (info[pos].value, sizeof(info[pos].value), "%s", data);
}

/* find data of a given type in the info array */
char *getdata (int infotype)
{
	int	i;

	for (i = 0; i < INFOMAX; i++)
		if (info[i].type == infotype)
			return (info[i].value);
	
	return (NULL);
}

/* write data to state file - effectively a no-op for shared memory mode */
void writeinfo (itype *iwrite)
{
	int	sffd, ret;
	struct	shmid_ds shmbuf;

	/* if data is stale, don't write it so the information ages */
	if (flag_timeoutfailure == 1)
		return;

	/* if in shm mode and not writing shm struct, exit immediately */
	if ((iwrite[0].type != INFO_SHMID) && (shmid >= 0)) {

		/* this updates the ctime that upsd wants to see */
		shmctl (shmid, IPC_STAT, &shmbuf);
		shmctl (shmid, IPC_SET, &shmbuf);
		return;
	}

	sffd = open (statefn, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
	if (sffd >= 0) {
		ret = write (sffd, iwrite, sizeof(itype) * INFOMAX);
		if (ret >= 0) {
			close (sffd);
			return;
		}
	}
	/* ssfd < 0 || ret < 0 */
	{
		char buf[512];
		snprintf (buf, sizeof(buf),
			  "Can't open %s: %s\n", statefn, strerror(errno));
		buf[sizeof(buf)-1] = '\0';
		fatal(buf);
	}
}

static void test_writeinfo(void) 
{
        int sffd = open (statefn, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
        int tmperr;

        /* tests a write to the file only so the user
	   can see if something is wrong before it enters the background */

	if (sffd < 0) {
		tmperr = errno;
		printf ("Can't open %s: %s\n", statefn, strerror(tmperr));
		if (tmperr == EACCES)
			printf ("This file has to be accessible by userid %i\n", RUN_AS_UID);
		exit (1);
	}
	close (sffd);
}

    
#ifdef HAVE_SHMAT
void cleanup_shm ()
{
	syslog (LOG_INFO, "Detaching from shared memory");

	if (shmid == -1)
		return;

	/* mark for deletion after total detachment */
	shmctl (shmid, IPC_RMID, NULL);                

	shmdt ((char *) info);	/* detach */

	/* clean up msg queue if necessary */
#ifdef HAVE_MSGGET
	if (msgid != -1)
		msgctl (msgid, IPC_RMID, NULL);
#endif	/* HAVE_MSGGET */

}
#endif	/* HAVE_SHMAT */

/* handler for SIGTERM */
void sigterm(int sig)
{
	syslog (LOG_INFO, "SIGTERM: Shutting down");
#ifdef HAVE_UU_LOCK
	uu_unlock (upsport);
#endif
	exit (0);
}

/* install handler for sigterm */
void catch_sigterm()
{
	struct sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = sigterm;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGTERM, &sa, NULL);
}

/* detach from the controlling tty and enter the background */
void background()
{
	int	pid;

	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */
	syslog (LOG_INFO, "Startup successful");

	catch_sigterm();

#ifdef HAVE_SHMAT
	/* safe to add this now... */
	atexit (cleanup_shm);
#endif
}

void droproot ()
{
	setgid(RUN_AS_GID);

	if (getuid() == 0)
		if (setuid(RUN_AS_UID) == -1) {
			perror ("setuid");
			exit (1);
		}
}

itype *create_info (int numinfo, int shmok)
{
	itype	*tmpinfo = NULL;

#ifdef HAVE_SHMAT
	key_t	shmkey = IPC_PRIVATE;
	itype	shminfo[1];

        test_writeinfo();

/* some systems (NetBSD) don't define SHM_R and SHM_W - they default to it */
#ifdef SHM_R
#define IPC_MODE IPC_CREAT|SHM_R|SHM_W
#else
#define IPC_MODE IPC_CREAT
#endif
        
	if (shmok == 1) {
		/* get some shared memory for the array */
		shmid = shmget (shmkey, sizeof(itype) * numinfo, 
		                IPC_MODE);

		tmpinfo = (itype *) shmat (shmid, 0, 0);

		if (tmpinfo == (itype *) (-1)) {
			perror ("shmat");
			shmid = -1;
		}
		else {
			printf ("Using shared memory (ID %i)\n", shmid);

			/* create state file with SHM id */
			shminfo[0].type = INFO_SHMID;
			snprintf (shminfo[0].value, sizeof(shminfo[0].value), 
			          "%i", shmid);
		
			writeinfo (shminfo);
		}
	}	/* if shmok == 1 */

#endif	/* HAVE_SHMAT */

	if (shmid == -1) {	/* shm failed or is disabled - fallback */
		printf ("Using standard state file mode\n");
		tmpinfo = calloc (numinfo, sizeof(itype));
	}

	return (tmpinfo);
}

/* add a member to the info struct */
void addinfo (int type, char *value)
{
	int	i;

	for (i = 0; i < INFOMAX; i++) {
		if (info[i].type == INFO_UNUSED) {	/* found open spot */
			info[i].type = type;
			snprintf (info[i].value, sizeof(info[i].value), "%s", 
			          value);
			return;
		}
	}

	syslog (LOG_ERR, "Unable to add new member to info array!\n");

	return;
}

#ifndef HAVE_MSGGET

/* stubs */
void createmsgq() {}
int getupsmsg(char *buf, int buflen, int wait) { return 0; }
void sendupsmsg(msgtype *buf) {}

#else

/* create a SysV IPC message queue */
void createmsgq()
{
	char	tempid[16];

	/* init handlers early */
	memset (&upsh, '\0', sizeof(upsh));

	msgid = msgget (IPC_PRIVATE, IPC_CREAT | 0400 | 0200);

	if (msgid == -1) {
		perror ("msgget");
		return;
	}

	snprintf (tempid, sizeof(tempid), "%i", msgid);
	addinfo (INFO_MSGID, tempid);
}

/* handler for when msgrcv times out */
void nomsg(int sig)
{
	return;
}

/* make our own struct since some systems don't have struct msgbuf */
typedef struct {
	long    mtype;
	msgtype	msg;
}       mbuf;           

/* get a message if one's waiting in the queue */
int getupsmsg (char *buf, int buflen, int wait)
{
	mbuf	*mb;
	int	ret;

	if (msgid == -1)	/* no queue was created */
		return (0);	/* no msg received */

	mb = malloc (sizeof(mbuf) + UPSMSG_MAXLEN);

	/* set up alarm handler and schedule an alarm */
	signal (SIGALRM, nomsg);
	alarm (wait);

	ret = msgrcv (msgid, (struct msgbuf *) mb, UPSMSG_MAXLEN, UPSMSG_TOMODEL, 0);

	/* cancel the alarm */
	alarm (0);
	signal (SIGALRM, SIG_IGN);

	if (ret == -1) {
		free (mb);
		return (0);	/* no msg received */
	}

	/* now parse the message and deal with it */
	switch (mb->msg.cmdtype) {
		case UPSMSG_CMDSDD: 
			if (upsh.shutdown)
				upsh.shutdown(); 
			break;
		default: 
			syslog (LOG_INFO, "Unknown msgcmd 0x%04x\n",
			        mb->msg.cmdtype);
	}		

	free (mb);
	return (1);	/* msg received */
}

/* send a message to the upsd process */
void sendupsmsg (msgtype *buf)
{
	mbuf	*mb;
	int	ret;

	if (msgid == -1)	/* no queue was created */
		return;

	mb = malloc (sizeof(mbuf) + UPSMSG_MAXLEN);

	mb->mtype = UPSMSG_TOUPSD;
	memcpy (&mb->msg, buf, UPSMSG_MAXLEN);

	ret = msgsnd (msgid, (struct msgbuf *) mb, UPSMSG_MAXLEN, 0);
	free (mb);
}

#endif	/* HAVE_MSGGET */

void msgreply (int reptype)
{
	msgtype	msg;

	msg.cmdtype = reptype;
	msg.auxcmd = 0;
	msg.dlen = 0;
	msg.data = '\0';

	sendupsmsg (&msg);
}
