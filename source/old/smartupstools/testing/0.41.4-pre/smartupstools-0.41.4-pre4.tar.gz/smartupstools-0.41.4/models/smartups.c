/* smartups.c - model specific routines for APC Smart-UPS units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "smartups.h"
#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

	int	shmok = 1;
	char	statefn[256];
	itype	*info;
extern	int	flag_timeoutfailure;
	int	cap_measureupsii = 0;
extern	struct	ups_handler upsh;

/* Define this if you need to enable the temporary Smart-UPS 600 hacks... */
/* #define SU600_HACK */
/* TODO: command line argument for this or (better) autodetect */

void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables possible TOTAL */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", INFOMAX);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;
	snprintf (info[1].value, sizeof(info[1].value), "APC");

	/* now set up room for all future variables that are supported */
	info[2].type = INFO_MODEL;
	info[3].type = INFO_SERIAL;
	info[4].type = INFO_UTILITY;
	info[5].type = INFO_BATTPCT;
	info[6].type = INFO_STATUS;
	info[7].type = INFO_UPSTEMP;
	info[8].type = INFO_ACFREQ;
	info[9].type = INFO_LOADPCT;

	/* TODO: only add these if they exist (SU600 dilemma) */
	info[10].type = INFO_LOWXFER;
	info[11].type = INFO_HIGHXFER;
}

/* try to find AMBTEMP, CONTACTS and AMBHUMID */
void test_measureupsii()
{
	char	temp[256];

	send (REQ_AMBTEMP);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (!strcmp(temp, "NA"))	/* not supported */
		return;

	/* we got something, so it must be supported */

	cap_measureupsii = 1;		/* log this fact */

	printf ("Measure-UPS II detected!\n");

	addinfo (INFO_AMBTEMP, temp);

	/* Now probe the contacts */

	send (REQ_CONTACTS);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	addinfo (INFO_CONTACTS, temp);

	/* now try for ambient humidity support */

	send (REQ_AMBHUMID);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (!strcmp(temp, "NA"))	/* not supported */
		return;

	addinfo (INFO_AMBHUMID, temp);
}

void getbaseinfo (char *port)
{
	/* TODO: do this in a cleaner fashion without the ifdef */
#ifndef SU600_HACK
	installinfo (INFO_MODEL, REQ_MODEL, ENDCHAR, IGNCHARS);
#else
	snprintf (info[2].value, sizeof(info[2].value), "Smart-UPS 600");
#endif

	installinfo (INFO_SERIAL, REQ_SERIAL, ENDCHAR, IGNCHARS);

	printf ("Detected %s [%s] on %s\n", getdata(INFO_MODEL), 
		getdata(INFO_SERIAL), port);

	/* see if we have a Measure-UPS II connected */
	test_measureupsii();
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256];
	int	tval;

	/* try to wake up a dead ups once in awhile */
	if (flag_timeoutfailure == 1) {
		send (GO_SMART);
		recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	}

	installinfo (INFO_UTILITY, REQ_UTILITY, ENDCHAR, IGNCHARS);
	installinfo (INFO_BATTPCT, REQ_BATTPCT, ENDCHAR, IGNCHARS);
	installinfo (INFO_UPSTEMP, REQ_UPSTEMP, ENDCHAR, IGNCHARS);
	installinfo (INFO_ACFREQ, REQ_ACFREQ, ENDCHAR, IGNCHARS);
	installinfo (INFO_LOADPCT, REQ_LOADPCT, ENDCHAR, IGNCHARS);

#ifndef SU600_HACK
	installinfo (INFO_LOWXFER, REQ_LOWXFER, ENDCHAR, IGNCHARS);
	installinfo (INFO_HIGHXFER, REQ_HIGHXFER, ENDCHAR, IGNCHARS);
#else
	info[10].type = INFO_UNUSED;
	info[11].type = INFO_UNUSED;
#endif

	if (cap_measureupsii) {
		installinfo (INFO_AMBHUMID, REQ_AMBHUMID, ENDCHAR, IGNCHARS);
		installinfo (INFO_AMBTEMP, REQ_AMBTEMP, ENDCHAR, IGNCHARS);
		installinfo (INFO_CONTACTS, REQ_CONTACTS, ENDCHAR, IGNCHARS);
	}

	send (REQ_STATUS);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	tval = strtol (temp, 0, 16);

	strcpy (info[6].value, "");
	if (tval & 1)
		strcat (info[6].value, "CAL ");		/* calibration */
	if (tval & 2)
		strcat (info[6].value, "TRIM ");	/* SmartTrim */
	if (tval & 4)
		strcat (info[6].value, "BOOST ");	/* SmartBoost */
	if (tval & 8)
		strcat (info[6].value, "OL ");		/* on line */
	if (tval & 16)
		strcat (info[6].value, "OB ");		/* on battery */
	if (tval & 32)
		strcat (info[6].value, "OVER ");	/* overload */
	if (tval & 64)
		strcat (info[6].value, "LB ");		/* low battery */
	if (tval & 128)
		strcat (info[6].value, "RB ");		/* replace batt */	

	if (!strcmp(temp, "00"))
		snprintf (info[6].value, sizeof(info[6].value), "OFF");

	/* lose trailing space if present */
	if (info[6].value[strlen(info[6].value)-1] == ' ')
		info[6].value[strlen(info[6].value)-1] = 0;

	writeinfo(info);
}

/* power down the attached load immediately */
void forceshutdown(char *port)
{
	char	temp[32];

	syslog (LOG_INFO, "Initiating UPS shutdown\n");
	printf ("Initiating forced UPS shutdown!\n");

	open_serial (port, B2400);

	send (GO_SMART);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);
	if (strcmp(temp, "SM") != 0)
		printf ("Detection failed.  Trying a shutdown command anyway.\n");
	
	send ('Z');
	sleep (2);
	send ('Z');

	sleep (10);
	printf ("Hmm, did the shutdown fail?  Oh well...\n");
	exit (1);
}

/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	/* TODO: future */
}

void usage (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("Example: %s /dev/ttyS0\n", prog);
	exit (1);
}

void help (char *prog)
{
	printf ("usage: %s [-h] [-k] <device>\n", prog);
	printf ("\n");
	printf ("-h       - display this help\n");
	printf ("-k       - force shutdown\n");
	printf ("<device> - /dev entry corresponding to UPS port\n");
}

int main (int argc, char **argv)
{
	char	*portname, temp[256], *prog;
	int	i;

	printf ("Smart UPS Tools - SmartUPS driver 1.10 (%s)\n", UPS_VERSION);

	prog = argv[0];

	while ((i = getopt(argc, argv, "+hk:")) != EOF) {
		switch (i) {
			case 'k':
				forceshutdown(optarg);
				break;
			case 'h':
				help(prog);
				break;
			default:
				usage(prog);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	if (argc != 1) {
		help (prog);
		exit (1);
	}

	droproot();

	openlog ("smartups", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[0]); i >= 0; i--)
		if (argv[0][i] == '/') {
			portname = &argv[0][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[0]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/smartups-%s", STATEPATH,
	          portname);
	open_serial (argv[0], B2400);

	send (GO_SMART);
	recv (temp, sizeof(temp), ENDCHAR, IGNCHARS);

	if (strcmp(temp, "SM") != 0) {
		printf ("Unable to detect a SmartUPS on port %s\n", argv[0]);
		printf ("Check the cabling, port name or model name and try again\n");
		exit (1);
	}

	initinfo();

	createmsgq();	/* try to create IPC message queue */

	setuphandlers();

	getbaseinfo(argv[0]);

	background();

	for (;;) {
		char msgbuf[256];

		updateinfo();

		/* wait up to 2 seconds for a message from the upsd */

		/* TODO: parse this properly - this is for testing */
		if (getupsmsg(msgbuf, 256, 2) == 1)
			syslog (LOG_INFO, "Received a message from upsd\n");
	}
}
