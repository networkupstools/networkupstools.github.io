/* upsonic.c - model specific routines for UPSONIC LAN Server 600  units

   Copyright (C) 1999 Jason Thomas <jason@topic.com.au>

   Based upon backups.c:

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

#ifdef HAVE_UU_LOCK
#include <libutil.h>
#endif

	int	shmok = 1, upsfd;
	char	statefn[256];
	char stateflags;
#define ONLINE_MASK 0x01
#define LOWBAT_MASK 0x02
	itype	*info;
#define INFOMAX 8

void initinfo (void)
{
	int	i;

	stateflags = 0;
	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* put in how big this thing will be */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", 4);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;
	snprintf (info[1].value, sizeof(info[1].value), "UPSONIC");

	/* model string - hardcoded in this particular module */
	info[2].type = INFO_MODEL;
	snprintf (info[2].value, sizeof(info[2].value), "LAN Server 600");

	/* now set up room for all future variables that are supported */
	info[3].type = INFO_STATUS;
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	int	flags, cts, dcd;

	ioctl (upsfd, TIOCMGET, &flags);
	cts = (flags & TIOCM_CTS);
	dcd = (flags & TIOCM_CD);
	
	strcpy (info[3].value, "");

	if (dcd) {
		/* No longer on low battery */
		if(stateflags & LOWBAT_MASK){
#ifdef DEBUG_UPSONIC
			notice("UPS - battery charged");
#endif
		}
		stateflags &= ~LOWBAT_MASK;
	} else {
		strcat (info[3].value, "LB");	/* low battery */
		if( !(stateflags & LOWBAT_MASK) ){
			/* Just got the low battery warning */
#ifdef DEBUG_UPSONIC
			notice ("UPS - LOW BATTERY");
#endif
			stateflags |= LOWBAT_MASK;
		}
	}

	if (cts) {
		/* on line */
		strcat (info[3].value, "OL");
		if ( !(stateflags & ONLINE_MASK) ) {
			/* We've just come back online */
#ifdef DEBUG_UPSONIC
			notice ("UPS - ups online");
#endif
			stateflags |= ONLINE_MASK;
		}
	} else {
		/* on battery */
		strcat (info[3].value, "OB");
		if ( stateflags & ONLINE_MASK ) {
			/* We've just gone offline */
#ifdef DEBUG_UPSONIC
			notice ("UPS - POWER OFFLINE");
#endif
			stateflags &= ~ONLINE_MASK;
		}
	}

	writeinfo(info);
}

int main (int argc, char **argv)
{
	char	*portname;
	int	i;

	printf ("Smart UPS Tools - UPSONIC driver 0.03 (%s)\n", UPS_VERSION);

	if (argc != 2) {
		printf ("usage: %s <portname>	Example: %s /dev/ttyS0\n", 
		         argv[0], argv[0]);
		exit (1);
	}

	droproot();

	openlog ("upsonic", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[1]); i >= 0; i--)
		if (argv[1][i] == '/') {
			portname = &argv[1][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[1]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/upsonic-%s", STATEPATH,
	          portname);
	open_serial (argv[1], B2400);

	initinfo();

	createmsgq();   /* try to create IPC message queue */

	background();

	for (;;) {
#ifdef DEBUG
		char	msgbuf[256];
#endif

		updateinfo();

		/* wait up to 2 seconds for a message from the upsd */

#ifdef DEBUG_UPSONIC
		/* TODO: parse this properly - this is for testing */
		if (getupsmsg(msgbuf, 256, 2) == 1)
			notice("UPS - Received a message from upsd");
#endif
	}
}
