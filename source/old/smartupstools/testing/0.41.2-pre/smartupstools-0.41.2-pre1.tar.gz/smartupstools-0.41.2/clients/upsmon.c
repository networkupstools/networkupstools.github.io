/* upsmon - monitor power status over the 'net (talks to upsd via UDP)

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#include "upsfetch.h"
#include "config.h"
#include "version.h"

	char	*shutdowncmd = NULL, *notifycmd = NULL, *password = NULL;
	int	online = 1, onbatt = 0, lowbatt = 0, upsresp = -1, fd = -1; 

	/* default polling interval = 5 sec */
	int	pollfreq = 5;

	/* default alert time = 30 sec */
	int	alerttime = 30;

void wall(char *text)
{
	char	exec[512];

	snprintf (exec, sizeof(exec), "echo \"%s\" | wall", text);
	system (exec);
} 

void notify (char *notice)
{
	char	exec[512];

	syslog (LOG_NOTICE, notice);
	wall (notice);

	if (notifycmd != NULL) {
		snprintf (exec, sizeof(exec), "%s \"%s\"", notifycmd, notice);
		system (exec);
	}
}

void heardups(char *upsname)
{
	char	logbuf[256];

	if (upsresp == 1)	/* nothing new ... */
		return;

	if (upsresp == -1) {	/* ups is there, first time */
		upsresp = 1;
		syslog (LOG_INFO, "Communication with UPS established");
	}

	if (upsresp == 0) {	/* ups is back */
		upsresp = 1;
		syslog (LOG_INFO, "Communication with UPS re-established");
	}

	/* LOGIN to the desired UPS */
	if (upslogin (fd, upsname, password) < 0) {
		snprintf (logbuf, sizeof(logbuf), "Unable to login: %s\n",
		          upsstrerror(upserror));
		syslog (LOG_INFO, logbuf);
	}
}

void upsgone()
{
	if (upsresp == 1) {  /* ups isn't there, first time */
		syslog (LOG_INFO, "Communication with UPS lost");
		upsresp = 0;
	}
}

void upsonbatt()
{
	if (onbatt == 0) {
		notify ("UPS is on battery");
		onbatt = 1;
		online = 0;
	}

	/* TODO: implement alerttime */
}

void upsonline()
{
	if (online == 0) {
		notify ("UPS back on line power");
		online = 1;
		onbatt = 0;
	}
}

void upslowbatt()
{
	/* critical only if on battery + low battery */
	if (onbatt == 0)
		return;

	syslog (LOG_CRIT, "Low battery - Executing automatic power-fail shutdown");
	wall ("Low battery - executing automatic power-fail shutdown\n");

	if (getuid() != 0) {
		syslog (LOG_ALERT, "Not root, unable to shutdown system");
		exit (1);
	}

	notify ("Auto logout and shutdown in 15 seconds!");
	sleep (15);

	/* TODO: put real logic here ...

	1. send <notify message>
	2. wait <num> seconds
	3. log out from upsd
	4. execute <shutdowncmd> 

	*/
	
	system (shutdowncmd);
	exit (1);
}

void background()
{
	int	pid;

	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */

	syslog (LOG_INFO, "Startup successful");
}

/* return everything to the end of the line in a new buffer */
char *dynchar (char *data)
{
	char	*temp;

	temp = calloc (strlen(data), 1);
	strncpy (temp, data, strlen(data) - 1);
	return (temp);
}

void loadconfig (void)
{
	char	cfn[256], buf[256];
	FILE	*conf;

	snprintf (cfn, sizeof(cfn), "%s/etc/upsmon.conf", BASEPATH);

	conf = fopen(cfn, "r");
	if (conf == NULL) {
		printf ("Can't open %s/etc/upsmon.conf: %s\n", BASEPATH, 
		        strerror(errno));
		exit (1);
	}

	/* TODO: allow overriding stock messages from config file */

	while (fgets(buf, sizeof(buf), conf)) {
		if (!strncmp(buf, "SHUTDOWNCMD", 11))
			shutdowncmd = dynchar (&buf[12]);

		if (!strncmp(buf, "NOTIFYCMD", 9)) {
			notifycmd = dynchar (&buf[10]);
			syslog (LOG_INFO, "External notify command enabled\n");
		}

		if (!strncmp(buf, "PASSWORD", 8))
			password = dynchar (&buf[9]);

		if (!strncmp(buf, "POLLFREQ", 8))
			pollfreq = atoi(dynchar(&buf[9]));

		if (!strncmp(buf, "ALERTTIME", 9))
			alerttime = atoi(dynchar(&buf[10]));
	}	

	fclose (conf);
}

/* SIGPIPE handler */
void sigpipe (int sig)
{
	upsgone();
	close (fd);
	fd = -1;
}

/* basic signal setup to handle SIGPIPE */
void setupsignals()
{
	struct sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = sigpipe;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGPIPE, &sa, NULL);
}

/* handler for alarm when getupsvarfd times out */
void timeout (int sig)
{
	if (upsresp == 1)
		syslog (LOG_INFO, "Communications with UPS timed out\n");

	upsgone();
}

/* see what the status of the UPS is and handle any changes */
void pollups(char *upsname)
{
	char	status[256], *stat;
	struct	sigaction sa;
	sigset_t sigmask;

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (10);

	if (getupsvarfd(fd, upsname, "status", status, sizeof(status)) >= 0) {
		signal (SIGALRM, SIG_IGN);
		alarm (0);
		heardups(upsname);

		stat = strtok (status, " ");
		while (stat != NULL) {
			if (!strcasecmp(stat, "OL"))
				upsonline();
			if (!strcasecmp(stat, "OB"))
				upsonbatt();
			if (!strcasecmp(stat, "LB"))
				upslowbatt();
			stat = strtok(NULL, " ");
		} 
	}
	else {	/* fetch failed */
		signal (SIGALRM, SIG_IGN);
		alarm (0);
		upsgone();
	}
}

int main(int argc, char *argv[])  
{
	char	*ptr, *host, *upsname;

	printf ("Smart UPS Tools upsmon %s\n", UPS_VERSION);

	if (argc != 2) {
		printf ("Usage: %s <host to monitor>     Example: %s 10.2.254.1\n", argv[0], argv[0]);
		exit (1);
	}

	openlog ("upsmon", LOG_PID, LOG_FACILITY);
	loadconfig();

	if (shutdowncmd == NULL)
		printf ("Warning: no shutdown command defined!\n");

	/* split upsname@host into separate parts */
	ptr = strstr (argv[1], "@");
	if (ptr != NULL) {
		ptr[0] = 0;
		upsname = argv[1];
		host = ptr + 1;
	}
	else {
		upsname = NULL;
		host = argv[1];
	}

	/* ignore sigpipes before the connection opens */
	setupsignals();

	/* try a connect - if it fails, we'll try again later */
	fd = upsconnect (host);

	if (upsname != NULL)
		syslog (LOG_INFO, "Monitoring UPS [%s] on %s", upsname, host);
	else
		syslog (LOG_INFO, "Monitoring UPS on %s", host);

	printf ("Monitoring UPS on %s\n", host);

	background();
	
	for (;;) {
		/* if the connection has been broken, try to re-establish it */
		if (fd == -1)
			fd = upsconnect (host);
		else
			pollups(upsname);

		sleep (pollfreq);
	}

	return (1);
}
