#define UPS_VERSION "0.41.2-pre1"
