/* upsd.c - watches ups state files and answers queries 

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <math.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "shared.h"
#include "upsd.h"
#include "config.h"
#include "version.h"

#ifdef HAVE_SHMAT
#include <sys/shm.h>
#endif

#define MAXAGE	15	/* over 15 seconds old = data is stale */

/* structure for the linked list of each UPS that we track */
typedef struct {
	char	*fn;
	int	shmid;
	char	*name;
	itype	*info;
	int	stale;
#ifdef HAVE_SHMAT
	struct	shmid_ds shmbuf;
#endif
	int	numinfo;
	void	*next;
}	upstype;

typedef struct {
	char	*name;
	unsigned int	addr;
	unsigned int	mask;
	void	*next;
}	acltype;

typedef struct {
	char	*addr;
	int	fd;
	struct sockaddr_in sock;
	char	rq[256];
	int	rqpos;
	void	*next;
}	ctype;

#define ACTION_GRANT	1
#define ACTION_DENY	2
#define ACTION_DROP	4

#define LEVEL_BASE	1
#define LEVEL_MONITOR	3
#define LEVEL_MANAGER	7
#define LEVEL_ALL	255

typedef struct {
	int	action;
	int	level;
	char	*aclname;
	void	*next;
}	acctype;

	/* pointers to linked lists */
	upstype	*firstups = NULL;
	acltype *firstacl = NULL;
	acctype *firstacc = NULL;
	ctype	*firstclient = NULL, *currclient = NULL;

	/* by default TCP uses the same port - use -t to override */
	int	udpfd, udpport = UDPPORT, upsnum = 0;
	int	listenfd, tcpport = UDPPORT;

/* search for a ups given the name */
upstype *findups (char *upsname)
{
	upstype	*temp;

	temp = firstups;

	/* return first one if a good name isn't given */
	if ((!strcasecmp(upsname, "default")) || (!strcmp(upsname, "")))
		return (temp);
	
	while (temp != NULL) {
		if (!strcasecmp(temp->name, upsname))
			return (temp);

		temp = temp->next;
	}

	return (NULL);
}

/* mark the data stale if this is new, otherwise do nothing */
void datastale (upstype *ups)
{
	/* don't do anything if it's been stale or if we're just starting */
	if ((ups->stale == 1) || (ups->stale == -1))
		return;

	ups->stale = 1;

	syslog (LOG_NOTICE, "Data for UPS [%s] is stale - check support module\n",
	        ups->name);

	ups->numinfo = 0;

	/* if we just dropped a state file, free the buffer */
	if ((ups->info != NULL) && (ups->shmid < 0)) {
		free(ups->info);
		ups->info = NULL;
	}

	return;
}

/* mark the data ok if this is new, otherwise do nothing */
void dataok (upstype *ups)
{
	if (ups->stale == 0)
		return;

	if (ups->stale == -1)		/* first time */
		syslog (LOG_NOTICE, "Read data for UPS [%s] successfully\n",
		        ups->name);
	else				/* subsequent time */
		syslog (LOG_NOTICE, "Data for UPS [%s] is now OK\n", ups->name);

	if (ups->shmid >= 0)
		syslog (LOG_NOTICE, "Data source for UPS [%s]: SHM (%i)\n", 
		        ups->name, ups->shmid);
	else
		syslog (LOG_NOTICE, "Data source for UPS [%s]: %s\n", 
		        ups->name, ups->fn);

	ups->stale = 0;
}

/* load data for a ups called <upsname> */
void updateups (char *upsname)
{
	int	stfd, ret;
	long	tdiff;
	struct	stat fs;
	time_t	tod;
	upstype	*ups;
	itype	tempinfo;
static	int	brokencompile = 0;

	ups = findups (upsname);

	if (ups == NULL)		/* sanity check */
		return;

	if (ups->fn == NULL)		/* sanity check */
		return;

	time (&tod);

#ifdef HAVE_SHMAT
	if (ups->shmid >= 0) {

		/* update information on shared memory segment */
		if (shmctl(ups->shmid, IPC_STAT, &ups->shmbuf) != 0) {
			datastale(ups);
			ups->shmid = -1;
			ups->info = NULL;
			return;
		}

		/* check attaches - should be at least 2 - model + upsd */
		if (ups->shmbuf.shm_nattch < 2) {
			datastale(ups);

			/* mark for deletion */
			shmctl (ups->shmid, IPC_RMID, NULL); 

			shmdt ((char *)ups->info);	/* detach */
			ups->info = NULL;
			ups->shmid = -1;
			return;
		}

		tdiff = tod - ups->shmbuf.shm_ctime;
		if (tdiff > MAXAGE) {
			datastale(ups);
			return;
		}

		dataok(ups);

		/* make sure we track how big the array is */
		ups->numinfo = atoi(ups->info[0].value);

		/* in shm mode, we're done at this point */
		return;
	}
#endif	/* HAVE_SHMAT */

	stfd = open (ups->fn, O_RDONLY);
	if (stfd < 0) {
		datastale (ups);
		return;
	}

	/* bring in first record to see what's up */
	ret = read (stfd, &tempinfo, sizeof(itype));
	if (ret < 1) {
		close (stfd);
		return;
	}

	/* if it's a shm pointer file, dereference it and switch modes */
	if (tempinfo.type == INFO_SHMID) {
		close (stfd);
#ifdef HAVE_SHMAT
		ups->shmid = atoi(tempinfo.value);
		ups->info = (itype *) shmat (ups->shmid, 0, 0);

		/* see if the shmat actually worked */
		if (ups->info == (itype *)(-1)) {
			ups->info = NULL;
			datastale(ups);
		}

		brokencompile = 0;	/* keep gcc quiet */
#else
		if (brokencompile == 0) {	/* only complain once */
			brokencompile = 1;
			syslog (LOG_NOTICE, "Need shared memory mode but HAVE_SHMAT wasn't defined during compile!\n");
		}
#endif
		return;
	}

	/* otherwise it must be a normal file, so do a sanity check */
	if (tempinfo.type != INFO_MEMBERS) {
		syslog (LOG_NOTICE, "Broken state file - doesn't start with INFO_MEMBERS!\n");
		close (stfd);
		datastale(ups);
	}

	/* if the struct changes sizes, realloc it */
	if (atoi(tempinfo.value) != ups->numinfo) {
		ups->numinfo = atoi(tempinfo.value);
		ups->info = realloc (ups->info, ups->numinfo * sizeof(itype));
	}		

	ret = read (stfd, ups->info, sizeof(itype) * atoi(tempinfo.value) - 1);
	if (ret == -1) {
		perror ("read");
		close (stfd);
		return;
	}
	close (stfd);

	/* now see if the state file is stale or not */
	if (stat (ups->fn, &fs)) { /* failed */
		datastale(ups);
		return;
	}

	time (&tod);
	tdiff = tod - fs.st_mtime;
	if (tdiff > MAXAGE) {
		datastale(ups);
		return;
	}

	dataok(ups);
}

/* start monitoring a ups called <name> from a file called <fn> */
void addups (char *fn, char *name)
{
	upstype	*temp, *last;

	temp = last = firstups;

	if (!strcasecmp(name, "default")) {
		printf ("You can't add a UPS called default!\n");
		return;
	}

	/* find end of linked list */
	while (temp != NULL) {
		last = temp;

		if (!strcasecmp(temp->name, name)) {
			printf ("UPS name [%s] is already in use!\n", name);
			return;
		}

		temp = temp->next;
	}

	/* grab some memory and add the info */
	temp = malloc (sizeof(upstype));
	temp->fn = strdup(fn);
	temp->shmid = -1;
	temp->name = strdup(name);
	temp->info = NULL;
	temp->stale = -1;
	temp->numinfo = 0;
	temp->next = NULL;

	if (last == NULL)	/* first one */
		firstups = temp;
	else			/* not the first */
		last->next = temp;

	updateups (name);
	upsnum++;
}

/* setup a socket for incoming udp requests */
void setupudp()
{
	struct	sockaddr_in	recv;

	if ((udpfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror ("Can't create socket");
		exit (1);
	}

	bzero ((char *) &recv, sizeof(recv));
	recv.sin_family = AF_INET;
	recv.sin_port = htons(udpport);

	if (bind(udpfd, (struct sockaddr *) &recv, sizeof(recv)) < 0) {
		perror ("Can't bind to socket");
		exit (1);
	}

	return;
}

/* create a listening socket for tcp connections */
void setuptcp()
{
	struct	sockaddr_in	server;
	int	res;

	if ((listenfd = socket (AF_INET, SOCK_STREAM, 0)) < 0) {
		perror ("socket");
		exit (1);
	}

	bzero ((char *) &server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(tcpport);

	if (bind (listenfd, (struct sockaddr *) &server, 
	   sizeof (struct sockaddr_in)) == -1) {
		perror ("bind");
		exit (1);
	}

	if ((res = fcntl(listenfd, F_GETFL, 0)) == -1) {
		perror ("fcntl(get)");
		exit (1);
	}

	if (fcntl(listenfd, F_SETFL, res | O_NDELAY) == -1) {
		perror ("fcntl(set)");
		exit (1);
	}

	if (listen (listenfd, 16)) {
		perror ("listen");
		exit (1);
	}

	return;
}

/* send the buffer <sendbuf> of length <sendlen> to host <dest> */
void sendback (struct sockaddr_in *dest, char *sendbuf, int sendlen)
{
	int	res, destfd;

	if (currclient == NULL)		/* udp */
		destfd = udpfd;
	else
		destfd = currclient->fd;

	res = sendto (destfd, sendbuf, sendlen, 0, (struct sockaddr *) dest,
	              sizeof (struct sockaddr));
	return;
}

/* see if <addr> matches the acl <aclname> */
int checkacl (char *aclname, struct sockaddr_in *addr)
{
	acltype	*tmp;
	int	aclchk, addrchk;

	tmp = firstacl;
	while (tmp != NULL) {
		if (!strcmp(tmp->name, aclname)) {
			aclchk = tmp->addr & tmp->mask;
			addrchk = ntohl(addr->sin_addr.s_addr) & tmp->mask;

			if (aclchk == addrchk)
				return 1;
		}

		tmp = tmp->next;
	}

	return 0;
}

int checkaccess (struct sockaddr_in *ip, int level)
{
	acctype	*tmp;

	tmp = firstacc;

	while (tmp != NULL) {
		if ((checkacl (tmp->aclname, ip) == 1) && 
		   ((tmp->level & level) == level)) {
			switch (tmp->action) {
				case ACTION_GRANT: 
					return (1); 
					break;

				case ACTION_DENY: 
					sendback (ip, "ERR ACCESS-DENIED\n", 18);

				/* silent return, no response */
				case ACTION_DROP:
				default:
					return (0);
			}
		}

		tmp = tmp->next;
	}

	/* default = drop */
	return (0);
}

/* remove a client struct from the linked list */
void delclient (ctype *dclient)
{
	ctype	*tmp, *last;

	last = NULL;
	tmp = firstclient;

	while (tmp != NULL) {
		if (tmp == dclient) {		/* found it */
			free (tmp->addr);
			if (last == NULL)	/* deleting first entry */
				firstclient = NULL;
			else
				last->next = tmp->next;
			free (tmp);
			return;
		}
		last = tmp;
		tmp = tmp->next;
	}

	/* not found?! */
	syslog (LOG_INFO, "Tried to delete client struct that doesn't exist!\n");

	return;
}

/* return a name for a command given its identifier (from shared.h) */
char *cmdname (int cmdnum)
{
	int	i;
	char	logbuf[256];

	for (i = 0; netvars[i].name != NULL; i++)
		if (netvars[i].type == cmdnum)
			return (netvars[i].name);

	if (cmdnum != INFO_UNUSED) {
	    snprintf (logbuf, sizeof(logbuf), "Unknown variable type 0x%04x", cmdnum);
	    syslog (LOG_INFO, logbuf);
	}
	
	return (strdup("UNKNOWN"));
}

/* handler for "REQ" - send a reply */
void sendans (struct sockaddr_in *dest, char *varin)
{
	int	i, type = 0;
	char	ans[256], vartmp[256], *upsname, *varname;
	upstype	*ups;

	if (!checkaccess (dest, LEVEL_MONITOR))
		return;

	snprintf (vartmp, sizeof(vartmp), "%s", varin);

	/* point upsname at the word beyond the @ */
	upsname = strtok(vartmp, "@") ;
	upsname = strtok(NULL, "@") ;

	if (upsname != NULL)
		varname = strtok (vartmp, "@");
	else {
		upsname = strdup ("default");
		varname = varin;
	}

	ups = findups (upsname);

	if (ups == NULL) {
		snprintf (ans, sizeof(ans), "ANS %s UNKNOWN-UPS\n", varin);
		sendback (dest, ans, strlen(ans));
		return;
	}

	for (i = 0; netvars[i].name != NULL; i++)
		if (!strcasecmp(netvars[i].name, varname))
			type = netvars[i].type;
	
	/* type wasn't resolved in the netvars[] array */
	if (type == 0) {
		snprintf (ans, sizeof(ans), "ANS %s UNKNOWN\n", varin);
		sendback (dest, ans, strlen(ans));
		return;
	}

	/* stock reply - overwritten if an answer is found */
	snprintf (ans, sizeof(ans), "ANS %s NOT-SUPPORTED\n", varin);

	if (ups->stale == 1)
		snprintf (ans, sizeof(ans), "ANS %s DATA-STALE\n", varin);
	else
		for (i = 1; i < ups->numinfo; i++) 
			if (ups->info[i].type == type) {
				snprintf (ans, sizeof(ans), "ANS %s %s\n", varin,
				          ups->info[i].value);
				break;
			}

	sendback (dest, ans, strlen(ans));
}

/* handler for "LISTVARS" */
void listvars (struct sockaddr_in *dest, char *arg)
{
	char	ans[256], tmp[256];
	int	i;
	upstype *ups;

	if (!checkaccess (dest, LEVEL_MONITOR))
		return;

	ups = findups (arg);

	if (ups == NULL) {
		snprintf (ans, sizeof(ans), "ERR UNKNOWN-UPS\n");
		sendback (dest, ans, strlen(ans));
		return;
	}

	snprintf (ans, sizeof(ans), "VARS");

	/* insert "@upsname" if explicitly specified in request */
	if (strcmp(arg, "") != 0) {
		snprintf (tmp, sizeof(tmp), "%s", ans);
		snprintf (ans, sizeof(ans), "%s @%s", tmp, arg);
	}		

	for (i = 1; i < ups->numinfo; i++) {
	    if (ups->info[i].type != INFO_UNUSED) {
		snprintf (tmp, sizeof(tmp), "%s", ans);
		snprintf (ans, sizeof(ans), "%s %s", tmp,
		          cmdname(ups->info[i].type));
	    }
	}

	snprintf (tmp, sizeof(tmp), "%s", ans);
	snprintf (ans, sizeof(ans), "%s\n", tmp);
	sendback (dest, ans, strlen(ans));
}

/* handler for "VER" */
void sendver (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];

	if (!checkaccess (dest, LEVEL_BASE))
		return;

	snprintf (ans, sizeof(ans),
	          "Smart UPS Tools upsd %s - rkroll@exploits.org\n", UPS_VERSION);
	sendback (dest, ans, strlen(ans));
}

/* handler for "HELP" */
void sendhelp (struct sockaddr_in *dest, char *arg)
{
	char	ans[256];

	if (!checkaccess (dest, LEVEL_BASE))
		return;

	snprintf (ans, sizeof(ans), "Commands: HELP, LISTVARS, LOGOUT, REQ <var>, VER\n");
	sendback (dest, ans, strlen(ans));
}

/* handler for "VER" */
void logout (struct sockaddr_in *dest, char *arg)
{
	char	logbuf[256];

	if (currclient == NULL) {
		sendback (dest, "Can't logout in UDP mode!\n", 26);
		return;
	}

	sendback (dest, "Goodbye...\n", 11);
	shutdown (currclient->fd, 2);
	close (currclient->fd);

	snprintf (logbuf, sizeof(logbuf), "Client on %s logged out\n", 
	          currclient->addr);
	syslog (LOG_INFO, logbuf);

	delclient (currclient);
}		

/* parse requests from the network */
void parse (int len, char *buf, struct sockaddr_in *from)
{
	int	res, i;
	char	cmd[512], arg2[512], ans[256];

	if (!checkaccess (from, LEVEL_BASE))
		return;

	memset (cmd, '\0', sizeof(cmd));
	memset (arg2, '\0', sizeof(arg2));
	res = sscanf (buf, "%s %s", cmd, arg2);

	for (i = 0; netcmds[i].name != NULL; i++) {
		if (!strcasecmp(netcmds[i].name, cmd)) {
			netcmds[i].func(from, arg2); 
			return;
		}
	}

	snprintf (ans, sizeof(ans), "Unknown command\n");
	sendback (from, ans, strlen(ans));
}

/* update every ups that is being monitored */
void updateall (void)
{
	upstype *ups;

	ups = firstups;

	while (ups != NULL) {
		updateups (ups->name);
		ups = ups->next;
	}

	return;
}

/* add the acl to the linked list */
void addacl (char *aclname, char *ipblock)
{
	acltype	*tmp, *last;
	char	*addr, *mask;

	addr = strtok (ipblock, "/");
	mask = strtok (NULL, "/");

	/* ipblock must be in the form <addr>/<mask>	*/

	/* 206.253.95.200/32 : VALID			*/
	/* 206.253.95.200:255.255.255.255 : VALID	*/
	/* 206.253.95.200 : INVALID			*/

	if ((addr == NULL) || (mask == NULL))	/* broken acl */
		return;

	tmp = last = firstacl;

	while (tmp != NULL) {	/* find end */
		last = tmp;
		tmp = tmp->next;
	}

	tmp = malloc (sizeof (acltype));
	tmp->name = strdup (aclname);
	tmp->addr = ntohl(inet_addr (addr));
	tmp->next = NULL;

	if (strstr(mask, ".") == NULL)	/* must be a /nn CIDR type block */
		tmp->mask = ((unsigned int) (pow (2, atoi(mask)) - 1) << 
		            (32 - atoi(mask)));
	else
		tmp->mask = ntohl(inet_addr (mask));

	if (last == NULL)	/* first */
		firstacl = tmp;
	else
		last->next = tmp;
}

/* add to the access linked list */
void addaccess (char *action, char *level, char *aclname)
{
	acctype	*tmp, *last;

	tmp = last = firstacc;

	while (tmp != NULL) {	/* find end */
		last = tmp;
		tmp = tmp->next;
	}

	tmp = malloc (sizeof(acctype));
	tmp->action = 0;
	tmp->level = 0;

	if (!strcasecmp(action, "grant"))
		tmp->action = ACTION_GRANT;
	if (!strcasecmp(action, "deny"))
		tmp->action = ACTION_DENY;
	if (!strcasecmp(action, "drop"))
		tmp->action = ACTION_DROP;

	if (!strcasecmp(level, "base"))
		tmp->level = LEVEL_BASE;
	if (!strcasecmp(level, "monitor"))
		tmp->level = LEVEL_MONITOR;
	if (!strcasecmp(level, "manager"))
		tmp->level = LEVEL_MANAGER;
	if (!strcasecmp(level, "all"))
		tmp->level = LEVEL_ALL;

	tmp->aclname = strdup(aclname);
	tmp->next = NULL;

	if (last == NULL)	/* first */
		firstacc = tmp;
	else
		last->next = tmp;	
}

/* parse the config file */
void readconf (void)
{
	FILE	*conf;
	char	buf[256], fn[256], arg1[128], arg2[128], arg3[128];

	snprintf (fn, sizeof(fn), "%s/etc/upsd.conf", BASEPATH);

	conf = fopen (fn, "r");

	/* lacking the config file is not a fatal error */
	if (conf == NULL)
		return;

	while (fgets (buf, sizeof(buf), conf)) {

		/* UPS <upsname> <statefile> */
		if (!strncmp(buf, "UPS", 3)) {
			sscanf (buf, "%*s %s %s", arg1, arg2);
			addups (arg2, arg1);
		}

		/* ACL <aclname> <ip block> */
		if (!strncmp(buf, "ACL", 3)) {
			sscanf (buf, "%*s %s %s", arg1, arg2);
			addacl (arg1, arg2);
		}

		/* ACCESS <action> <level> <aclname> */
		if (!strncmp(buf, "ACCESS", 6)) {
			sscanf (buf, "%*s %s %s %s", arg1, arg2, arg3);
			addaccess (arg1, arg2, arg3);
		}
	}
		
	fclose (conf);
}

/* answer incoming tcp connections */
void answertcp()
{
	int	acc, clen;
	struct	sockaddr_in client;
	char	logbuf[256];
	ctype	*tmp, *last;

	clen = sizeof (client);
	acc = accept (listenfd, (struct sockaddr *) &client, &clen);

	if (acc < 0)
		return;

	if (!checkaccess (&client, LEVEL_BASE)) {
		snprintf (logbuf, sizeof(logbuf),  "Rejecting TCP connection from %s\n", inet_ntoa (client.sin_addr));
		syslog (LOG_INFO, logbuf);
		close (acc);
		return;
	}

	snprintf (logbuf, sizeof(logbuf), "Connection from %s\n", inet_ntoa(client.sin_addr));
	syslog (LOG_INFO, logbuf);

	last = tmp = firstclient;

	while (tmp != NULL) {
		last = tmp;
		tmp = tmp->next;
	}

	tmp = malloc (sizeof(ctype));
	tmp->addr = strdup(inet_ntoa(client.sin_addr));
	tmp->fd = acc;
	memcpy (&tmp->sock, &client, sizeof(struct sockaddr_in));
	tmp->rqpos = 0;
	bzero (tmp->rq, sizeof(tmp->rq));
	tmp->next = NULL;

	if (last == NULL)
		firstclient = tmp;
	else
		last->next = tmp;
}

/* read tcp messages and handle them */
void readtcp (ctype *client)
{
	char	buf[256];
	int	i, ret;

	bzero (buf, sizeof(buf));
	ret = read (client->fd, buf, sizeof(buf));

	if (ret < 1) {
		syslog (LOG_INFO, "Host %s disconnected\n", client->addr);

		shutdown (client->fd, 2);
		close (client->fd);
		delclient (client);
		return;
	}

	/* if an overflow will happen, then clear the queue */
	if ((ret + client->rqpos) >= sizeof(client->rq)) {
		bzero (client->rq, sizeof(client->rq));
		client->rqpos = 0;
	}

	/* fragment handling code */

	for (i = 0; i < ret; i++) {
		/* add to the receive queue one by one */
		client->rq[client->rqpos++] = buf[i];

		/* parse on linefeed ('blah blahCRLF') */
		if (buf[i] == 10) {	/* LF */
			currclient = client;	/* enable tcp replies */
			parse (client->rqpos, client->rq, &client->sock);
			currclient = NULL;	/* disable */
			
			/* reset queue */
			client->rqpos = 0;
			bzero (client->rq, sizeof(client->rq));
		}
	}
}

/* service requests and check on new data */
void mainloop (void)
{
	fd_set	rfds;
	struct	timeval	tv;
	struct	sockaddr_in from;
	int	res, fromlen, maxfd;
	char	buf[256];
	ctype	*tmpcli;

	FD_ZERO (&rfds);
	FD_SET (udpfd, &rfds);
	FD_SET (listenfd, &rfds);
	
	tv.tv_sec = 2;
	tv.tv_usec = 0;

	maxfd = (udpfd > listenfd) ? udpfd : listenfd;

	/* scan through clients and add to FD_SET */
	for (tmpcli = firstclient; tmpcli != NULL; tmpcli = tmpcli->next) {
		FD_SET (tmpcli->fd, &rfds);
		if (tmpcli->fd > maxfd)
			maxfd = tmpcli->fd;
	}
	
	res = select (maxfd + 1, (void *) &rfds, (void *) NULL,
		     (void *) NULL, &tv);

	if (res) {
		if (FD_ISSET (udpfd, &rfds)) {
			fromlen = sizeof(from);
			bzero (buf, sizeof(buf));
			res = recvfrom (udpfd, buf, sizeof(buf), 0, 
		        	       (struct sockaddr *) &from, &fromlen);

			if (res > 0)
				parse (res, buf, &from);
		}

		if (FD_ISSET (listenfd, &rfds))
			answertcp();

		/* scan clients for activity */
		for (tmpcli = firstclient; tmpcli != NULL; tmpcli = tmpcli->next)
			if (FD_ISSET (tmpcli->fd, &rfds))
				readtcp(tmpcli);
	}

	updateall();
}

/* close ttys and become a daemon */
void background()
{
	int	pid;

	if ((pid = fork()) < 0) {
		perror ("Unable to enter background");
		exit (1);
	}

	close (0);
	close (1);
	close (2);

	if (pid != 0) 
		exit (0);		/* parent */

	/* child */

	syslog (LOG_INFO, "Startup successful");
}

/* change uid/gid if running as root */
void droproot ()
{
	setgid(RUN_AS_GID);

	if (getuid() == 0)
		if (setuid(RUN_AS_UID) == -1) {
			perror ("setuid");
			exit (1);
		}
}

#ifdef HAVE_SHMAT
/* detach from shared memory if necessary */
void detach_shm()
{
	upstype	*temp = firstups;

	while (temp != NULL) {
		if (temp->shmid >= 0) {
			/* mark for deletion */
			shmctl (temp->shmid, IPC_RMID, NULL); 
			shmdt ((char *)temp->info);	/* detach */
		}
		temp = temp->next;
	}	
}
#endif HAVE_SHMAT

void help (char *progname)
{
	printf ("usage: %s [-p portnum] [-t tcpport]\n", progname);
	printf ("\n");
	printf ("-p sets both port numbers (UDP, TCP)\n");
	printf ("-t overrides port number for TCP only\n");

	exit (1);
}

/* basic signal setup to ignore SIGPIPE */
void setupsignals()
{
	struct sigaction sa;
	sigset_t sigmask;

	/* ignore SIGPIPE */
	sa.sa_handler = SIG_IGN;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGPIPE, &sa, NULL);
}

int main (int argc, char **argv)
{
	int	i, complained = 0;
	char	upsname[16];

	printf ("Smart UPS Tools upsd %s\n", UPS_VERSION);

	while ((i = getopt(argc, argv, "+p:t:")) != EOF) {
		switch (i) {
			case 'p':
				udpport = atoi(optarg);
				tcpport = atoi(optarg);
				break;
			case 't':
				tcpport = atoi(optarg);
				break;
			default:
				help (argv[0]);
				break;
		}
	}

	argc -= optind;
	argv += optind;

	setupsignals();
	setupudp();
	setuptcp();

	readconf();

	droproot();		

	if ((argc < 1) && (upsnum == 0)) {
		printf ("No state filenames specified!\n");
		exit (1);
	}

	openlog ("upsd", LOG_PID, LOG_FACILITY);

	/* allow adding systems from the cmd line without custom names */
	for (i = 0; i < argc; i++) {
		if (complained == 0) {
			complained = 1;
			printf ("Use of command line to list state files is depreciated.\n");
			printf ("See the config file for examples of how to add them there.\n");
		}		

		snprintf (upsname, sizeof(upsname), "ups-%i", i);
		addups (argv[i], upsname);
	}

 	background();

	for (;;)
		mainloop();

	return (0);	
}
