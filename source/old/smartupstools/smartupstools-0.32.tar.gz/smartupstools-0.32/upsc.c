/* upsc - an example program showing how to use fetch to get ups data 

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "upsfetch.h"

int main(int argc, char *argv[]) 
{
	upsinfo	ups;

	if (argc < 2) {
		printf ("usage: %s <host>\n", argv[0]);
		exit(1);
	}

	if (fetch (argv[1], &ups) > 0) {
		printf ("    model: %s\n", ups.model);
		printf ("   serial: %s\n", ups.serial);
		printf ("  mfgdate: %s\n", ups.mfgdate);
		printf ("  battchg: %s\n", ups.battchg);
		printf ("  upsload: %s\n", ups.upsload);
		printf ("  battcap: %s\n", ups.battcap);
		printf ("  utility: %s\n", ups.utility);
		printf ("   status: %s\n", ups.status);
		printf ("  linemin: %s\n", ups.linemin);
		printf ("  linemax: %s\n", ups.linemax);
		printf ("  upstemp: %s\n", ups.upstemp);
		printf ("     freq: %s\n", ups.freq);
		printf (" selftest: %s\n", ups.selftest);
		printf ("retthresh: %s\n", ups.retthresh);
		printf (" upsident: %s\n", ups.upsident);
		printf (" almdelay: %s\n", ups.almdelay);
		printf ("  lowxfer: %s\n", ups.lowxfer);
		printf (" highxfer: %s\n", ups.highxfer);
		printf ("\n");
		printf ("capabilities: \n");
		printf (" selftest: %s\n", ups.c_selftest);
		printf ("retthresh: %s\n", ups.c_retthresh);
		printf (" almdelay: %s\n", ups.c_almdelay);
		printf ("  lowxfer: %s\n", ups.c_lowxfer);
		printf (" highxfer: %s\n", ups.c_highxfer);
		printf ("  outvolt: %s\n", ups.c_outvolt);
		printf ("    grace: %s\n", ups.c_grace);
		printf (" battwarn: %s\n", ups.c_battwarn);
		printf (" retdelay: %s\n", ups.c_retdelay);
		printf ("     sens: %s\n", ups.c_sens);
		exit (0);
	}

	printf ("UPS communications failure: %s\n", upserrstring(upserror));

	return (1);
}
