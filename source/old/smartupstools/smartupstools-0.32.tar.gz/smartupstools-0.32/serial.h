/* serial.h - prototypes for (future) "black box" serial modules */

void init_serial (char *port);
void recv_from_ups (char *answer, int anslen);
void send_to_ups (char data);
void close_serial ();                   
