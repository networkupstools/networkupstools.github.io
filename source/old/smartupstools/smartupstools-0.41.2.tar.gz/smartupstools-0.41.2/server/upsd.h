/* upsd.h - support structures and other minor details

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

/* netvars[] - map text strings from the network to internal identifiers */

struct {
	char	*name;
	int	type;
}	netvars[] =
{
	{ "MFR",	INFO_MFR	},
	{ "MODEL",	INFO_MODEL	},
	{ "SERIAL",	INFO_SERIAL	},
	{ "UTILITY",	INFO_UTILITY	},
	{ "BATTPCT",	INFO_BATTPCT	},
	{ "STATUS",	INFO_STATUS	},
	{ "UPSTEMP",	INFO_UPSTEMP	},
	{ "ACFREQ",	INFO_ACFREQ	},
	{ "LOADPCT",	INFO_LOADPCT	},
	{ "LOWXFER", 	INFO_LOWXFER	},
	{ "HIGHXFER",	INFO_HIGHXFER	},
	{ "AMBHUMID",	INFO_AMBHUMID	},
	{ "AMBTEMP",	INFO_AMBTEMP	},
	{ NULL,		INFO_UNUSED	}
};

void do_sendver (struct sockaddr_in *dest, char *arg);
void do_sendans (struct sockaddr_in *dest, char *arg);
void do_sendhelp (struct sockaddr_in *dest, char *arg);
void do_listvars (struct sockaddr_in *dest, char *arg);
void do_logout (struct sockaddr_in *dest, char *arg);
void do_login (struct sockaddr_in *dest, char *arg);
void do_password (struct sockaddr_in *dest, char *arg);

/* netcmds[] - map net commands to functions */

struct {
	char	*name;
	void	(*func)(struct sockaddr_in *dest, char *arg);
}	netcmds[] =
{
	{ "VER",	do_sendver		},
	{ "REQ",	do_sendans		},
	{ "HELP",	do_sendhelp		},
	{ "LISTVARS",	do_listvars		},
	{ "LOGOUT", 	do_logout		},
	{ "LOGIN",	do_login		},
	{ "PASSWORD",	do_password		},
	{ NULL,		(void(*)())(NULL)	}
};
