/* protocol.h - common values used in the UDP packets sent to/from upsd 
 *
 * Russell Kroll <rkroll@exploits.org>
 */

#define BATTCAPREQ      1
#define BATTCAPANS      2
#define MODELREQ        3
#define MODELANS        4  
#define UTILITYREQ	5
#define UTILITYANS	6
#define LOADREQ		7
#define LOADANS		8
#define STATUSREQ	9
#define STATUSANS	10
#define LINEMINREQ	11
#define LINEMINANS	12
#define LINEMAXREQ	13
#define LINEMAXANS	14
#define UPSTEMPREQ	15
#define UPSTEMPANS	16
#define	FREQREQ		17
#define FREQANS		18
#define UNKNOWNANS      255

/* this is how we keep the versions straight protocol-wise */

#define PROTOMAGIC	"UPSMON1"

typedef struct {
	char	magic[8];
	char	passwd[16];
	int	command;
	char	value[16];
        char    dummy[2];
}	pkttype;
