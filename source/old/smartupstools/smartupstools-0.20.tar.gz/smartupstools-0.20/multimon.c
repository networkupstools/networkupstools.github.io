/*
 * multimon - CGI program to monitor several UPSes from one page
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* bit values that get OR'ed later */
#define UPS_CALIBRATION	1
#define UPS_SLEEPING	2
#define UPS_UNKNOWN	4
#define UPS_ONLINE	8
#define UPS_ONBATT	16
#define UPS_UNKNOWN2	32
#define UPS_BATTLOW	64
#define UPS_CHARGING	128

int fetch(char *host, char *request, char *answer, int anslen, char *passwd);

void noresp()
{
	printf ("<TD BGCOLOR=\"#FF0000\">Unavailable</TD>\n");
}

void getinfo (char *addr, char *desc)
{
	char	retbuf[256], color[16], stattxt[128];
	long	status;
	float	tempf;

	printf ("<TR ALIGN=CENTER>\n");
	printf ("<TD BGCOLOR=\"#00FFFF\"><A HREF=\"/cgi-bin/upsstats.cgi?host=%s\">%s</A></TD>\n", addr, desc);

	if (fetch (addr, "model", retbuf, sizeof(retbuf), ""))
		printf ("<TD BGCOLOR=\"#00FFFF\">%s</TD>\n", retbuf);
	else {
		printf ("<TD COLSPAN=6 BGCOLOR=\"#FF0000\">No response from system!</TD></TR>\n");
		return;
	}

	if (fetch (addr, "status", retbuf, sizeof(retbuf), "")) {
		strcpy (stattxt, "");
		strcpy (color, "#FFFF00");
		status = strtol (retbuf, 0, 16);
		if (status & UPS_CALIBRATION) 
			strcat (stattxt, "CALIBRATION ");
		if (status & UPS_SLEEPING)
			strcat (stattxt, "SLEEPING ");
		if (status & UPS_UNKNOWN)
			strcat (stattxt, "UNKNOWN ");
		if (status & UPS_ONLINE) {
			strcat (stattxt, "ONLINE ");
			strcpy (color, "#00FF00");
		}
		if (status & UPS_ONBATT) {
			strcat (stattxt, "ON BATTERY ");
			strcpy (color, "#FF0000");
		}
		if (status & UPS_BATTLOW) {
			strcat (stattxt, "BATTERY LOW ");
			strcpy (color, "#FF0000");
		}
		if (status & UPS_CHARGING) {
			strcat (stattxt, "BATTERY CHARGING ");
			strcpy (color, "#FFFF00");
		}
		if (status == 0)
			noresp();
		else
			printf ("<TD BGCOLOR=\"%s\">%s</TD>\n", color, stattxt);
	}
	else
		noresp();

	if (fetch (addr, "battcap", retbuf, sizeof(retbuf), "")) 
		printf ("<TD BGCOLOR=\"#00FF00\">%s %%</TD>\n", retbuf);
	else
		noresp();

	if (fetch (addr, "utility", retbuf, sizeof(retbuf), "")) 
		printf ("<TD BGCOLOR=\"#00FF00\">%s VAC</TD>\n", retbuf);
	else
		noresp();

	if (fetch (addr, "upsload", retbuf, sizeof(retbuf), "")) 
		printf ("<TD BGCOLOR=\"#00FF00\">%s %%</TD>\n", retbuf);
	else
		noresp();

	if (fetch (addr, "upstemp", retbuf, sizeof(retbuf), "")) {
		tempf = (strtod (retbuf, 0) * 1.8) + 32;
		printf ("<TD BGCOLOR=\"#00FF00\">%.1f �F</TD>\n", tempf); 
	}
	else
		noresp();

	printf ("</TR>\n");
}

void main() 
{
	FILE	*conf;
	time_t	tod;
	char	buf[256], fn[256], addr[256], desc[256], timestr[256];

	printf ("Content-type: text/html\n");
	printf ("\n");

	printf ("<HTML>\n");
	printf ("<HEAD><TITLE>Multimon: UPS Status Page</TITLE></HEAD>\n");
	printf ("<BODY BGCOLOR=\"#FFFFFF\">\n");
	printf ("<TABLE BGCOLOR=\"#50A0A0\" ALIGN=CENTER>\n");
	printf ("<TR><TD>\n");
	printf ("<TABLE CELLPADDING=5>\n");
	printf ("<TR>\n");
	
	time (&tod);
	strftime (timestr, 100, "%a %b %d %X %Z %Y", localtime(&tod));
	printf ("<TH COLSPAN=7 BGCOLOR=\"#60B0B0\"><FONT SIZE=+2>Smart UPS Tools: Multimon</FONT><BR>%s</TH>\n", timestr);
	printf ("</TR>\n"); 
	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TH COLSPAN=1>System</TH>\n");
	printf ("<TH COLSPAN=1>Model</TH>\n");
	printf ("<TH COLSPAN=1>Status</TH>\n");
	printf ("<TH COLSPAN=1>Batt Cap</TH>\n");
	printf ("<TH COLSPAN=1>Utility</TH>\n");
	printf ("<TH COLSPAN=1>UPS Load</TH>\n");
	printf ("<TH COLSPAN=1>Temperature</TH>\n");
	printf ("</TR>\n"); 

	/* ups status */

	sprintf (fn, "%s/hosts.conf", BASEPATH);
	conf = fopen (fn, "r");

	while (fgets (buf, sizeof(buf), conf)) 
		if (strncmp("MONITOR", buf, 4) == 0) {
			sscanf (buf, "%*s %s %s", addr, desc);
			getinfo (addr, desc);
		}

	fclose (conf);
	
	printf ("</TABLE>\n"); 
	printf ("</TD></TR>\n"); 
	printf ("</TABLE></BODY></HTML>\n");
}
