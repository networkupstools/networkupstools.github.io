/* readconf - common function for reading the ups.conf */

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void readconf(char *configfile, char *passwd, char *upsport, char *shutdown)
{
	FILE	*config;
	char	*confbuf;

	if ((confbuf = calloc(255, sizeof(char))) == NULL) {
		perror ("calloc");
		exit (0);
	}

	if ((config = fopen(configfile, "r")) == NULL) {
		char	errmsg[256];
		sprintf (errmsg, "Can't open %s", configfile);
		perror (errmsg);
		exit (0);
	}

	while (fgets (confbuf, 255, config)) {
		if (strncmp ("PASS", confbuf, 4) == 0) {
			sscanf (confbuf, "%*s %s", passwd);
		}
		if (strncmp ("UPSPORT", confbuf, 7) == 0) {
			sscanf (confbuf, "%*s %s", upsport);
		}
		if (strncmp ("SHUTDOWN", confbuf, 4) == 0) {
			sscanf (confbuf, "%*s %s", shutdown);
		}
	}
	
	fclose (config);
}
