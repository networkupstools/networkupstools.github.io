/*
 * upsmon - monitor power status over the 'net (talks to upsd via UDP)
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 * upsmon is the process that will bring your machine down gracefully when
 * your UPS has run on battery for a good while and has finally reached the
 * dreaded "low battery" condition.
 *
 * It needs to run as root to accomplish the shutdown, but you can run it
 * as a normal user to see what will happen (including the walls) while
 * testing.
 *
 * Expect lots of wall-like messages on every tty when the UPS changes states.
 */

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <time.h>

/* bit values that get OR'ed later */
#define UPS_CALIBRATION	1
#define UPS_SLEEPING	2
#define UPS_UNKNOWN	4
#define UPS_ONLINE	8
#define UPS_ONBATT	16
#define UPS_UNKNOWN2	32
#define UPS_BATTLOW	64
#define UPS_CHARGING	128

#define ALERTTIME	30		/* after this many seconds on battery,
					   do something about it */

extern void wall();
int fetch(char *host, char *request, char *answer, int anslen, char *passwd);
void readconf(char *configfile, char *passwd, char *upsport, char *shutdown);

	char	passwd[16], upsport[16], shutdowncmd[16];

void notify(char *notice)
{
	wall (notice, 1);
}

void nowonbattery()
{
	syslog (LOG_NOTICE, "UPS is on battery");	
	notify ("UPS is on battery\n");
}

void notonbattery()
{
	syslog (LOG_NOTICE, "UPS is no longer on battery");
	notify ("UPS is no longer on battery\n");
}

void flee()
{
	syslog (LOG_CRIT, "Initiating automatic power-fail shutdown");
	notify ("Initiating automatic power-fail shutdown\n");

	if (getuid() != 0) {
		syslog (LOG_ALERT, "Not root, unable to shutdown system");
		exit (1);
	}
		
	notify ("Auto logout and shutdown in 15 seconds!\n");
	sleep (15);
	
	system (shutdowncmd);
	exit (1);
}

void become_daemon()
{
	int	pid;
	
	close (0);
	close (1);
	close (2);

	if ((pid = fork()) < 0) {
		perror ("Unable to fork");
		exit (1);
	}
	if (pid != 0) exit (0);
	syslog (LOG_INFO, "Ready to handle UPS requests");
}

void onbattlongtime()
{
	char	nottmp[80];

	syslog (LOG_ALERT, "UPS has been on battery for more than %i seconds",
		ALERTTIME);

	sprintf (nottmp, "Prolonged power outage (longer than %i seconds)\n", 
		 ALERTTIME);

	notify (nottmp);
}

void main(int argc, char *argv[])  
{
	char	answer[256];
	char	monhost[256];
	int	status;
	int	on_battery = 0, noresp = 0;
	int	onbatttime = 0, longtimewarn = 0;
	struct	timeval		tv;
	struct	timezone	tz;
	char	configfile[128];
	
	printf ("upsmon by Russell Kroll <rkroll@exploits.org>\n");

	if (argc != 2) {
		printf ("Usage: %s <host to monitor>     Example: %s 10.2.254.1\n", argv[0], argv[0]);
		exit (1);
	}

	sprintf (configfile, "%s/ups.conf", BASEPATH);
	readconf (configfile, passwd, upsport, shutdowncmd);

	if (strlen(shutdowncmd) == 0) {
		printf ("SHUTDOWNCMD must be configured in %s\n", configfile);
		exit (1);
	}

	if (strlen(passwd) == 0) {
		printf ("PASSWD must be configured in %s\n", configfile);
		exit (1);
	}

	/* upsport isn't used by upsmon .. */

	strcpy (monhost, argv[1]);

	printf ("Monitoring UPS on %s\n", monhost);
	become_daemon();
	
	openlog ("upsmon", LOG_PID, LOG_INFO);
	syslog (LOG_INFO, "Monitoring UPS on %s", monhost);

	while (1) {
		if (fetch (monhost, "status", answer, sizeof(answer),
		    passwd)) {
			if (noresp == 1) {	/* ups is back */
				noresp = 0;
				syslog (LOG_INFO, "Communication with UPS re-established");
			}

			status = strtol (answer, 0, 16);

			if (status & UPS_ONBATT) {	/* on battery */
				gettimeofday(&tv, &tz);
		
				if ((onbatttime != 0) && (longtimewarn == 0) &&
				   ((tv.tv_sec - onbatttime) > ALERTTIME)) {
					onbattlongtime();
					longtimewarn = 1;
				}					

				if (!on_battery) {
					on_battery = 1;
					nowonbattery();
					onbatttime = tv.tv_sec;
				}
			}	/* not on battery currently */
			else
				if (on_battery) {
					on_battery = 0;
					notonbattery();
					onbatttime = 0;
					longtimewarn = 0;
				}

			if ((status & UPS_BATTLOW) && (status & UPS_ONBATT))
				flee();

		}	/* fetch failed */

		else {
			if (noresp == 0) {	/* ups isn't there */
				syslog (LOG_INFO, "Communication with UPS lost");
				noresp = 1;
			}
		}
		sleep (5);
	}
}
