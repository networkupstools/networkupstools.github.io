/*
 * upsc - an example program showing how to use fetch to get ups data 
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 *  to use: upsc <host> <variable>
 *  example: upsc upsserver model 
 *   output: SMART-UPS 700
 *
 */

#include <stdio.h>

int fetch(char *host, char *request, char *answer, int anslen, char *passwd);

void main(int argc, char *argv[]) 
{
	char	answer[128];

	if (argc != 3) {
		printf ("usage: %s <host> <variable>\n", argv[0]);
		exit(-1);
	}

	if (fetch (argv[1], argv[2], answer, sizeof(answer), "")) {
		printf ("%s\n", answer);
		exit (0);
	}

	printf ("No response from %s", argv[1]);
}
