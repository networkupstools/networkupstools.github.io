/*
 * upsd - serial UPS monitoring daemon and status server
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 * upsd's job is to chat with the UPS to see how things are, and keep
 * track of the state internally.  When queried by a valid client, it then
 * passes along the requested information in the form of a UDP packet.
 *
 * Many different upsmon processes can monitor a single upsd, allowing 
 * the "multiple boxes on a single UPS" scenario to work rather well.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h> 
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/termios.h>
#include <signal.h>
#include <unistd.h>
#include <syslog.h>

/* UDP protocol */
#include "protocol.h"

/* Serial protocol */
#define GO_SMART 'Y'
#define REQ_MODEL 0x01
#define REQ_SERIAL 'n'
#define REQ_LOAD 'P'
#define REQ_BATTLVL 'f'
#define REQ_MFGDATE 'm'
#define REQ_UPSTEMP 'C'
#define REQ_UTILITY 'O'
#define REQ_STATUS 'Q'
#define REQ_LINEMIN 'N'
#define REQ_LINEMAX 'M'
#define REQ_FREQ 'F'

	pkttype			pkt, reppkt;
	int			recvsockfd;
	fd_set			rfds;
	struct	sockaddr_in	rcv_addr, from;
	int			n, retval, fromlen = sizeof(from), res, port;
	struct	timeval		tv;
	struct	termios		oldtio, newtio;
	char			in, out, buflen, resp[80], model[80],
				serial[80], mfgdate[80],  upsload[80], battcap[80],
				utility[80], status[80], linemin[80],
				linemax[80], upstemp[80], freq[80];
static	sigset_t		sigmask;
	int			fakelow = 0, fakeonbatt = 0;
	char			passwd[16], upsport[16], shutdowncmd[16];

void readconf(char *configfile, char *passwd, char *upsport, char *shutdown);

void initudp()
{
	if ((recvsockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror ("socket() failure");
		exit (1);
	}

	bzero((char *) &rcv_addr, sizeof(rcv_addr));
	rcv_addr.sin_family = AF_INET;
	rcv_addr.sin_port = htons(3301);

	res = (bind(recvsockfd, (struct sockaddr *)&rcv_addr, 
	       sizeof(rcv_addr)));

	if (res) {
		perror ("bind failure");
		exit (1);
	}

	return;
}

void notty()
{
	perror ("Serial port open timed out");

	/* It would be great if someone could tell me why the open blocks
         * on BSD/OS systems if you don't "prime" the port with tip first.
	 * It would be even better if someone came up with a fix ...
	 */

#ifdef __bsdi__
	printf ("BSD/OS users: try using tip to connect to the port at 2400 bps first\n");
	printf ("Example: tip -2400 ttyS1\n");
#endif

	exit (1);
}

void sig_usr1 (int sig)
{
	syslog (LOG_INFO, "SIGUSR1 caught");
	if (fakelow == 0) {
		syslog (LOG_INFO, "Fake low battery is ON");
		fakelow = 1;
		return;
	}
	syslog (LOG_INFO, "Fake low battery is OFF");
	fakelow = 0;
	return;
}

void sig_usr2 (int sig)
{
	syslog (LOG_INFO, "SIGUSR2 caught");
	if (fakeonbatt == 0) {
		syslog (LOG_INFO, "Fake on battery is ON");
		fakeonbatt = 1;
		return;
	}
	syslog (LOG_INFO, "Fake on battery is OFF");
	fakeonbatt = 0;
	return;
}

void signal_setup()
{
        struct  sigaction sa;

        sigemptyset(&sigmask);
        sigaddset(&sigmask, SIGHUP);
        sigaddset(&sigmask, SIGUSR1);
        sigaddset(&sigmask, SIGUSR2);

#define SIGNAL(s,handler) { \
                sa.sa_handler = handler; \
                if (sigaction(s, &sa, NULL) < 0) { \
			perror ("sigaction failure"); \
                        exit(1); \
                } \
        }

        sa.sa_mask = sigmask;
        sa.sa_flags = 0;
        SIGNAL(SIGUSR1,sig_usr1);
        SIGNAL(SIGUSR2,sig_usr2);
}

void inittty()                        /* from apcd */
{
	signal (SIGALRM, notty); 
	alarm (1);
        port = open("/dev/ups", O_RDWR | O_NOCTTY);
        if (port < 1) {
		char	errmsg[64];
		sprintf (errmsg, "Unable to open %s", upsport);
		perror (errmsg);
                exit(0);
        }
	signal (SIGALRM, SIG_IGN);

        tcgetattr(port, &oldtio);
        newtio.c_cflag = B2400 | CS8 | CLOCAL | CREAD;
        newtio.c_iflag = IGNPAR;
        newtio.c_oflag = 0;
        newtio.c_lflag = 0;
        newtio.c_cc[VMIN] = 1;
        newtio.c_cc[VTIME] = 0;
        tcflush(port, TCIFLUSH);
        tcsetattr(port, TCSANOW, &newtio);
}

void sendtoups(char tosend)
{
        out = tosend;
        tcflush(port, TCIFLUSH);
        write (port, &out, 1);

        return;
}

void getresp()
{
        int	buflen = 0;

        while (1) {
                read (port, &in, 1);
                resp[buflen++] = in;
                if (resp[buflen-1] == 10) {
                        resp[buflen-2] = 0;
                        return;
                }
        }
        return;
}               


void sendback(int reply, char *val)

{
	strcpy(reppkt.magic, PROTOMAGIC);
	strcpy(reppkt.passwd, "");
	reppkt.command = reply;
	strcpy(reppkt.value, val);

	res = sendto(recvsockfd, &reppkt, sizeof(reppkt), 0, 
	      (struct sockaddr *) &from, sizeof(from));

}

void parseudp() 
{
	if (strcmp(PROTOMAGIC, pkt.magic)) {
		sendback (UNKNOWNANS, "Huh?");
		return;
	}

	switch (pkt.command) {
		case BATTCAPREQ: sendback (BATTCAPANS, battcap); break;
		case MODELREQ: sendback (MODELANS, model); break;
		case UTILITYREQ: sendback (UTILITYANS, utility); break;
		case LOADREQ: sendback (LOADANS, upsload); break;
		case STATUSREQ: sendback (STATUSANS, status); break;
		case LINEMINREQ: sendback (LINEMINANS, linemin); break;
		case LINEMAXREQ: sendback (LINEMAXANS, linemax); break;
		case UPSTEMPREQ: sendback (UPSTEMPANS, upstemp); break;
		case FREQREQ: sendback (FREQANS, freq); break;
		default: sendback (UNKNOWNANS, "Huh?");
	}

	return;
}

void getupsstats()
{
	sendtoups (REQ_LINEMIN);
	getresp();
	strcpy (linemin, resp);

	sendtoups (REQ_LINEMAX);
	getresp();
	strcpy (linemax, resp);

	sendtoups (REQ_UPSTEMP);
	getresp();
	strcpy (upstemp, resp);

	sendtoups (REQ_FREQ);
	getresp();
	strcpy (freq, resp);

/*	sendtoups (REQ_MINVOLT);
	getresp();
	strcpy (voltmin, resp); */

	sendtoups (REQ_LOAD);
	getresp();
	strcpy (upsload, resp);

	sendtoups (REQ_BATTLVL);
	getresp();
	strcpy (battcap, resp);

	sendtoups (REQ_UTILITY);
	getresp();
	strcpy (utility, resp);

	sendtoups (REQ_STATUS);
	getresp();
	strcpy (status, resp);
	if (fakeonbatt == 1) {
		strcpy (status, "10"); 
	}
	if (fakelow == 1) {
		strcpy (status, "50"); 
	} 
}

void become_daemon()
{
	int	pid;
	
	printf ("Entering the background...\n");

	close (0);
	close (1);
	close (2);

	if ((pid = fork()) < 0) {
		perror ("Unable to fork");
		exit (1);
	}
	if (pid != 0) exit (0);
	syslog (LOG_INFO, "Ready to handle UPS requests");
}

int main()
{
	char	configfile[128];

	sprintf (configfile, "%s/ups.conf", BASEPATH);

	strcpy (upsport, "");
	strcpy (passwd, "");
	strcpy (shutdowncmd, "");

	readconf(configfile, passwd, upsport, shutdowncmd);

	if (getuid() == 0) {
		printf ("Giving up root privileges...\n");
		seteuid(65534);
	}

	if (strlen(upsport) == 0) {
		printf ("UPSPORT must be configured in %s\n", configfile);
		exit (1);
	}

	if (strlen(passwd) == 0) {
		printf ("PASSWD must be configured in %s\n", configfile);
		exit (1);
	}

	/* shutdown isn't used by upsd .. */

	openlog ("upsd", LOG_PID, LOG_INFO);

	initudp();

	inittty();

	become_daemon();

	signal_setup();

	sendtoups (GO_SMART);
	getresp();

	sendtoups (REQ_MODEL);
	getresp();
	strcpy (model, resp);

	sendtoups (REQ_SERIAL);
	getresp();
	strcpy (serial, resp);

	sendtoups (REQ_MFGDATE);
	getresp();
	strcpy (mfgdate, resp);

	getupsstats();

	for ( ; ; ) {
		FD_ZERO(&rfds);
		FD_SET(recvsockfd, &rfds);

		tv.tv_sec = 0;
		tv.tv_usec = 250;

		sigprocmask(SIG_BLOCK, &sigmask, NULL);
		retval = select(recvsockfd+1, &rfds, NULL, NULL, &tv);
		sigprocmask(SIG_UNBLOCK, &sigmask, NULL);

		if ((retval) && (FD_ISSET(recvsockfd, &rfds))) {
			n = recvfrom (recvsockfd, &pkt, sizeof(pkt), 0, 
				     (struct sockaddr *)&from, &fromlen);

			parseudp();
		}
		else
		{
			getupsstats();
		}

	}

	close (recvsockfd);
	exit (0);
}
