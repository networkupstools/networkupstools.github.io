/*
 * upsimage - cgi program to create graphical ups information reports
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 * When used together, upsstats and upsimage create interesting looking web
 * pages with graphical representations of the battery capacity, utility
 * voltage, and UPS load. 
 *
 * This program utilizes the gd graphics library for snappy GIF generation.
 * I highly recommend this package for anyone doing similar graphics
 * "on the fly" in C.
 *
 * This binary needs to be installed some place where upsstats can find it.
 */

#include "gd1.2/gd.h"
#include "gd1.2/gdfontl.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

	char	monhost[128];
	char	cmd[16];

int fetch(char *host, char *request, char *answer, int anslen, char *passwd);

void parsearg(char var[255], char value[255]) 
{
	if (!strcmp(var, "host"))
		strncpy (monhost, value, sizeof(monhost));

	if (!strcmp(var, "display"))
		strncpy (cmd, value, sizeof(monhost));
}

void extractcgiargs() 
{
	char	ch;
	int	invar, invalue, handled, i;
	char	var[255], value[255];
	char	*query;

	invar = 1;
	invalue = 0;

	strcpy (value, "");
	strcpy (var, "");

	query = getenv ("QUERY_STRING");

	for (i = 0; i < strlen(query); i++) {
		ch = query[i];
		handled = 0;
		if (ch == '=') {
			invar = 0;
			invalue = 1;
			strcpy (value, "");
			handled = 1;
		}

		if (ch == '&') {
			invar = 1;
			invalue = 0;
			parsearg(var, value);
			strcpy (var, "");
			handled = 1;
		}

		if ((invar == 1) && (!handled)) {
			sprintf (var, "%s%c", var, ch);
		}

		if ((invalue == 1)  && (!handled)) {
			sprintf (value, "%s%c", value, ch);
		}
	}

	if (invalue) {
		value[strlen(value)] = 0;
		parsearg (var, value);
	}
}

void gifheader (void)
{
	printf ("Content-type: image/gif\n");
	printf ("Expires: Thu, 01 Jan 1998 00:00:00 GMT\n");
	printf ("\n");
}

void drawbattcap(char *battcaps) 
{
	gdImagePtr	im;
	int		green, black, white, grey, darkgrey;
	char		batttxt[16];
	int		battpos;
	double		battcap;

	battcap = strtod(battcaps, NULL);

	im = gdImageCreate (150, 350);

	black = gdImageColorAllocate (im, 0, 0, 0);
	green = gdImageColorAllocate (im, 0, 255, 0);
	white = gdImageColorAllocate (im, 255, 255, 255);
	grey = gdImageColorAllocate (im, 200, 200, 200);
	darkgrey = gdImageColorAllocate (im, 50, 50, 50);

	gdImageColorTransparent (im, grey);

	gdImageFilledRectangle (im, 0, 0, 150, 350, grey);

	gdImageString (im, gdFontLarge, 0, 0, "100", black);
	gdImageString (im, gdFontLarge, 0, 55, "80", black);
	gdImageString (im, gdFontLarge, 0, 115, "60", black);
	gdImageString (im, gdFontLarge, 0, 175, "40", black);
	gdImageString (im, gdFontLarge, 0, 235, "20", black);
	gdImageString (im, gdFontLarge, 0, 295, "0", black);

	gdImageFilledRectangle (im, 50, 0, 150, 300, green);

	gdImageLine (im, 50, 60, 150, 60, darkgrey);
	gdImageLine (im, 50, 120, 150, 120, darkgrey);
	gdImageLine (im, 50, 180, 150, 180, darkgrey);
	gdImageLine (im, 50, 240, 150, 240, darkgrey);
	gdImageLine (im, 50, 300, 150, 300, darkgrey);

	battpos = (300 - (battcap * 3));
	gdImageFilledRectangle (im, 75, battpos, 125, 300, black);

	sprintf (batttxt, "%.1f %%", battcap);
	gdImageString (im, gdFontLarge, 75, 320, batttxt, black);

	gifheader();
	gdImageGif (im, stdout);

	gdImageDestroy (im);
}

void noimage (void)
{
	gdImagePtr	im;
	int		black, grey;

	im = gdImageCreate (150, 350);
	grey = gdImageColorAllocate (im, 200, 200, 200);
	black = gdImageColorAllocate (im, 0, 0, 0);

	gdImageColorTransparent (im, grey);

	gdImageFilledRectangle (im, 0, 0, 150, 300, grey);

	gdImageString (im, gdFontLarge, 0, 0, "Data not available", black);

	gifheader();
	gdImageGif (im, stdout);

	gdImageDestroy (im);
}

void drawupsload(char *upsloads) 
{
	gdImagePtr	im;
	int		green, black, white, grey, darkgrey, red;
	char		loadtxt[16];
	int		loadpos;
	double		upsload;

	upsload = strtod(upsloads, NULL);

	im = gdImageCreate (150, 350);

	black = gdImageColorAllocate (im, 0, 0, 0);
	green = gdImageColorAllocate (im, 0, 255, 0);
	white = gdImageColorAllocate (im, 255, 255, 255);
	grey = gdImageColorAllocate (im, 200, 200, 200);
	darkgrey = gdImageColorAllocate (im, 50, 50, 50);
	red = gdImageColorAllocate (im, 255, 0, 0);

	gdImageColorTransparent (im, grey);

	gdImageFilledRectangle (im, 0, 0, 150, 350, grey);

	gdImageString (im, gdFontLarge, 0, 0, "125", black);
	gdImageString (im, gdFontLarge, 0, 55, "100", black);
	gdImageString (im, gdFontLarge, 0, 115, "75", black);
	gdImageString (im, gdFontLarge, 0, 175, "50", black);
	gdImageString (im, gdFontLarge, 0, 235, "25", black);
	gdImageString (im, gdFontLarge, 0, 295, "0", black);

	gdImageFilledRectangle (im, 50, 0, 150, 60, red);
	gdImageFilledRectangle (im, 50, 60, 150, 300, green); 

	gdImageLine (im, 50, 60, 150, 60, darkgrey);
	gdImageLine (im, 50, 120, 150, 120, darkgrey);
	gdImageLine (im, 50, 180, 150, 180, darkgrey);
	gdImageLine (im, 50, 240, 150, 240, darkgrey);
	gdImageLine (im, 50, 300, 150, 300, darkgrey);

	loadpos = (300 - ((upsload / 125) * 300));
	gdImageFilledRectangle (im, 75, loadpos, 125, 300, black);

	sprintf (loadtxt, "%.1f %%", upsload);
	gdImageString (im, gdFontLarge, 75, 320, loadtxt, black);

	gifheader();
	gdImageGif (im, stdout);

	gdImageDestroy (im);
}

void drawutility (char *utilitys) 
{
	gdImagePtr	im;
	int		green, black, white, grey, darkgrey, red;
	char		utiltxt[16];
	int		utilpos;
	double		utility;

	utility = strtod(utilitys, NULL);

	im = gdImageCreate (150, 350);

	black = gdImageColorAllocate (im, 0, 0, 0);
	green = gdImageColorAllocate (im, 0, 255, 0);
	white = gdImageColorAllocate (im, 255, 255, 255);
	grey = gdImageColorAllocate (im, 200, 200, 200);
	darkgrey = gdImageColorAllocate (im, 50, 50, 50);
	red = gdImageColorAllocate (im, 255, 0, 0);

	gdImageColorTransparent (im, grey);

	gdImageFilledRectangle (im, 0, 0, 150, 350, grey);

	gdImageString (im, gdFontLarge, 0, 0, "140", black);
	gdImageString (im, gdFontLarge, 0, 55, "130", black);
	gdImageString (im, gdFontLarge, 0, 115, "120", black);
	gdImageString (im, gdFontLarge, 0, 175, "110", black);
	gdImageString (im, gdFontLarge, 0, 235, "100", black);
	gdImageString (im, gdFontLarge, 0, 295, "90", black);

	gdImageFilledRectangle (im, 50, 0, 150, 300, green);
	gdImageFilledRectangle (im, 50, 0, 150, 48, red);
	gdImageFilledRectangle (im, 50, 222, 150, 300, red);

	gdImageLine (im, 50, 60, 150, 60, darkgrey);
	gdImageLine (im, 50, 120, 150, 120, darkgrey);
	gdImageLine (im, 50, 180, 150, 180, darkgrey);
	gdImageLine (im, 50, 240, 150, 240, darkgrey);
	gdImageLine (im, 50, 300, 150, 300, darkgrey);

	utilpos = (300 - (((utility - 90) / 50) * 300));
	gdImageFilledRectangle (im, 75, utilpos, 125, 300, black);

	sprintf (utiltxt, "%.1f VAC", utility);
	gdImageString (im, gdFontLarge, 75, 320, utiltxt, black); 

	gifheader();
	gdImageGif (im, stdout);

	gdImageDestroy (im);
}


int main ()
{
	char	upsval[16];

	extractcgiargs();

	if (!strcmp(cmd, "upsload")) {
		if (fetch (monhost, "upsload", upsval, sizeof(upsval), ""))
			drawupsload (upsval);
		else 
			noimage();
		return (0);
	}

	if (!strcmp(cmd, "battcap")) {
		if (fetch (monhost, "battcap", upsval, sizeof(upsval), ""))
			drawbattcap (upsval); 
		else
			noimage();
		return (0);
	}

	if (!strcmp(cmd, "utility")) {
		if (fetch (monhost, "utility", upsval, sizeof(upsval), ""))
			drawutility (upsval);
		else
			noimage();
		return (0);
	}

	printf ("Content-type: text/plain\n\n");
	printf ("Invalid request!\n");

	return (0);
}
