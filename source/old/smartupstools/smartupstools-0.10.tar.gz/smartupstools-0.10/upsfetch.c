/*
 * upsfetch - utility program to retrieve data from upsd via UDP 
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 * This source creates a handy object file that can be linked into other
 * programs for easy retrieval of common UPS parameters from the upsd
 * process.  It is used by upsc and upsmon.  
 *
 * See the upsc source and Makefile for examples of how to use this 
 * code in your own program.
 *
 * TODO: perrors need to be added, and errors need to be reported back
 *       gracefully
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>
#include <netdb.h>		/* hostent */
#include <unistd.h>

#include "protocol.h"

int fetch(char *host, char *request, char *answer, int anslen, char *passwd) {
	pkttype			pkt, recpkt;
	struct 	sockaddr_in	xmit_addr;
	int			udpfd, res, tries, retval;
	struct	sockaddr_in	dest_addr, from;
	int			one=1, fromlen = sizeof(from);
	fd_set			rfds;
	struct	timeval		tv;
	struct	hostent		*serverdns;

        if ((serverdns = gethostbyname(host)) == 
            (struct hostent *) NULL) {
                printf ("Unknown host: %s\n", host);
                return (0);
        }

	strcpy (pkt.magic, PROTOMAGIC);
	strcpy (pkt.passwd, passwd);

	pkt.command = 0;

	if (!strcmp("model", request))
		pkt.command = MODELREQ;

	if (!strcmp("battcap", request))
		pkt.command = BATTCAPREQ;

	if (!strcmp("utility", request))
		pkt.command = UTILITYREQ;

	if (!strcmp("upsload", request))
		pkt.command = LOADREQ;

	if (!strcmp("status", request))
		pkt.command = STATUSREQ;

	if (!strcmp("linemin", request))
		pkt.command = LINEMINREQ;

	if (!strcmp("linemax", request))
		pkt.command = LINEMAXREQ;

	if (!strcmp("upstemp", request))
		pkt.command = UPSTEMPREQ;

	if (!strcmp("outputfreq", request))
		pkt.command = FREQREQ;

	if (!pkt.command) {
		printf ("!Invalid request.\n");
		return (0);
	}

	for (tries = 0; tries <= 3; tries++) {
		udpfd = socket(AF_INET, SOCK_DGRAM, 0);

		if (udpfd < 0) {
			printf ("socket error: (%i) %s\n", errno, strerror(errno));
			return (0);
		}

		res = setsockopt(udpfd, SOL_SOCKET, SO_REUSEADDR, 
		      (const char *)&one, sizeof(int));

		if (res) {
			printf ("setsockopt failure: (%i) %s\n", errno, strerror(errno));
			return (0);
		}

		bzero((char *) &xmit_addr, sizeof(xmit_addr));
		xmit_addr.sin_family = AF_INET;
		xmit_addr.sin_addr.s_addr = INADDR_ANY;
		/* not setting sin_port just grabs the next one avail */

		res = (bind(udpfd, (struct sockaddr *) &xmit_addr, 
		       sizeof(xmit_addr)));

		if (res) { 
			printf ("bind failure: (%i) %s\n", errno, strerror(errno));
			return (0);
		}

		bzero((char *) &dest_addr, sizeof(dest_addr));

		(void) bcopy ((char *) serverdns->h_addr, (char *)
			     &dest_addr.sin_addr, serverdns->h_length);

		dest_addr.sin_family = AF_INET;
		dest_addr.sin_port = htons(3301);

	 	res = (sendto(udpfd, &pkt, 34, 0, (struct sockaddr *)&dest_addr, 
		       sizeof(dest_addr))); 

		if (res < 0) {
			printf ("sendto error: %i (%s)\n", errno, strerror(errno));
			return(0);
		}

		FD_ZERO(&rfds);
		FD_SET(udpfd, &rfds);

		tv.tv_sec = 1;
		tv.tv_usec = 500;

		retval = select (udpfd+1, &rfds, NULL, NULL, &tv);

		if (retval) 
			res = recvfrom(udpfd, &recpkt, sizeof(recpkt), 0, 
			      (struct sockaddr *) &from, &fromlen);

		if (res == sizeof(recpkt)) {
			strncpy (answer, recpkt.value, anslen);
			close (udpfd);
			return(1);
		}
	
		close(udpfd);
	}

	strncpy (answer, "", 0);
	return(0);
}
