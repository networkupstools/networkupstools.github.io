/*
 * upsstats - cgi program to generate the main ups info page
 *
 * Author: Russell Kroll <rkroll@exploits.org>
 *
 * To use: install the binary in a directory where CGI programs may be
 *         executed by your web server.  On many systems something like
 *         /usr/local/etc/httpd/cgi-bin will work nicely.  I recommend
 *         calling the binary "upsstats.cgi" in that directory.
 *
 *         Assuming a path like the above, the following link will suffice:
 *         <A HREF="/cgi-bin/upsstats.cgi">UPS Status</A>
 *
 *         This program assumes that upsimage.cgi will be in the same 
 *         directory.  The install-cgi target will take care of putting
 *         things in the right place if you set the paths properly in the
 *         Makefile.
 *
 */

/* change this if you are monitoring a remote host */
#define MONHOST "127.0.0.1"

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <time.h>

/* bit values that get OR'ed later */
#define UPS_CALIBRATION	1
#define UPS_SLEEPING	2
#define UPS_UNKNOWN	4
#define UPS_ONLINE	8
#define UPS_ONBATT	16
#define UPS_UNKNOWN2	32
#define UPS_BATTLOW	64
#define UPS_CHARGING	128

int fetch(char *host, char *request, char *answer, int anslen, char *passwd);

char *getdate()
{
	char	*timestr;
	time_t	tod;

	timestr = calloc (255, sizeof(char));
	time (&tod);
	strftime (timestr, 100, "%a %b %d %X %Z %Y", localtime(&tod));

	return (timestr);
}

void nocomm(char *monhost)
{
	printf ("Unable to communicate with the ups on %s\n", monhost);
	exit (0);
}

void main() 
{
	char	answer[256];
	char	monhost[256];
	int	status;
	double	tempf;

	strcpy (monhost, MONHOST);

	printf ("Content-type: text/html\n");
	printf ("Expires: Thu, 01 Jan 1998 00:00:00 GMT\n");
	printf ("\n");
	
	if (!fetch (monhost, "model", answer, sizeof(answer), "")) {
		nocomm(monhost);
	}

	printf ("<HTML><HEAD><TITLE>%s on %s</TITLE></HEAD>\n", answer, monhost);
	printf ("<BODY>\n");
	printf ("<CENTER><TABLE BORDER CELLSPACING=10 CELLPADDING=5>\n");
	printf ("<TR><TH>%s</TH>\n", getdate());
	printf ("<TH>Batt Cap</TH><TH>Utility</TH><TH>UPS Load</TH></TR>\n");
	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	printf ("Monitoring: %s\n", monhost);
	printf (" UPS Model: %s\n", answer);

	printf ("    Status: ");

	if (!fetch (monhost, "status", answer, sizeof(answer), "")) {
		printf ("Not available\n");
	}
	else {
		status = strtol (answer, 0, 16);
		if (status & UPS_CALIBRATION) 
			printf ("CALIBRATION "); 
		if (status & UPS_SLEEPING)
			printf ("SLEEPING "); 
		if (status & UPS_UNKNOWN)
			printf ("UNKNOWN "); 
		if (status & UPS_ONLINE)
			printf ("ONLINE "); 
		if (status & UPS_ONBATT) 
			printf ("ON BATTERY "); 
		if (status & UPS_BATTLOW) 
			printf ("BATTERY LOW "); 
		if (status & UPS_CHARGING)
			printf ("CHARGING "); 
		printf ("\n"); 
	}

	printf ("</PRE></TD>\n");
	printf ("<TD ROWSPAN=3><IMG SRC=\"upsimage.cgi?host=%s&display=battcap\" WIDTH=150 HEIGHT=350 ALT=\"Battery Capacity\"></TD>\n", monhost);
	printf ("<TD ROWSPAN=3><IMG SRC=\"upsimage.cgi?host=%s&display=utility\" WIDTH=150 HEIGHT=350 ALT=\"Utility\"></TD>\n", monhost);
	printf ("<TD ROWSPAN=3><IMG SRC=\"upsimage.cgi?host=%s&display=upsload\" WIDTH=150 HEIGHT=350 ALT=\"UPS Load\"></TD>\n", monhost);
	printf ("</TR>\n");

	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	printf ("Last UPS Self Test: Not Available\n");
	printf ("    Last Test Date: Not Available\n");
	printf ("</PRE></TD></TR>\n");

	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	if (!fetch (monhost, "utility", answer, sizeof(answer), ""))
		strcpy (answer, "Not available");
	printf ("  UPS Output: %s VAC\n", answer);

	if (!fetch (monhost, "linemin", answer, sizeof(answer), ""))
		strcpy (answer, "Not available");
	printf ("Line Minimum: %s VAC\n", answer);

	if (!fetch (monhost, "linemax", answer, sizeof(answer), ""))
		strcpy (answer, "Not available");
	printf ("Line Maximum: %s VAC\n", answer);

	if (!fetch (monhost, "upstemp", answer, sizeof(answer), ""))
		strcpy (answer, "Not available");
	else {
#ifdef I_LIKE_CELSIUS
		printf ("    UPS Temp: %s �C\n", answer);
#else
		tempf = (strtod (answer, 0) * 1.8) + 32;
		printf ("    UPS Temp: %.1f �F\n", tempf); 
#endif
	}

	if (!fetch (monhost, "outputfreq", answer, sizeof(answer), ""))
		strcpy (answer, "Not available");
	printf (" Output Freq: %s Hz\n", answer);

	printf ("</PRE></TD></TR>\n");
	printf ("</TABLE></CENTER>\n");
	printf ("</HTML>\n");
}
