/* genericups.c - support for generic contact-closure UPS models

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

	int	shmok = 1, upsfd;
	char	statefn[256];
	itype	*info;

	int	upstype = 0;

	/* bitwise values for different models */
	int	line_NORM, line_OL, line_BL, line_SD, val_OL, val_BL;

#define INFOMAX 8

/* simple open - we don't care about baud rate or any flags */
void open_serial_simple(char *port)
{
	signal (SIGALRM, openfail);
	alarm (3);

	upsfd = open (port, O_RDWR);

	/* set "normal" flags - cable power, or whatever */
	ioctl (upsfd, TIOCMSET, &line_NORM);
	alarm (0);

	if (upsfd < 1) {
		printf ("Unable to open %s: %s\n", port, strerror(errno));
		exit (1);
	}

	lockport (upsfd, port);
}

void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* put in how big this thing will be */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", 4);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;

	switch (upstype) {
		case 1:
		case 2:
			snprintf (info[1].value, sizeof(info[1].value), "APC");
			break;
		case 3:
			snprintf (info[1].value, sizeof(info[1].value), "PowerTech");
			break;
		default:
			snprintf (info[1].value, sizeof(info[1].value), "Unknown");
	}

	/* model string - hardcoded in this particular module */
	info[2].type = INFO_MODEL;

	switch (upstype) {
		case 1:
		case 2:
			snprintf (info[2].value, sizeof(info[2].value), "BACK-UPS");
			break;
		case 3:
			snprintf (info[2].value, sizeof(info[2].value), "Comp1000");
			break;
		default:
			snprintf (info[2].value, sizeof(info[2].value), "Unknown");
			break;
	}

	/* now set up room for all future variables that are supported */
	info[3].type = INFO_STATUS;
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	int	flags, ol, bl;

	ioctl (upsfd, TIOCMGET, &flags);

	ol = ((flags & line_OL) == val_OL);
	bl = ((flags & line_BL) == val_BL);

	strcpy (info[3].value, "");

	if (bl)
		strcat (info[3].value, "LB ");	/* low battery */

	if (ol)
		strcat (info[3].value, "OL");	/* on line */
	else
		strcat (info[3].value, "OB");	/* on battery */

	writeinfo(info);
}

/* show all possible UPS types */
void listtypes ()
{
	printf ("Valid UPS types:\n\n");
	printf ("1 - APC Back-UPS attached with 940-0095A/B/C cable\n");
	printf ("2 - APC Back-UPS attached with 940-0020B cable\n");
	printf ("3 - PowerTech Comp1000 UPS using DTR as cable power\n");
}

/* set the flags for this UPS type */
void settype (int type)
{
	upstype = type;

	printf ("UPS type: ");

	switch (type) {
		case 1: printf ("APC Back-UPS (940-0095A/B/C cable)\n");
			line_NORM = TIOCM_DTR;
			line_OL = TIOCM_RNG; val_OL = 0;
			line_BL = TIOCM_CD; val_BL = 0;
			line_SD = TIOCM_RTS;
			break;
		case 2: printf ("APC Back-UPS (940-0020B cable)\n");
			line_NORM = 0;
			line_OL = TIOCM_CTS; val_OL = 0;
			line_BL = TIOCM_CD; val_BL = TIOCM_CD;
			line_SD = TIOCM_DTR | TIOCM_RTS;
			break;
		case 3: printf ("PowerTech Comp1000 with DTR as cable power\n");
			line_NORM = TIOCM_DTR;
			line_OL = TIOCM_CTS; val_OL = 0;
			line_BL = TIOCM_CD; val_BL = TIOCM_CD;
			line_SD = TIOCM_DTR | TIOCM_RTS;
			break;
		default:
			printf ("Unknown UPS type number\n");
			listtypes();
			exit (1);
			break;
	}
}			

/* power down the attached load immediately */
void forceshutdown(char *port)
{
	int	flags;

	if (upstype == 0) {
		printf ("You need to set a UPS type with -t <num>...\n");
		sleep (5);
		exit (1);
	}

	open_serial_simple (port);

	syslog (LOG_INFO, "Initiating UPS shutdown\n");
	printf ("Initiating forced UPS shutdown!\n");

	flags = line_SD;
	ioctl (upsfd, TIOCMSET, &flags);

	sleep (10);
	printf ("Hmm, did the shutdown fail?  Oh well...\n");
	exit (1);  
}

/* install pointers to functions for msg handlers called from msgparse */
void setuphandlers()
{
	/* TODO: future */
}

void usage(char *prog)
{
	printf ("usage: %s [-h] [-l] -t <num> [-k] <device>\n", prog);
	printf ("Example: %s -t 1 /dev/ttyS0\n", prog);
}

void help(char *prog)
{
	printf ("usage: %s [-h] [-l] -t <num> [-k] <device>\n", prog);
	printf ("\n");
	printf ("-h       - display this help\n");
	printf ("-l       - show list of valid ups types\n");
	printf ("-t <num> - set ups type to <num>\n");
	printf ("-k       - force shutdown\n");
	printf ("<device> - /dev entry corresponding to UPS port\n");
}

int main (int argc, char **argv)
{
	char	*portname, *prog;
	int	i;

	printf ("Smart UPS Tools - Generic UPS driver 0.20 (%s)\n", UPS_VERSION);

	prog = argv[0];
	
	while ((i = getopt(argc, argv, "+k:t:lh")) != EOF) {
		switch (i) {
			case 'k':
				forceshutdown (optarg);
				break;
			case 't':
				settype (atoi(optarg));
				break;
			case 'l':
				listtypes();
				exit (1);
				break;
			case 'h':
				help (prog);
				break;
			default:
				usage (prog);
				break;
		}
	}

	if (upstype == 0) {
		printf ("No UPS type specified (use -t <num>)\n");
		exit (1);
	}

	argc -= optind;
	argv += optind;

	if (argc != 1) {
		help (prog);
		exit (1);
	}

	droproot();

	openlog ("genericups", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[0]); i >= 0; i--)
		if (argv[0][i] == '/') {
			portname = &argv[0][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[0]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/genericups-%s", STATEPATH,
	          portname);
	open_serial_simple (argv[0]);

	initinfo();

	createmsgq();   /* try to create IPC message queue */

	setuphandlers();

	background();

	for (;;) {
		char	msgbuf[256];

		updateinfo();

		/* wait up to 2 seconds for a message from the upsd */

		/* TODO: parse this properly - this is for testing */
		if (getupsmsg(msgbuf, 256, 2) == 1)
			syslog (LOG_INFO, "Received a message from upsd\n");
	}
}
