/* upsfetch - utility program to retrieve data from upsd via UDP 

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>

#include "netprotocol.h"	/* client/server net protocol	*/
#include "upsfetch.h"		/* our prototypes		*/

int upserror;

char *upserrstring (int errnum) 
{
	static char err[32];

	switch (errnum) {
		case UPSCOMMFAILURE:
			return ("Generic communications failure\n");

		case UPSTIMEDOUT:
			return ("Transaction timed out\n");

		case UPSBADMAGIC:
			return ("Protocol mismatch with server\n");

		case UPSUNKNOWNERR:
			return ("Unknown error occurred\n");

		default:
			sprintf (err, "Unknown error number %i\n", errnum);
			return (err);
			break;
	}

	return ("Broken switch.  Run away.\n");
}

int fetch(char *host, upsinfo *ups)
{
	requesttype		request;
	struct 	sockaddr_in	xmit_addr, dest_addr, from;
	int			udpfd, res, tries, retval;
	int			fromlen = sizeof(from);
	fd_set			rfds;
	struct	timeval		tv;
	struct	hostent		*serverdns;

	upserror = UPSUNKNOWNERR;

        if ((serverdns = gethostbyname(host)) == 
            (struct hostent *) NULL) {
		upserror = UPSCOMMFAILURE;
		return (-1);
        }

	strcpy (request.base.magic, PROTOMAGIC);
	strcpy (request.base.passwd, "");
	request.base.command = REQ_STATS;

	for (tries = 0; tries <= 3; tries++) {
		udpfd = socket(AF_INET, SOCK_DGRAM, 0);

		if (udpfd < 0) {
			upserror = UPSCOMMFAILURE;
			return (-1);
		}

		bzero((char *) &xmit_addr, sizeof(xmit_addr));
		xmit_addr.sin_family = AF_INET;
		xmit_addr.sin_addr.s_addr = INADDR_ANY;
		/* not setting sin_port just grabs the next one avail */

		res = (bind(udpfd, (struct sockaddr *) &xmit_addr, 
		       sizeof(xmit_addr)));

		if (res) {
			upserror = UPSCOMMFAILURE;
			return (-1);
		} 

		bzero((char *) &dest_addr, sizeof(dest_addr));

		(void) bcopy ((char *) serverdns->h_addr, (char *)
			     &dest_addr.sin_addr, serverdns->h_length);

		dest_addr.sin_family = AF_INET;
		dest_addr.sin_port = htons(UDPPORT);

	 	res = (sendto(udpfd, &request, sizeof(requesttype), 0, 
		      (struct sockaddr *)&dest_addr, sizeof(dest_addr))); 

		if (res < 0) {
			upserror = UPSCOMMFAILURE;
			return (-1);
		}

		FD_ZERO(&rfds);
		FD_SET(udpfd, &rfds);

		tv.tv_sec = 5;
		tv.tv_usec = 0;

		retval = select (udpfd+1, &rfds, NULL, NULL, &tv);

		if (retval) {
			res = recvfrom(udpfd, ups, sizeof(upsinfo), 0,
			      (struct sockaddr *) &from, &fromlen);

			if (res == sizeof(upsinfo)) {
				close (udpfd);
				upserror = 0;
				return(1);
			}
		}
	
		close(udpfd);
	}

	upserror = UPSTIMEDOUT;
	return(-1);
}
