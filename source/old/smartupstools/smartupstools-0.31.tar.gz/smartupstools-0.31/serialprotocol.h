/* serialprotocol.h - the protocol used to talk to the UPS */

#define GO_SMART 'Y'
#define GO_DUMB 'R'
#define REQ_MODEL 0x01			/* ^A */
#define REQ_CAPABILITIES 0x1A		/* ^Z */

#define NEXT_VALUE '+'
#define PREV_VALUE '-'

#define REQ_UPSIDENT 'c'
#define REQ_RETTHRESH 'e'
#define REQ_BATTLVL 'f'
#define REQ_ALMDELAY 'k'
#define REQ_LOWXFER 'l'
#define REQ_MFGDATE 'm'
#define REQ_SERIAL 'n'
#define REQ_HIGHXFER 'u'
#define REQ_BATTCHG 'x'

#define REQ_UPSTEMP 'C'
#define REQ_SELFTEST 'E'
#define REQ_FREQ 'F'
#define REQ_LINEMAX 'M'
#define REQ_LINEMIN 'N'
#define REQ_UTILITY 'O'
#define REQ_LOAD 'P'
#define REQ_STATUS 'Q'
