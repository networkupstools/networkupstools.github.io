/* readconf - common function for reading the ups.conf

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void readconf(char *configfile, char *passwd, char *upsport, char *shutdown)
{
	FILE	*config;
	char	*confbuf;

	if ((confbuf = calloc(255, sizeof(char))) == NULL) {
		perror ("calloc");
		exit (0);
	}

	if ((config = fopen(configfile, "r")) == NULL) {
		char	errmsg[256];
		sprintf (errmsg, "Can't open %s", configfile);
		perror (errmsg);
		exit (0);
	}

	while (fgets (confbuf, 255, config)) {
		if (strncmp ("PASS", confbuf, 4) == 0) {
			sscanf (confbuf, "%*s %s", passwd);
		}
		if (strncmp ("UPSPORT", confbuf, 7) == 0) {
			sscanf (confbuf, "%*s %s", upsport);
		}
		if (strncmp ("SHUTDOWN", confbuf, 4) == 0) {
			sscanf (confbuf, "%*s %s", shutdown);
		}
	}
	
	fclose (config);
}
