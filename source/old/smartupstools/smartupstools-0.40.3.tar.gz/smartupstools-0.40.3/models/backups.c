/* backups.c - model specific routines for APC Back-UPS units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/termios.h>

#include "shared.h"
#include "config.h"
#include "version.h"
#include "upscommon.h"

	int	shmok = 1, upsfd;
	char	statefn[256];
	itype	*info;
#define INFOMAX 8

/* simple open - we don't care about baud rate or any flags */
void open_serial_simple(char *port)
{
	int flags = 0;

	signal (SIGALRM, openfail);
	alarm (3);

	upsfd = open (port, O_RDWR);
	ioctl (upsfd, TIOCMSET, &flags);	/* turn off DTR right away */
	alarm (0);

	if (upsfd < 1) {
		printf ("Unable to open %s: %s\n", port, strerror(errno));
		exit (1);
	}

#ifdef HAVE_FLOCK
	if (flock(upsfd, LOCK_EX | LOCK_NB) != 0) {
		printf ("%s is locked by another process\n", port);
		exit (1);
	}
#endif
#ifdef HAVE_UULOCK
	res = uu_lock(port);
	if (res != 0) {
		printf ("Can't lock %s: %s\n", port, uu_lockerr(res));
		exit (1);
	}
#endif
}

void initinfo (void)
{
	int	i;

	info = create_info (INFOMAX, shmok);

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* put in how big this thing will be */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", 4);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;
	snprintf (info[1].value, sizeof(info[1].value), "APC");

	/* model string - hardcoded in this particular module */
	info[2].type = INFO_MODEL;
	snprintf (info[2].value, sizeof(info[2].value), "BACK-UPS");

	/* now set up room for all future variables that are supported */
	info[3].type = INFO_STATUS;

	writeinfo(1, info); /* see if this works before going any further */
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	int	flags, cts, dcd;

	ioctl (upsfd, TIOCMGET, &flags);
	cts = (flags & TIOCM_CTS);
	dcd = (flags & TIOCM_CD);
	
	snprintf (info[3].value, sizeof(info[3].value), "");

	if (dcd)
		strcat (info[3].value, "LB ");	/* low battery */

	if (cts)
		strcat (info[3].value, "OB");	/* on battery */
	else
		strcat (info[3].value, "OL");	/* on line */

	writeinfo(0, info);
}

int main (int argc, char **argv)
{
	char	*portname;
	int	i;

	printf ("Smart UPS Tools - BackUPS driver 1.00\n");

	if (argc != 2) {
		printf ("usage: %s <portname>	Example: %s /dev/ttyS0\n", 
		         argv[0], argv[0]);
		exit (1);
	}

	droproot();

	openlog ("backups", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[1]); i >= 0; i--)
		if (argv[1][i] == '/') {
			portname = &argv[1][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[1]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/backups-%s", STATEPATH,
	          portname);
	open_serial_simple (argv[1]);

	initinfo();

	background();

	while (1) {
		updateinfo();
		sleep (2);
	}
}
