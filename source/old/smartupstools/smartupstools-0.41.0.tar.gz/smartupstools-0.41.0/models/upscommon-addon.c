/* upscommon-addon.c - addons functions 
    perhaps used in more than one model support module

   Copyright (C) 1999  Peter Bieringer <pb@bieringer.de>

   based on:
    upscommon.c - functions used in more than one model support module
    Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

/* Here you can define extended syslog debugging */
/* #define DEBUG_UPSCOMMONADDON */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <sys/ioctl.h>

#include "smartups.h"
#include "shared.h"
#include "config.h"
#include "version.h"

#include "upscommon.h"
#include "upscommon-addon.h"

    int dtr_bit = TIOCM_DTR;
    int rts_bit = TIOCM_RTS;

/* set DTR and RTS lines on a serial port to supply a passive serial interface */
/*  here: DTR to 0 (-V), RTS to 1 (+V) */
void set_serialDTR0RTS1(void)
{
    // set DTR to low and RTS to high
    ioctl(upsfd, TIOCMBIC, &dtr_bit);
    ioctl(upsfd, TIOCMBIS, &rts_bit);
}

/* wait for an binary answer and get buflen bytes */
int recvbinary (char *buf, int buflen)
{
	unsigned char in;
	int ret, counter = 0, retval = 0;
	struct sigaction sa;
	sigset_t sigmask;

#ifdef DEBUG_UPSCOMMONADDON
        syslog (LOG_DEBUG, "start reading %d binary data bytes from ups", buflen);
#endif	

	sa.sa_handler = timeout;
	sigemptyset (&sigmask);
	sa.sa_mask = sigmask;
	sa.sa_flags = 0;
	sigaction (SIGALRM, &sa, NULL);

	alarm (3);

        while (counter < buflen) {
#ifdef DEBUG_UPSCOMMONADDON
            syslog (LOG_DEBUG, "want to read [%2d] of %2d", counter +1 , buflen); 
#endif	
    	    ret = read (upsfd, &in, 1);
#ifdef DEBUG_UPSCOMMONADDON
	    if (ret == -1) {
		perror("read from serial");
	    };
#endif	
	    
	    if (ret > 0) {
		buf[counter] = in;
		counter ++;
#ifdef DEBUG_UPSCOMMONADDON
                syslog (LOG_DEBUG, "read [%2d]: 0x%02x", counter,  buflen, in); 
#endif	
		nolongertimeout();	   
	    }
	    else {
	        syslog (LOG_DEBUG, "error reading from serial device!");
		retval = -1;
		break;
	    }
	}
	
	alarm (0);
	signal (SIGALRM, SIG_IGN);
	
	if (retval == 0) {
	    syslog (LOG_DEBUG, "got all bytes from ups");
	}
	
        return (retval);
}

/* install given data directly in the data array */
void installinfodirect (int infotype, char *datastring)
{
	int	i, pos = 0;

	for (i = 0; i < INFOMAX; i++)
		if (info[i].type == infotype) {
			pos = i;
			break;
		}

	if (pos == 0) {	/* not found, probably debugging? */
		syslog (LOG_ERR, "installinfodirect: can't find type %i\n", infotype);
		return;
	}

	strncpy(info[pos].value, datastring, sizeof(info[pos].value) - 1);
}
