/* smartups.c - model specific routines for APC Smart-UPS units

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/termios.h>

#include "smartups.h"
#include "shared.h"
#include "config.h"
#include "upscommon.h"

	int	upsfd;
	char	statefn[256];
	itype	info[INFOMAX];

void initinfo (void)
{
	int	i;

	/* clear out everything first */
	for (i = 0; i < INFOMAX; i++)
		info[i].type = INFO_UNUSED;

	/* number of variables (put in 10 for 0-9, etc) */
	info[0].type = INFO_MEMBERS;
	snprintf (info[0].value, sizeof(info[0].value), "%i", 12);

	/* manufacturer ID - hardcoded in this particular module */
	info[1].type = INFO_MFR;
	snprintf (info[1].value, sizeof(info[1].value), "APC");

	/* now set up room for all future variables that are supported */
	info[2].type = INFO_MODEL;
	info[3].type = INFO_SERIAL;
	info[4].type = INFO_UTILITY;
	info[5].type = INFO_BATTPCT;
	info[6].type = INFO_STATUS;
	info[7].type = INFO_UPSTEMP;
	info[8].type = INFO_ACFREQ;
	info[9].type = INFO_LOADPCT;
	info[10].type = INFO_LOWXFER;
	info[11].type = INFO_HIGHXFER;
}

void getbaseinfo (char *port)
{
	/* TODO: handle models that don't do this gracefully */
	installinfo (INFO_MODEL, REQ_MODEL);

	installinfo (INFO_SERIAL, REQ_SERIAL);

	printf ("Detected %s [%s] on %s\n", getdata(INFO_MODEL), 
		getdata(INFO_SERIAL), port);

	writeinfo(1);
}

/* normal idle loop - keep up with the current state of the UPS */
void updateinfo (void)
{
	char	temp[256];
	int	tval;

	installinfo (INFO_UTILITY, REQ_UTILITY);
	installinfo (INFO_BATTPCT, REQ_BATTPCT);
	installinfo (INFO_UPSTEMP, REQ_UPSTEMP);
	installinfo (INFO_ACFREQ, REQ_ACFREQ);
	installinfo (INFO_LOADPCT, REQ_LOADPCT);
	installinfo (INFO_LOWXFER, REQ_LOWXFER);
	installinfo (INFO_HIGHXFER, REQ_HIGHXFER);

	send (REQ_STATUS);
	recv (temp, sizeof(temp));
	tval = strtol (temp, 0, 16);

	strcpy (info[6].value, "");
	if (tval & 1)
		strcat (info[6].value, "CAL ");		/* calibration */
	if (tval & 2)
		strcat (info[6].value, "TRIM ");	/* SmartTrim */
	if (tval & 4)
		strcat (info[6].value, "BOOST ");	/* SmartBoost */
	if (tval & 8)
		strcat (info[6].value, "OL ");		/* on line */
	if (tval & 16)
		strcat (info[6].value, "OB ");		/* on battery */
	if (tval & 32)
		strcat (info[6].value, "OVER ");	/* overload */
	if (tval & 64)
		strcat (info[6].value, "LB ");		/* low battery */
	if (tval & 128)
		strcat (info[6].value, "RB ");		/* replace batt */	

	if (!strcmp(temp, "00")) 
		snprintf (info[6].value, sizeof(info[6].value), "OFF");

	/* lose trailing space if present */
	if (info[6].value[strlen(info[6].value)-1] == ' ')
		info[6].value[strlen(info[6].value)-1] = 0;

	writeinfo(0);
}

int main (int argc, char **argv)
{
	char	*portname, temp[256];
	int	i;

	printf ("Smart UPS Tools - SmartUPS driver 1.00\n");

	if (argc != 2) {
		printf ("usage: %s <portname>       Example: %s /dev/ttyS0\n", 
			argv[0], argv[0]);
		exit (1);
	}

	droproot();

	openlog ("smartups", LOG_PID, LOG_FACILITY);

	portname = NULL;
	for (i = strlen(argv[1]); i >= 0; i--)
		if (argv[1][i] == '/') {
			portname = &argv[1][i+1];
			break;
		}

	if (portname == NULL) {
		printf ("Unable to abbreviate %s\n", argv[1]);
		exit (1);
	}

	snprintf (statefn, sizeof(statefn), "%s/smartups-%s", STATEPATH,
	          portname);
	open_serial (argv[1], B2400);

	send (GO_SMART);
	recv (temp, sizeof(temp));
	if (strcmp(temp, "SM") != 0) {
		printf ("Unable to detect a SmartUPS on port %s\n", argv[1]);
		printf ("Check the cabling, port name or model name and try again\n");
		exit (1);
	}

	initinfo();
	getbaseinfo(argv[1]);

	background();

	while (1) {
		updateinfo();
		sleep (2);
	}
}
