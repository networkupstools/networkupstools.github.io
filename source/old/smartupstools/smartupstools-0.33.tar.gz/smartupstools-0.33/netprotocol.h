/* netprotocol.h - client/server communications via UDP
 *
 * Russell Kroll <rkroll@exploits.org>
 */

/* UDP port number */

#define UDPPORT		3301

/* client to server protocol base */

typedef struct {
	char	magic[8];
	char	passwd[16];
	int	command;
}	protobase;

#define PROTOMAGIC	"UPSMON3"	/* for the magic field */

/* values for command */
#define REQ_STATS	1000
#define SET_CAPS	1001		/* capabilities - someday         */
#define UNKNOWNCMD	1002		/* upsd doesn't understand packet */
#define BADMAGIC	1003		/* protocol mismatch              */

/* for trivial requests - status only so far */

typedef struct {	
	protobase	base;
	int		request;
}	requesttype;
