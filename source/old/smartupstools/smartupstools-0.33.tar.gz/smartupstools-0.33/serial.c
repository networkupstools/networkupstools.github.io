/* serial.c: upsd serial routines for unix systems

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

/* interface details
 *
 * This is intended to become "unix/serial.c" in the event that 
 * support for other operating systems and their serial ports becomes
 * necessary.  It was supposed to have a counterpart, "nt/serial.c",
 * but it never materialized.
 *
 * init_serial(char *portfn) 
 * - opens the serial port to the UPS on the given port
 *
 * recv_from_ups(char *answer, int anslen) 
 * - returns the response from the ups in your buffer of anslen bytes
 *
 * send_to_ups (char data)
 * - sends a byte to the UPS on the port opened earlier
 *
 * close_serial()
 * - cleanly shuts down the port to the UPS
 */

#include <stdio.h>
#include <errno.h>		
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h> 	
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/termios.h>

	int	upsfd;

void notty()			/* called on SIGALRM during serial open */
{
	printf ("Fatal error: Serial port open timed out\n");
	exit (1);
}

void init_serial(char *portfn)
{
	struct	termios		oldtio, newtio;

	signal (SIGALRM, notty); 
	alarm (3);

	/* first open - nonblocking mode to set all the flags straight */

        upsfd = open(portfn, O_RDWR | O_NOCTTY | O_NONBLOCK);
	alarm(0);

        if (upsfd < 1) {
		char	errmsg[64];
		sprintf (errmsg, "Unable to open %s", portfn);
		perror (errmsg);
                exit(0);
        }

        tcgetattr(upsfd, &oldtio);
	newtio.c_lflag = 0 | ECHOE | ECHOKE | ECHOCTL | PENDIN;
	newtio.c_iflag = 0 | IXANY | IMAXBEL | IXOFF;
	newtio.c_oflag = 0 | ONLCR;
	newtio.c_cflag = 0 | CREAD | CS8 | HUPCL | CLOCAL;
	cfsetospeed(&newtio, B2400);
        newtio.c_cc[VMIN] = 1;
        newtio.c_cc[VTIME] = 0;
        tcflush(upsfd, TCIFLUSH);
        tcsetattr(upsfd, TCSANOW, &newtio);
	close (upsfd);				

	/* now we open the port again for actual use */

	signal (SIGALRM, notty); 
	alarm (3);

        upsfd = open(portfn, O_RDWR | O_NOCTTY);
	alarm (0);

        if (upsfd < 1) {
		char	errmsg[64];
		sprintf (errmsg, "Unable to open %s", portfn);
		perror (errmsg);
                exit(0);
        }
	signal (SIGALRM, SIG_IGN);

        tcgetattr(upsfd, &oldtio);
        newtio.c_cflag = B2400 | CS8 | CLOCAL | CREAD;
        newtio.c_iflag = IGNPAR;
        newtio.c_oflag = 0;
        newtio.c_lflag = 0;
        newtio.c_cc[VMIN] = 1;
        newtio.c_cc[VTIME] = 0;
        tcflush(upsfd, TCIFLUSH);
        tcsetattr(upsfd, TCSANOW, &newtio);
}

void send_to_ups(char data)
{
        tcflush(upsfd, TCIFLUSH);
        write (upsfd, &data, 1);

        return;
}

void recv_from_ups(char *answer, int anslen)
{
	char	recvbuf[256];
	char	in;
	int	ret;

	strcpy (recvbuf, "");

        while (1) {
                ret = read (upsfd, &in, 1);
		if (ret > 0) {
			if (in == 10) {		/* done, exit */
				strncpy (answer, recvbuf, anslen);
				answer[anslen-1] = 0;
				return;
			} 
			else
				if ((in != 13) && (in != '!') && (in != '$')
				    && (in != '|'))
					sprintf (recvbuf, "%s%c", recvbuf, in);
		}	

		if (ret == -1)
			perror ("read error");
        }

	/* not reached */
}               

void close_serial()
{
	close (upsfd);
}
