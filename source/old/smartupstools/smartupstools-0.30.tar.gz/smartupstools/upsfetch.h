/* upsfetch.h - prototypes and struct info for ups data retrieval
 *
 * Russell Kroll <rkroll@exploits.org>
 */

typedef struct {		/* 12345678901234567890 */
	int	pkttype;
	char	model[32];	/* SMART-UPS 700	*/
	char	serial[32];	/* WSxxxxxxxxxx		*/
	char	mfgdate[16];	/* 01/23/45 		*/
	char	battchg[16];	/* 01/23/45		*/
	char	upsload[8];	/* 100.0		*/
	char	battcap[8];	/* 100.0		*/
	char	utility[8];	/* 120.0		*/
	char	status[8];	/* 08			*/
	char	linemin[8];	/* 100.0		*/
	char	linemax[8];	/* 130.0		*/
	char	upstemp[8];	/* 040.5		*/
	char	freq[8];	/* 60.00		*/
	char	selftest[8];	/* 168			*/
	char	retthresh[8];	/* 15			*/
	char	upsident[16];	/* UPS_IDEN		*/
	char	almdelay[8];	/* T			*/
	char	lowxfer[8];	/* 103			*/
	char	highxfer[8];	/* 132			*/

	/* capabilities */
	char	c_selftest[32];	
	char	c_retthresh[32];
	char	c_almdelay[32];
	char	c_lowxfer[32];
	char	c_highxfer[32];
	char	c_outvolt[32];
	char	c_grace[32];
	char	c_battwarn[32];
	char	c_retdelay[32];
	char	c_sens[32];

}	upsinfo;

/* fetch: use to retrieve a upsinfo struct info from host into ups */
int fetch(char *host, upsinfo *ups);

/* upserrstring: returns a short explanation of a failure condition */
char *upserrstring (int errnum) ;

/* upserror: the error number associated with the failure, if any */
extern int upserror;

/* error numbers */

#define UPSCOMMFAILURE	1	/* generic comms failure 		*/
#define UPSTIMEDOUT	2	/* receive from upsd timed out		*/
#define UPSBADMAGIC	3	/* protocol version mismatch		*/
#define UPSUNKNOWNERR	255	/* unknown error encountered		*/
