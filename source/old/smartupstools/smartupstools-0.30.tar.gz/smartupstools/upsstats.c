/* upsstats - cgi program to generate the main ups info page

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

/* default host - only used if you don't specify one in the URL */
#define MONHOST "127.0.0.1"

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>
#include <fcntl.h>
#include "upsfetch.h"

/* bit values that get OR'ed later */
#define UPS_CALIBRATION	1
#define UPS_SLEEPING	2
#define UPS_UNKNOWN	4
#define UPS_ONLINE	8
#define UPS_ONBATT	16
#define UPS_UNKNOWN2	32
#define UPS_BATTLOW	64
#define UPS_CHARGING	128

char	monhost[256];

void parsearg(char var[255], char value[255]) 
{
	if (!strcmp(var, "host")) {
		strncpy (monhost, value, sizeof(monhost));
	}
}

void extractcgiargs() 
{
	char	ch;
	int	invar, invalue, handled, i;
	char	var[255], value[255];
	char	*query;

	invar = 1;
	invalue = 0;

	strcpy (value, "");
	strcpy (var, "");

	query = getenv ("QUERY_STRING");
	if (query == NULL)
		return;		/* not run as a cgi script! */

	for (i = 0; i < strlen(query); i++) {
		ch = query[i];
		handled = 0;
		if (ch == '=') {
			invar = 0;
			invalue = 1;
			strcpy (value, "");
			handled = 1;
		}

		if (ch == '&') {
			invar = 1;
			invalue = 0;
			parsearg(var, value);
			strcpy (var, "");
			handled = 1;
		}

		if ((invar == 1) && (!handled)) {
			sprintf (var, "%s%c", var, ch);
		}

		if ((invalue == 1)  && (!handled)) {
			sprintf (value, "%s%c", value, ch);
		}
	}

	if (invalue) {
		value[strlen(value)] = 0;
		parsearg (var, value);
	}
}

int checkhost(char *check)
{
	FILE	*hostlist;
	char	fn[256], buf[256], addr[256], desc[256];

	sprintf(fn, "%s/hosts.conf", BASEPATH);
	hostlist = fopen(fn, "r");

	if (hostlist == NULL)
		return 1;		/* default to allow */

	while (fgets (buf, sizeof(buf), hostlist)) 
		if (strncmp("MONITOR", buf, 7) == 0) {
			sscanf (buf, "%*s %s %s", addr, desc);
			if (!strcmp (addr, check)) {
				fclose (hostlist);
				return 1;	/* allowed */
			}
		}

	fclose (hostlist);
	return 0;		/* denied */
}	

char *getdate()
{
	char	*timestr;
	time_t	tod;

	timestr = calloc (255, sizeof(char));
	time (&tod);
	strftime (timestr, 100, "%a %b %d %X %Z %Y", localtime(&tod));

	return (timestr);
}

void nocomm()
{
	printf ("Error: %s\n", upserrstring(upserror));
	exit (0);
}

int main() 
{
	int	status;
	double	tempf;
	upsinfo	ups;

	strcpy (monhost, MONHOST);	/* default host */

	extractcgiargs();

	printf ("Content-type: text/html\n");
	printf ("Pragma: no-cache\n");
/*	printf ("Expires: Thu, 01 Jan 1998 00:00:00 GMT\n"); */
	printf ("\n");

	if (!checkhost (monhost)) {
		printf ("Access to that host is not authorized.\n");
		exit (0);
	}

	if (fetch (monhost, &ups) < 0) 
		nocomm(monhost);
	
	printf ("<HTML><HEAD><TITLE>%s on %s</TITLE></HEAD>\n", ups.model, monhost);
	printf ("<BODY TEXTCOLOR=\"#000000\">\n");
	printf ("<CENTER><TABLE BORDER CELLSPACING=10 CELLPADDING=5>\n");
	printf ("<TR><TH>%s</TH>\n", getdate());
	printf ("<TH>Batt Cap</TH><TH>Utility</TH><TH>UPS Load</TH></TR>\n");
	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	printf ("Monitoring: %s\n", monhost);
	printf (" UPS Model: %s\n", ups.model);

	printf ("    Status: ");

	status = strtol (ups.status, 0, 16);
	if (status & UPS_CALIBRATION) 
		printf ("CALIBRATION "); 
	if (status & UPS_SLEEPING)
		printf ("SLEEPING "); 
	if (status & UPS_UNKNOWN)
		printf ("UNKNOWN "); 
	if (status & UPS_ONLINE)
		printf ("ONLINE "); 
	if (status & UPS_ONBATT) 
		printf ("ON BATTERY "); 
	if (status & UPS_BATTLOW) 
		printf ("BATTERY LOW "); 
	if (status & UPS_CHARGING)
		printf ("CHARGING "); 
	printf ("\n"); 

	printf ("</PRE></TD>\n");

	printf ("<TD ROWSPAN=3>\n");
	printf ("<IMG SRC=\"upsimage.cgi?host=%s&display=battcap\" WIDTH=130 HEIGHT=350 ALT=\"Battery capacity: %s %%\"></TD>\n", monhost, ups.battcap);

	printf ("<TD ROWSPAN=3>\n");
	printf ("<IMG SRC=\"upsimage.cgi?host=%s&display=utility\" WIDTH=130 HEIGHT=350 ALT=\"Utility: %s %%\"></TD>\n", monhost, ups.utility);

	printf ("<TD ROWSPAN=3>\n");
	printf ("<IMG SRC=\"upsimage.cgi?host=%s&display=upsload\" WIDTH=130 HEIGHT=350 ALT=\"UPS Load: %s %%\"></TD>\n", monhost, ups.upsload);

	printf ("</TR>\n");

	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	printf ("Last UPS Self Test: Not Available\n");
	printf ("    Last Test Date: Not Available\n");
	printf ("</PRE></TD></TR>\n");

	printf ("<TR><TD BGCOLOR=\"#FFFFFF\"><PRE>\n");
	printf ("  UPS Output: %s VAC\n", ups.utility);
	printf ("Line Minimum: %s VAC\n", ups.linemin);
	printf ("Line Maximum: %s VAC\n", ups.linemax);
#ifdef I_LIKE_CELSIUS
	printf ("    UPS Temp: %s �C\n", ups.upstemp);
#else
	tempf = (strtod (ups.upstemp, 0) * 1.8) + 32;
	printf ("    UPS Temp: %.1f �F\n", tempf); 
#endif

	printf (" Output Freq: %s Hz\n", ups.freq);

	printf ("</PRE></TD></TR>\n");
	printf ("</TABLE></CENTER>\n");

	return (1);
}
