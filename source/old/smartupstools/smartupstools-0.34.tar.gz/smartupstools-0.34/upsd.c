/* upsd - serial UPS monitoring daemon and status server

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h> 
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/termios.h>
#include <signal.h>
#include <unistd.h>
#include <syslog.h>
#include <stdlib.h>

#include "netprotocol.h"	/* client/server net protocol	*/
#include "upsfetch.h"		/* upsinfo struct		*/
#include "serial.h"		/* serial module prototypes	*/
#include "serialprotocol.h"	/* SmartUPS protocol		*/

	/* see, i told you the list of globals was shrinking... */

	struct	sockaddr_in	from;
	requesttype		pkt, reppkt;
	upsinfo			ups;		
	int			recvsockfd, udpport = UDPPORT;

static	sigset_t		sigmask;
	int			fakelow = 0, fakeonbatt = 0;
	char			passwd[16], *upsport, *shutdowncmd;

	/* sag/spike values */
	int	anomstart = 0, sag = 0, spike = 0;
	float	vmin, vmax;

void readconf(char *configfile, char *passwd, char **upsport, char **shutdown);

void initudp()
{
	int	res;
	struct	sockaddr_in	rcv_addr;

	if ((recvsockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror ("socket() failure");
		exit (1);
	}

	bzero((char *) &rcv_addr, sizeof(rcv_addr));
	rcv_addr.sin_family = AF_INET;
	rcv_addr.sin_port = htons(udpport);

	res = (bind(recvsockfd, (struct sockaddr *)&rcv_addr, 
	       sizeof(rcv_addr)));

	if (res) {
		perror ("bind failure");
		exit (1);
	}

	return;
}

void become_daemon()
{
	int	pid;
	
	close (0);
	close (1);
	close (2);

	if ((pid = fork()) < 0) {
		perror ("Unable to fork");
		exit (1);
	}
	if (pid != 0) exit (0);
	syslog (LOG_INFO, "Ready to handle UPS requests");
}

void give_up_root()
{
	if (getuid() == 0) 
		seteuid(65534);

	return;
}

void sig_term (int sig)
{
	syslog (LOG_INFO, "SIGTERM: shutting down..");
	
	send_to_ups (GO_DUMB);
	close_serial();

	exit (0);
}

void sig_usr1 (int sig)
{
	syslog (LOG_INFO, "SIGUSR1 caught");
	if (fakelow == 0) {
		syslog (LOG_INFO, "Fake low battery is ON");
		fakelow = 1;
		return;
	}
	syslog (LOG_INFO, "Fake low battery is OFF");
	fakelow = 0;
	return;
}

void sig_usr2 (int sig)
{
	syslog (LOG_INFO, "SIGUSR2 caught");
	if (fakeonbatt == 0) {
		syslog (LOG_INFO, "Fake on battery is ON");
		fakeonbatt = 1;
		return;
	}
	syslog (LOG_INFO, "Fake on battery is OFF");
	fakeonbatt = 0;
	return;
}

void signal_setup()
{
        struct  sigaction sa;

        sigemptyset(&sigmask);
        sigaddset(&sigmask, SIGUSR1);
        sigaddset(&sigmask, SIGUSR2);
        sigaddset(&sigmask, SIGTERM);

#define SIGNAL(s,handler) { \
                sa.sa_handler = handler; \
                if (sigaction(s, &sa, NULL) < 0) { \
			perror ("sigaction failure"); \
                        exit(1); \
                } \
        }

        sa.sa_mask = sigmask;
        sa.sa_flags = 0;
        SIGNAL(SIGUSR1,sig_usr1);
        SIGNAL(SIGUSR2,sig_usr2);
	SIGNAL(SIGTERM,sig_term);
}
 
void sendback(int reply)
{
	int	res;

	strcpy(reppkt.base.magic, PROTOMAGIC);
	strcpy(reppkt.base.passwd, "");
	reppkt.base.command = reply;

	res = sendto(recvsockfd, &reppkt, sizeof(reppkt), 0, 
	      (struct sockaddr *) &from, sizeof(from));

}

void get_initial_settings()
{
	send_to_ups (REQ_MODEL);
	recv_from_ups (ups.model, sizeof(ups.model));	

	send_to_ups (REQ_SERIAL);
	recv_from_ups (ups.serial, sizeof(ups.serial));

	send_to_ups (REQ_MFGDATE);
	recv_from_ups (ups.mfgdate, sizeof(ups.mfgdate));

	send_to_ups (REQ_BATTCHG);
	recv_from_ups (ups.battchg, sizeof(ups.battchg));

	send_to_ups (REQ_SELFTEST);
	recv_from_ups (ups.selftest, sizeof(ups.selftest));

	send_to_ups (REQ_RETTHRESH);
	recv_from_ups (ups.retthresh, sizeof(ups.retthresh));

	send_to_ups (REQ_ALMDELAY);
	recv_from_ups (ups.almdelay, sizeof(ups.almdelay));

	send_to_ups (REQ_UPSIDENT);
	recv_from_ups (ups.upsident, sizeof(ups.upsident));

	send_to_ups (REQ_LOWXFER);
	recv_from_ups (ups.lowxfer, sizeof(ups.lowxfer));

	send_to_ups (REQ_HIGHXFER);
	recv_from_ups (ups.highxfer, sizeof(ups.highxfer));
}

int valid_option (char *hayin, char *needle)
{
	char	*next, haystack[512];

	strcpy (haystack, hayin);	/* strtok modifies the first arg */

	next = strtok(haystack, "!");
	if (!strcmp (next, needle))
		return (1);

	while ((next = strtok(NULL, "!")) != NULL)
		if (!strcmp (next, needle))
			return (1);

	return (0);
}	

void parseudp() 
{
	int res;

	if (strcmp(PROTOMAGIC, pkt.base.magic)) {
		sendback (BADMAGIC);
		return;
	}

	if (pkt.base.command == REQ_STATS) {
		res = sendto (recvsockfd, &ups, sizeof(upsinfo), 0,
		             (struct sockaddr *) &from, sizeof(from));
		return;
	}

	sendback (UNKNOWNCMD);
	return;
}

#define DEEPSAG 90.0		/* under 90V = deep sag */
#define LONGTIME 5		/* "prolonged" after this many seconds */

void line_norm()
{
	time_t	tod;

	if (sag || spike) {
		sag = spike = 0;
		time (&tod);
		syslog (LOG_INFO, "Normal power restored - duration: %li sec",
			tod - anomstart);
	}
}

void line_sag()
{
	char	logbuf[256];
	time_t	tod;
static	int	longtime;

	if (sag == 0) {
		sag = 1;
		longtime = 0;
		time(&tod);
		anomstart = tod;

		sprintf (logbuf, "On battery: %s sag %sV", 
			(vmin < DEEPSAG) ? "deep" : "small", ups.linemin);

		syslog (LOG_INFO, logbuf);
	}
	else {		/* still in a sag */
		time (&tod);
		if (((tod - anomstart) > LONGTIME) && (!longtime)) {
			longtime = 1;
			sprintf (logbuf, "Extended sag (> %i sec)- now %sV",
				 LONGTIME, ups.linemin);
			syslog (LOG_INFO, logbuf);
		}
	}
}

void getupsstats()
{
	send_to_ups (REQ_LINEMIN);
	recv_from_ups (ups.linemin, sizeof(ups.linemin));
	vmin = atof (ups.linemin);

	if (vmin < atoi(ups.lowxfer))   /* lowest voltage < lower transfer */
		line_sag();

	if (vmin >= atoi(ups.lowxfer))  /* lowest voltage >= lower transfer */
		line_norm();

	send_to_ups (REQ_LINEMAX);
	recv_from_ups (ups.linemax, sizeof(ups.linemax));

	send_to_ups (REQ_UPSTEMP);
	recv_from_ups (ups.upstemp, sizeof(ups.upstemp));

	send_to_ups (REQ_FREQ);
	recv_from_ups (ups.freq, sizeof(ups.freq));

	send_to_ups (REQ_LOAD);
	recv_from_ups (ups.upsload, sizeof(ups.upsload));

	send_to_ups (REQ_BATTLVL);
	recv_from_ups (ups.battcap, sizeof(ups.battcap));

	send_to_ups (REQ_UTILITY);
	recv_from_ups (ups.utility, sizeof(ups.utility));

	send_to_ups (REQ_STATUS);
	recv_from_ups (ups.status, sizeof(ups.status));

	/* debugging stuff */

	if (fakeonbatt == 1) 
		strcpy (ups.status, "10"); /* "on battery" */
	
	if (fakelow == 1) 
		strcpy (ups.status, "50"); /* "on battery" + "low battery" */
}

int parseopt (char *ptr, char *store)
{
	short int j, numopt, optlen;
	char opt[256], optloc;

	optloc = ptr[1];
	numopt = ptr[2] - 48;
	optlen = ptr[3] - 48;

	if ((optloc != 'D') && (optloc != '4')) {
		return (3 + (optlen * numopt));
	}

	ptr += 4;
	for (j = 0; j < numopt; j++) {
		strncpy (opt, ptr, optlen);
		opt[optlen] = 0;
		sprintf (store, "%s%s!", store, opt);
		ptr += optlen;
	}

	return (3 + (numopt * optlen));
}

void get_ups_capabilities()
{
	char	resp[1024], *ptr, dummy[256];
	int	i;

	/* initialize capability strings */
	strcpy (ups.c_retthresh, "");
	strcpy (ups.c_almdelay, "");
	strcpy (ups.c_lowxfer, "");
	strcpy (ups.c_highxfer, "");
	strcpy (ups.c_outvolt, "");
	strcpy (ups.c_grace, "");
	strcpy (ups.c_battwarn, "");
	strcpy (ups.c_retdelay, "");
	strcpy (ups.c_sens, "");
	strcpy (ups.c_selftest, "");

	send_to_ups (GO_SMART);
	recv_from_ups (resp, sizeof(resp));

	send_to_ups (REQ_CAPABILITIES);
	recv_from_ups (resp, sizeof(resp));

	if (resp[0] != '#') {
		printf ("Unrecognized capability string start char %c\n", resp[0]);
		exit (0);
	}

	for (i = 1; i < strlen(resp); i++) {
		ptr = &resp[i];

		switch (ptr[0]) {
			case 'e': i += parseopt(ptr, ups.c_retthresh); break;
			case 'k': i += parseopt(ptr, ups.c_almdelay); break;
			case 'l': i += parseopt(ptr, ups.c_lowxfer); break;
			case 'o': i += parseopt(ptr, ups.c_outvolt); break;
			case 'p': i += parseopt(ptr, ups.c_grace); break;
			case 'q': i += parseopt(ptr, ups.c_battwarn); break;
			case 'r': i += parseopt(ptr, ups.c_retdelay); break;
			case 's': i += parseopt(ptr, ups.c_sens); break;
			case 'u': i += parseopt(ptr, ups.c_highxfer); break;
			case 'E': i += parseopt(ptr, ups.c_selftest); break;
			default: i += parseopt (ptr, dummy); break;
		}
	}
}

void usage (char *progname)
{
	printf ("usage: %s [-s serialport] [-p portnum]\n", progname);

	exit (1);
}

int main(int argc, char **argv)
{
	char		configfile[128];
	int		i, n, retval, fromlen;
	fd_set		rfds;
struct	timeval		tv;

	printf ("Smart UPS Tools upsd %s\n", VERSION);
	sprintf (configfile, "%s/ups.conf", BASEPATH);

	upsport = shutdowncmd = NULL;
	strcpy (passwd, "");

	readconf(configfile, passwd, &upsport, &shutdowncmd);
	give_up_root();

	while ((i = getopt(argc, argv, "+s:p:h")) != EOF) {
		switch (i) {
			case 'h': 		/* help */
				usage (argv[0]);
				break;

			case 's':		/* serial port */
				if (upsport != NULL)
					free(upsport);
				upsport = calloc (strlen(optarg), 1);
				strncpy (upsport, optarg, strlen(optarg));
				break;

			case 'p':		/* network port */
				udpport = atoi(optarg);
				break;
			default:
				usage(argv[0]);
				break;
		}
	}

	if (strlen(upsport) == 0) {
		printf ("UPSPORT must be configured in %s\n", configfile);
		exit (1);
	}

	if (strlen(passwd) == 0) {
		printf ("PASSWD must be configured in %s\n", configfile);
		exit (1);
	}

	/* shutdown isn't used by upsd .. */

	openlog ("upsd", LOG_PID, LOG_INFO);

	initudp();

	init_serial(upsport);

	send_to_ups (GO_SMART);
	recv_from_ups (ups.model, sizeof(ups.model));	/* expect "SM" */
	if (strcmp(ups.model, "SM")) {
		printf ("Error: SM not received in reply to GO_SMART command\n");
		printf ("Reply was [%s]\n", ups.model);
		close_serial(upsport);
		exit (0);
	}

	get_initial_settings();

	get_ups_capabilities();

	printf ("Monitoring %s serial # %s on %s (port %i)\n", ups.model, 
		ups.serial, upsport, udpport);
	printf ("Acceptable voltage range: %s - %s VAC\n", ups.lowxfer, 
		ups.highxfer);
	signal_setup();
	become_daemon();   

	getupsstats();

	for ( ; ; ) {
		FD_ZERO(&rfds);
		FD_SET(recvsockfd, &rfds);

		tv.tv_sec = 0;
		tv.tv_usec = 250;

		sigprocmask(SIG_BLOCK, &sigmask, NULL);
		retval = select(recvsockfd+1, &rfds, NULL, NULL, &tv);
		sigprocmask(SIG_UNBLOCK, &sigmask, NULL);

		fromlen = sizeof(from);

		if ((retval) && (FD_ISSET(recvsockfd, &rfds))) {
			n = recvfrom (recvsockfd, &pkt, sizeof(pkt), 0, 
				     (struct sockaddr *)&from, &fromlen);
	
			if (n == sizeof(pkt))	/* toss broken frames */
				parseudp();
		}
		else {			/* idle stuff */
			getupsstats();
		}
	}

	close (recvsockfd);
	exit (0);
}
