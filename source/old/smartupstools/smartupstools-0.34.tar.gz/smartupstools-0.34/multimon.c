/* multimon - CGI program to monitor several UPSes from one page

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "upsfetch.h"

/* bit values that get OR'ed later */
#define UPS_CALIBRATION	1
#define UPS_SLEEPING	2
#define UPS_UNKNOWN	4
#define UPS_ONLINE	8
#define UPS_ONBATT	16
#define UPS_UNKNOWN2	32
#define UPS_BATTLOW	64
#define UPS_CHARGING	128

void noresp()
{
	printf ("<TD BGCOLOR=\"#FF0000\">Unavailable</TD>\n");
}

void getinfo (char *addr, char *desc)
{
	char	color[16], stattxt[128];
	long	status;
	float	tempf;
	upsinfo	ups;

	printf ("<TR ALIGN=CENTER>\n");
	printf ("<TD BGCOLOR=\"#00FFFF\"><A HREF=\"upsstats.cgi?host=%s\">%s</A></TD>\n", addr, desc);

	if (fetch (addr, &ups) < 0) {
		printf ("<TD COLSPAN=6 BGCOLOR=\"#FF0000\">Error: %s!</TD></TR>\n",
		        upserrstring(upserror));
		return;
	}
	
	printf ("<TD BGCOLOR=\"#00FFFF\">%s</TD>\n", ups.model);

	strcpy (stattxt, "");
	strcpy (color, "#FFFF00");
	status = strtol (ups.status, 0, 16);
	if (status & UPS_CALIBRATION) 
		strcat (stattxt, "CALIBRATION ");
	if (status & UPS_SLEEPING)
		strcat (stattxt, "SLEEPING ");
	if (status & UPS_UNKNOWN)
		strcat (stattxt, "UNKNOWN ");
	if (status & UPS_ONLINE) {
		strcat (stattxt, "ONLINE ");
		strcpy (color, "#00FF00");
	}
	if (status & UPS_ONBATT) {
		strcat (stattxt, "ON BATTERY ");
		strcpy (color, "#FF0000");
	}
	if (status & UPS_BATTLOW) {
		strcat (stattxt, "BATTERY LOW ");
		strcpy (color, "#FF0000");
	}
	if (status & UPS_CHARGING) {
		strcat (stattxt, "BATTERY CHARGING ");
		strcpy (color, "#FFFF00");
	}
	if (status == 0)
		noresp();
	else
		printf ("<TD BGCOLOR=\"%s\">%s</TD>\n", color, stattxt);

	printf ("<TD BGCOLOR=\"#00FF00\">%s %%</TD>\n", ups.battcap);
	printf ("<TD BGCOLOR=\"#00FF00\">%s VAC</TD>\n", ups.utility);
	printf ("<TD BGCOLOR=\"#00FF00\">%s %%</TD>\n", ups.upsload);
	tempf = (strtod (ups.upstemp, 0) * 1.8) + 32;
	printf ("<TD BGCOLOR=\"#00FF00\">%.1f �F</TD>\n", tempf); 
	printf ("</TR>\n");
}

int main() 
{
	FILE	*conf;
	time_t	tod;
	char	buf[256], fn[256], addr[256], *desc, timestr[256], *rest;
	int	restofs;

	printf ("Content-type: text/html\n");
	printf ("\n");

	printf ("<HTML>\n");
	printf ("<HEAD><TITLE>Multimon: UPS Status Page</TITLE></HEAD>\n");
	printf ("<BODY BGCOLOR=\"#FFFFFF\">\n");
	printf ("<TABLE BGCOLOR=\"#50A0A0\" ALIGN=CENTER>\n");
	printf ("<TR><TD>\n");
	printf ("<TABLE CELLPADDING=5>\n");
	printf ("<TR>\n");
	
	time (&tod);
	strftime (timestr, 100, "%a %b %d %X %Z %Y", localtime(&tod));
	printf ("<TH COLSPAN=7 BGCOLOR=\"#60B0B0\"><FONT SIZE=+2>Smart UPS Tools multimon %s</FONT><BR>%s</TH>\n", VERSION, timestr);
	printf ("</TR>\n"); 
	printf ("<TR BGCOLOR=\"#60B0B0\">\n");
	printf ("<TH COLSPAN=1>System</TH>\n");
	printf ("<TH COLSPAN=1>Model</TH>\n");
	printf ("<TH COLSPAN=1>Status</TH>\n");
	printf ("<TH COLSPAN=1>Batt Cap</TH>\n");
	printf ("<TH COLSPAN=1>Utility</TH>\n");
	printf ("<TH COLSPAN=1>UPS Load</TH>\n");
	printf ("<TH COLSPAN=1>Temperature</TH>\n");
	printf ("</TR>\n"); 

	/* ups status */

	sprintf (fn, "%s/hosts.conf", BASEPATH);
	conf = fopen (fn, "r");

	while (fgets (buf, sizeof(buf), conf)) 
		if (strncmp("MONITOR", buf, 4) == 0) {
			sscanf (buf, "%*s %s %n", addr, &restofs);
			rest = buf + restofs + 1;
			desc = strsep (&rest, "\"");
			getinfo (addr, desc);
		}

	fclose (conf);
	
	printf ("</TABLE>\n"); 
	printf ("</TD></TR>\n"); 
	printf ("</TABLE></BODY></HTML>\n");

	return (1);
}
