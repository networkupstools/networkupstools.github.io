/* upslog - log ups values to a file for later collection and analysis

   Copyright (C) 1998  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "upsfetch.h"

int main(int argc, char *argv[])
{
	upsinfo	ups;
	char	monhost[128], logfile[128], timestr[256];
	int	interval;
	time_t	tod;
	FILE	*log;

	if (argc != 4) {
		printf ("usage: %s <host> <logfile> <interval>\n", argv[0]);
		exit (0);
	}	

	strncpy (monhost, argv[1], sizeof (monhost));
	strncpy (logfile, argv[2], sizeof(logfile));
	interval = atoi (argv[3]);

	printf ("Smart UPS Tools upslog %s\n", VERSION);
	printf ("logging status of %s to %s (%is intervals)\n", 
		monhost, logfile, interval);

	log = fopen (logfile, "a");
	
	if (log == NULL) {
		perror ("unable to fopen log file");
		exit (0);
	}

	while (1) {
		time (&tod);
		strftime (timestr, sizeof(timestr), "%Y%m%d %H%M%S",
		          localtime(&tod));

		if (fetch (monhost, &ups) > 0) {
			fprintf (log, "%s %s %s %s %s %s %s\n", timestr, 
				ups.battcap, ups.utility, ups.upsload, 
				ups.status, ups.upstemp, ups.freq);

			fflush (log);
		}

		sleep (interval);
	}

	/* notreached */

	return (1);
}
