#define UPS_VERSION "0.40.2"
