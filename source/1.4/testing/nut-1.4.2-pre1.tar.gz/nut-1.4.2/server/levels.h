/* access levels for upsd network functions */

#define LEVEL_BASE	1
#define LEVEL_MONITOR	3
#define LEVEL_ALL	255

