/* cmd-map.h - translate between old CMD #defines and new names */

struct cmd_map_t {
	int	cmd;
	char	*old;
	char	*name;
};
