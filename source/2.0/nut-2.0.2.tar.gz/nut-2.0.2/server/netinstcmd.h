void net_instcmd(ctype *client, int numarg, const char **arg);
