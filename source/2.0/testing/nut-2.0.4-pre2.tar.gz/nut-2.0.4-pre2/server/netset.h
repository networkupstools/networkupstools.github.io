void net_set(ctype *client, int numarg, const char **arg);
