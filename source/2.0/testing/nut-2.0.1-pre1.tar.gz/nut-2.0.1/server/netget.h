void net_get(ctype *client, int numarg, const char **arg);
