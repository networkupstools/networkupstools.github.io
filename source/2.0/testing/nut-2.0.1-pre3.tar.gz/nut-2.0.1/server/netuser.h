void net_login(ctype *client, int numarg, const char **arg);
void net_logout(ctype *client, int numarg, const char **arg);
void net_master(ctype *client, int numarg, const char **arg);
void net_username(ctype *client, int numarg, const char **arg);
void net_password(ctype *client, int numarg, const char **arg);
