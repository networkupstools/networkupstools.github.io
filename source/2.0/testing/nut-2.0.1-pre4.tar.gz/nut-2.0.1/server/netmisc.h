void net_ver(ctype *client, int numarg, const char **arg);
void net_help(ctype *client, int numarg, const char **arg);
void net_fsd(ctype *client, int numarg, const char **arg);
