/* upscommon.c - functions used in more than one model support module

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

/* *******

   All of this code is going away.  Don't write anything else that uses
   these functions!  Use the serial.c functions instead!

   ******* */

#include "upscommon.h"
#include "common.h"

#include <pwd.h>
#include <ctype.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include "timehead.h"
#include <sys/socket.h>
#include <sys/un.h>

#ifdef HAVE_UU_LOCK
#include <libutil.h>
#endif

#include "dstate.h"
#include "extstate.h"

	extern	int	upsfd, do_lock_port;

static	int	upsc_debug = 0;

#ifdef HAVE_UU_LOCK
	static	char	*upsport = NULL;
#endif

/* need to pick a sane default.  maybe this should be set by open_serial */
	unsigned int upssend_delay = 0;
static	char	upssend_endchar = '\0';
	
	int	flag_timeoutfailure = 0;

static	struct	sigaction sa;
static	sigset_t	upscom_sigmask;

static void uc_warnold(const char *fn)
{
	static	unsigned int	count = 0;

	if (count++ > 10)
		return;

	upslogx(LOG_NOTICE, "Driver uses old function [%s]", fn);
}

/* function for erasing "timeout"-conditions */
void nolongertimeout(void)
{
	uc_warnold("nolongertimeout");

	/* if override enabled, then return without changing anything */
	if (flag_timeoutfailure == -1)
		return;

	if (flag_timeoutfailure == 1)
		upslogx(LOG_NOTICE, "Serial port read ok again");
	
	flag_timeoutfailure = 0;
}

/* signal handler for SIGALRM when trying to read */
static void timeout(int sig)
{
	uc_warnold("timeout");

	sa.sa_handler = SIG_DFL;
	sigemptyset(&upscom_sigmask);
	sa.sa_mask = upscom_sigmask;
	sa.sa_flags = 0;
	sigaction(SIGALRM, &sa, NULL);

	/* if override enabled, then return without changing anything */
	if (flag_timeoutfailure == -1)
		return;

	if (flag_timeoutfailure == 0)
		upslogx(LOG_NOTICE, "Serial port read timed out");
	
	flag_timeoutfailure = 1;
	return;
}

/* wait for an answer in the form <data><endchar> and store in buf */
int upsrecv(char *buf, int buflen, char endchar, const char *ignchars)
{
	char	recvbuf[512], *ptr, in;
	int	ret;
	size_t	cnt, maxsize;

	uc_warnold("upsrecv");

	memset(recvbuf, '\0', sizeof(recvbuf));

	sa.sa_handler = timeout;
	sigemptyset(&upscom_sigmask);
	sa.sa_mask = upscom_sigmask;
	sa.sa_flags = 0;
	sigaction(SIGALRM, &sa, NULL);

	maxsize = sizeof(recvbuf) - 4;		/* why 4? */

	alarm(3);

	ptr = recvbuf;
	*ptr = 0;
	cnt = 0;
	for (;;) {
		ret = read(upsfd, &in, 1);
		if (ret > 0) {

			if (in == endchar) {
				alarm(0);
				signal(SIGALRM, SIG_IGN);
				strlcpy(buf, recvbuf, buflen);
				if (upsc_debug > 0) {
					unsigned int	i;
					printf("upsrecv: read %d bytes [", cnt);
					for (i = 0; i < cnt; ++i)
						printf(isprint((unsigned char)buf[i]) ? "%c" : "\\%03o",
							   buf[i]);
					printf("]\n");
				}
				return buflen;
			}

			if (strchr(ignchars, in) == NULL) {
				*ptr++ = in;
				*ptr = 0; /* tie off end */
				cnt++;
			}
			
			nolongertimeout();
		}
		else {
			alarm(0);
			signal(SIGALRM, SIG_IGN);
			strlcpy(buf, recvbuf, buflen);
			return -1;
		}

		/* keep from overrunning the buffer - lame hack */
		if (cnt > maxsize) {
			upslogx(LOG_NOTICE, "UPS is spewing wildly");
			return -1;
		}
	}

	return -1;	/* not reached */
}

/* read buflen chars and store in buf */
int upsrecvchars(char *buf, int buflen)
{
	int ret,count;
	char* bufptr;

	uc_warnold("upsrecvchars");
	
	sa.sa_handler = timeout;
	sigemptyset(&upscom_sigmask);
	sa.sa_mask = upscom_sigmask;
	sa.sa_flags = 0;
	sigaction(SIGALRM, &sa, NULL);

	alarm(3);
	
	bufptr=buf;
	count=buflen;
	while (count>0) {
		ret=read(upsfd,bufptr,count);
		if (ret>0) {
			bufptr+=ret;
			count-=ret;
		} else {
			alarm (0);
			signal (SIGALRM, SIG_IGN);
			return (-1);
		}
	}
	alarm (0);
	signal (SIGALRM, SIG_IGN);
	return buflen;
}

int upssend(const char *fmt, ...)
{
	char	buf[1024], *p;
	int	ret, bytes_sent = 0;
	va_list	ap;

	uc_warnold("upssend");

	va_start(ap, fmt);

	ret = vsnprintf(buf, sizeof(buf), fmt, ap);

	if ((ret < 1) || (ret >= (int) sizeof(buf)))
		upslogx(LOG_WARNING, "upssend: vsnprintf needed more than %d bytes",
			sizeof(buf));

	va_end(ap);

	tcflush(upsfd, TCIFLUSH);

	for (p = buf; *p; p++) {
		if (write(upsfd, p, 1) != 1)
			return -1;
		bytes_sent++;
		usleep(upssend_delay);
	}

	if (upssend_endchar) {
		if (write(upsfd, &upssend_endchar, 1) != 1)
			return -1;
		bytes_sent++;
		usleep(upssend_delay);
	}

	return bytes_sent;
}
