/* upscommon.h - prototypes for upscommon.c

   Copyright (C) 1999  Russell Kroll <rkroll@exploits.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

/* **********************************************************************

   All of this code is going away.  Don't write anything else that uses
   these functions!  Use the serial.c functions instead!

   ********************************************************************** */

#include "config.h"

#if defined(HAVE_SYS_TERMIOS_H)
#  include <sys/termios.h>	/* for speed_t */
#else
#  error "No <sys/termios.h> available.  Unable to continue."
#endif /* HAVE_SYS_TERMIOS_H */

/* function for erasing "timeout"-conditions */
void nolongertimeout(void);

/* receive up to buflen bytes from the ups into buf until endchar is read */
/* any characters received that match members of ignchars are discarded */
int upsrecv(char *buf, int buflen, char endchar, const char *ignchars);

/* read buflen chars and store in buf */
int upsrecvchars(char *buf, int buflen);

/* send a string to the ups */
int upssend(const char *fmt, ...);

extern int flag_timeoutfailure;
extern unsigned int upssend_delay;
