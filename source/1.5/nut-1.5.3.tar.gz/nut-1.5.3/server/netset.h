int net_set(ctype *client, int numarg, char **arg);
