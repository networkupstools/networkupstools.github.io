int net_list(ctype *client, int numarg, char **arg);
