int net_get(ctype *client, int numarg, char **arg);
