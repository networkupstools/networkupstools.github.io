int net_instcmd(ctype *client, int numarg, char **arg);
