void desc_load(void);
void desc_free(void);
const char *desc_get_cmd(const char *name);
const char *desc_get_var(const char *name);
